local root=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/]])
local native=dofile(root..'CCIP/native.lua')
local config=dofile(root..'CCIP/ccrp.lua')
local mathlib=dofile(root..'flight_math.lua')
local M={}
local lastPoseFrame
local handles,down,values={},{ },{}
local staged,buffer=nil,{}
local function set(n,v)if staged then staged[n]=v;return end;if values[n]==v then return end;if not handles[n]then handles[n]=get_param_handle('F4MH_'..n)end;values[n]=v;handles[n]:set(v)end
function M.command(cmd,value,ag)
 if cmd~=3950 and cmd~=3951 then return end
 local pressed=value>.5
 if ag and pressed and not down[cmd] and native then native.ag_command(cmd==3950 and 1 or 2) end
 down[cmd]=pressed
end
function M.mode()return native and native.ag_state().mode or 0 end
local function update_frame(s)
 local state=native and native.ag_state() or {mode=0,target=0}
 lastPoseFrame=state
 local active=s.ag and state.mode==1
 set('AG_CCIP',s.ag and not active and 1 or 0);set('AG_CCRP',active and 1 or 0)
 set('CCRP_FIXED',active and state.target~=1 and 1 or 0)
 set('CCRP_FIXED_X',0)
 set('CCRP_FIXED_Y',math.tan(config.sight_pitch)*1000+config.optical_y)
 for _,name in ipairs({'CCRP_TARGET_SHOW','CCRP_ASL_SHOW','CCRP_SOLUTION_SHOW','CCRP_RANGE_SHOW','CCRP_TTR_SHOW','CCRP_ALIGN_SHOW','CCRP_REFERENCE_SHOW','CCRP_BEARING_SHOW'})do set(name,0)end
 local px,py,pz,pitch,bank,heading=s.x,s.y,s.z,s.pitch,s.bank,s.heading
 if state.pose_valid==1 then
  if not state.pose_time or s.time-state.pose_time<-.05 or s.time-state.pose_time>.25 then return end
  px,py,pz,pitch,bank,heading=state.ox,state.oy,state.oz,state.opitch,state.obank,state.oheading
 end
 if not(active and state.target==1 and px and py and pz and pitch and bank and heading)then return end
 set('CCRP_RANGE_SHOW',1);set('CCRP_RANGE_NM',math.floor((state.range or 0)/1852*100+.5)/100)
 local x,y,limited=mathlib.project(state.tx-px,state.ty-py,state.tz-pz,pitch,bank,heading,config.optical_y)
 if x then set('CCRP_TARGET_X',x);set('CCRP_TARGET_Y',y);set('CCRP_TARGET_SHOW',limited and 0 or 1)end
 if not x or limited then
  set('CCRP_BEARING',math.floor(math.deg(math.atan2(state.tz-pz,state.tx-px))%360+.5)%360)
  set('CCRP_BEARING_SHOW',1)
 end
 local direction=state.valid==1 and state.heading or math.atan2(state.tz-pz,state.tx-px)
 local f,u,r=mathlib.body(math.cos(direction),0,math.sin(direction),pitch,bank,heading)
 local ax=mathlib.ray(f,u,r,0,true)
 if ax then set('CCRP_ASL_X',ax);set('CCRP_ASL_Y',0);set('CCRP_ASL_SHOW',1)end
 local fresh=state.stamp and s.time-state.stamp>=0 and s.time-state.stamp<.35
 if fresh and state.valid==1 and ax then
  -- Only the FPM-attached marks require a valid flight registration.
  -- Keep target geometry, alignment, range and release timing independent.
  local fpmValid=mathlib.finite(s.fpm_x) and mathlib.finite(s.fpm_y)
  if fpmValid then
   set('CCRP_REFERENCE_X',s.fpm_x)
   set('CCRP_REFERENCE_Y',s.fpm_y)
   set('CCRP_REFERENCE_SHOW',1)
  end
  local ttr=state.ttr or -1
  local misaligned=state.status==1
  set('CCRP_ALIGN_SHOW',misaligned and 1 or 0)
  if ttr>=0 then set('CCRP_TTR_SHOW',1);set('CCRP_TTR',math.floor(ttr*10+.5)/10)end
  set('CCRP_SOLUTION_X',ax)
  local offset=math.max(-40,math.min(50,ttr>=0 and ttr*5 or -10))
  if misaligned then offset=math.max(12,offset)end
  if fpmValid then
   set('CCRP_SOLUTION_Y',s.fpm_y+offset)
   set('CCRP_SOLUTION_SHOW',1)
  end
 end
end
function M.update(s)
 staged=buffer;update_frame(s)
 local final=staged;staged=nil
 for n,v in pairs(final)do set(n,v);final[n]=nil end
 return lastPoseFrame
end
return M
