declare_plugin('F4ModernAvionicsRwrResources',{
 installed=true,dirName=current_mod_path,displayName='F-4 Modern Avionics RWR Resources',
 version='1.1.35',state='installed',info='Local ALR-56M adapter sound resources.'
})
mount_vfs_sound_path((require('lfs').writedir()..[[Scripts/F4ModernAvionics/RWR/Sounds]]))
plugin_done()
