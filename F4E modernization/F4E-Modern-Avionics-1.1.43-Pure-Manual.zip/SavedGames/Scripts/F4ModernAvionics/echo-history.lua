-- Display-only echo association. Never supplies acquisition, STT or IFF data.
local M={}
function M.new(profile)
 local tracks,lastStamp,lastTime={},-math.huge,-math.huge
 local hold=profile.display_hold_seconds or 2.5
 return function(batch,now,mode)
  if now<lastTime or (mode~=1 and mode~=2)then tracks={};lastStamp=-math.huge end
  lastTime=now
  for i=#tracks,1,-1 do if now-tracks[i].stamp>hold then table.remove(tracks,i)end end
  if mode~=1 and mode~=2 then return {}end
  local fresh,newest={},lastStamp
  for _,c in ipairs(batch)do
   local stamp=now-c.age
   if c.age<=hold and stamp>lastStamp+.003 and #fresh<32 then
    fresh[#fresh+1]={range=c.range,az=c.az,kind=c.kind,stamp=stamp}
    newest=math.max(newest,stamp)
   end
  end
  if #fresh>0 then
   local pairs={}
   for i,c in ipairs(fresh)do for j,t in ipairs(tracks)do
    local dt=math.max(0,c.stamp-t.stamp)
    local dr=c.range-(t.range+(t.vr or 0)*dt)
    local da=c.az-(t.az+(t.va or 0)*dt)
    local rg=math.max(150,math.min(2000,800*dt));local ag=math.rad(math.min(8,1+3*dt))
    if math.abs(dr)<=rg and math.abs(da)<=ag then
     local score=(dr/rg)^2+(da/ag)^2
     if c.kind~=0 and t.kind~=0 and c.kind~=t.kind then score=score+3 end
     if score<=2 then pairs[#pairs+1]={i=i,j=j,score=score}end
    end
   end end
   table.sort(pairs,function(a,b)if a.score==b.score then return a.i<b.i end;return a.score<b.score end)
   local usedC,usedT={},{}
   for _,pair in ipairs(pairs)do
    if not usedC[pair.i] and not usedT[pair.j] then
     local c,t=fresh[pair.i],tracks[pair.j];local dt=c.stamp-t.stamp
     if dt>=.05 then
      local vr=(c.range-t.range)/dt;local va=(c.az-t.az)/dt
      c.vr=math.abs(vr)<2000 and vr or nil;c.va=math.abs(va)<math.rad(120)and va or nil
     else c.vr=t.vr;c.va=t.va end
     tracks[pair.j]=c;usedC[pair.i]=true;usedT[pair.j]=true
    end
   end
   for i,c in ipairs(fresh)do if not usedC[i]and #tracks<32 then tracks[#tracks+1]=c end end
   lastStamp=newest
  end
  local out={}
  for _,t in ipairs(tracks)do out[#out+1]={range=t.range,az=t.az,kind=t.kind,age=math.max(0,now-t.stamp)}end
  return out
 end
end
return M
