-- F-4E only, BabyFoxSight v0.14.60 MIT snapshot.
return {["mass"]=0.1,["caliber"]=0.019995,["cx"]={0.2,1.27,0.65,0.26,2.35},["muzzle_vel"]=1050,["area"]=0.000314,["cd"]=0.25}
