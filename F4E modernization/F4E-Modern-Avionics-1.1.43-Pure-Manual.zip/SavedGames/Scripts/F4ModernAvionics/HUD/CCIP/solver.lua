-- Native C++ is preferred; Lua reference fallback requires no external process.
local root=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/CCIP/]])
local native=dofile(root..'native.lua')
local reference=dofile(root..'foxsight-physics.lua')
local M={orientation=reference.orientation}
function M.solve(origin,velocity,profile,terrain,wind)
    if native and profile and profile.foxsight then
        return native.solve(origin,velocity,profile,terrain,wind or {x=0,y=0,z=0})
    end
    if profile and profile.foxsight and ((profile.foxsight.bomblet_mass or 0)>0 or profile.fixedDispenser==1) then
        return nil,'NATIVE_REQUIRED_FOR_DISPENSER'
    end
    return reference.solve(origin,velocity,profile,terrain,wind)
end
return M
