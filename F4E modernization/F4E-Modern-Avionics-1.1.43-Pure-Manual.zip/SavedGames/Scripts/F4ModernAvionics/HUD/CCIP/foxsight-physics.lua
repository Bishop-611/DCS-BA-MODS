-- Numerical principles adapted from BabyFoxSight v0.14.60 (MIT), Huba, 2026.
-- See THIRD-PARTY-BabyFoxSight-LICENSE.txt in the installation payload.
-- Deterministic neutral-control impact: no guidance or random shot dispersion.
local M={}
local atmosphere_nodes=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/CCIP/foxsight-atmosphere.lua]]))
local function afm_atmosphere(h)
 local u=math.max(0,math.min(#atmosphere_nodes-1,(h+1000)/25));local i=math.floor(u)+1
 local a,b=atmosphere_nodes[i],atmosphere_nodes[math.min(i+1,#atmosphere_nodes)];local f=u-math.floor(u)
 return a[1]+(b[1]-a[1])*f,a[2]+(b[2]-a[2])*f
end
local function dot(a,b)return a[1]*b[1]+a[2]*b[2]+a[3]*b[3] end
local function cross(a,b)return {a[2]*b[3]-a[3]*b[2],a[3]*b[1]-a[1]*b[3],a[1]*b[2]-a[2]*b[1]} end
local function norm(a)local n=0;for _,v in ipairs(a) do n=n+v*v end;n=math.sqrt(n);if n<1e-12 then return nil end;local r={};for i,v in ipairs(a) do r[i]=v/n end;return r end
local function mul(a,b)return {a[1]*b[1]-a[2]*b[2]-a[3]*b[3]-a[4]*b[4],a[1]*b[2]+a[2]*b[1]+a[3]*b[4]-a[4]*b[3],a[1]*b[3]-a[2]*b[4]+a[3]*b[1]+a[4]*b[2],a[1]*b[4]+a[2]*b[3]-a[3]*b[2]+a[4]*b[1]} end
local function rotate(q,v)local r=mul(mul(q,{0,v[1],v[2],v[3]}),{q[1],-q[2],-q[3],-q[4]});return {r[2],r[3],r[4]} end
function M.orientation(pitch,bank,heading)
 -- DCS forward/up/right basis: heading rotates positive X towards positive Z.
 local a={math.cos(heading/2),0,-math.sin(heading/2),0}
 local b={math.cos(pitch/2),0,0,math.sin(pitch/2)}
 local c={math.cos(bank/2),math.sin(bank/2),0,0}
 return norm(mul(mul(a,b),c))
end
function M.atmosphere(h)
 -- BabyFoxSight generic DCS ISA branch; actual mission atmosphere is optional future input.
 h=math.max(0,h);local t=math.max(216.65,288.15-.0065*math.min(h,11000))
 local pressure=101325*math.max(.01,1-2.25577e-5*h)^5.25588
 return pressure/(287.058*t),math.sqrt(1.4*287.058*t)
end
function M.cx(m,c)
 if not c or #c<5 then return .25 end
 if m<=c[3] then return c[4] end
 if m>c[5] then return c[2]/math.sqrt(math.max(1e-12,m*m-1)) end
 local h=c[5]-c[3];if h<=1e-12 then return c[4] end
 local t=(m-c[3])/h;local t2,t3=t*t,t*t*t
 local endv=c[2]/math.sqrt(c[5]^2-1)
 local slope=-c[1]*c[2]*c[5]/(c[5]^2-1)^1.5
 return (2*t3-3*t2+1)*c[4]+(-2*t3+3*t2)*endv+(t3-t2)*h*slope
end
function M.cx0(m,c,scale)
 if not c or #c<2 then return nil end
 local f=math.max(0,m/(scale and scale>0 and scale or .2));local i=math.floor(f)+1
 if i>=#c then return c[#c] end
 return c[i]+(c[i+1]-c[i])*(f-math.floor(f))
end
local function afm_drag(f,m,added)
 local base
 if f.cx_mode==1 then base=M.cx0(m,f.Cx0,f.table_scale)
 elseif f.cx_mode==2 then local c=f.old_cx_coeff;base=m>=1 and ((c[2]-c[4])/m^c[5]+c[4]) or (math.exp(-(m-1)^2/c[3])*(c[2]-c[1])+c[1])
 else base=M.cx(m,f.cx_coeff) end
 if f.deplCx~=0 and f.addDeplSw>0 and added<f.addDeplSw then local start=M.cx(m,f.no_wings_cx_coeff);base=start+(base-start)*added/f.addDeplSw end
 return base
end
local function afm_step(f,p,v,q,w,t,dt,wind)
 local b1,b2,b3=rotate(q,{1,0,0}),rotate(q,{0,1,0}),rotate(q,{0,0,1})
 local rel={v[1]-wind.x,v[2]-wind.y,v[3]-wind.z};local speed=math.sqrt(dot(rel,rel))
 local added=0
 if t>=f.wingsDeplDelay then
  if t==f.wingsDeplDelay or t>f.wingsDeplDelay+f.wingsDeplProcTime then added=f.addDeplSw
  else added=f.addDeplSw*(t-f.wingsDeplDelay)/f.wingsDeplProcTime end
 end
 local force,torque={0,0,0},{0,0,0}
 if speed>1e-8 then
  local rho,sound=afm_atmosphere(p[2]);local mach=speed/sound
  local ay,az=dot(rel,b3)/speed,-dot(rel,b2)/speed
  local dc=mach<1.14128 and f.dCydA[1] or f.dCydA[2]/math.sqrt(mach*mach-1)
  local peak=f.maxAoa*dc*57.3
  local function cy(angle)if angle==0 then return 0 end;local value=math.max(peak-(math.abs(angle)-f.maxAoa)^2*peak/f.maxAoa^2,0);return angle<0 and -value or value end
  local cyy,cyz=cy(az),cy(-ay)
  local induced=dc>1e-8 and math.max(1/(dc*57.3),f.A) or 0
  if f.addDeplSw>0 then induced=induced*((1-added/f.addDeplSw)*(f.no_wings_A_mlt-1)+1) end
  local dynamic=.5*rho*speed*speed;local swy,swz=f.Sw+added,f.Sw
  local local_force={-(afm_drag(f,mach,added)*f.S+cyy^2*induced*swy+cyz^2*induced*swz)*dynamic,cyy*swy*dynamic,cyz*swz*dynamic}
  local vx=norm(rel);local b3n=norm(b3);local projection=dot(b3n,vx)
  local vz=norm({b3[1]-projection*vx[1],b3[2]-projection*vx[2],b3[3]-projection*vx[3]})
  if not vz then return nil,'DEGENERATE_AFM_FRAME' end
  local vy=cross(vz,vx)
  for i=1,3 do force[i]=vx[i]*local_force[1]+vy[i]*local_force[2]+vz[i]*local_force[3] end
  local roll=f.Mx0;if #f.Mx0Ma==2 then roll=mach<1.1 and f.Mx0Ma[1] or f.Mx0Ma[2]/math.sqrt(mach*mach-1) end
  local damping=f.Mw_x~=0 and f.Mw_x*f.L/speed or f.Kw_x;local scale=dynamic*f.S*f.L
  torque={(roll-damping*w[1])*scale,(-ay*f.Ma-f.L/speed*w[2]*f.Mw)*scale,(-az*f.Ma_z-f.L/speed*w[3]*f.Mw)*scale}
 end
 local nextp,nextv={},{ }
 for i=1,3 do
  w[i]=w[i]+dt*torque[i]/(i==1 and f.I_x or f.I)
  local accel=force[i]/f.mass-(i==2 and 9.81 or 0)
  nextp[i]=p[i]+v[i]*dt+.5*accel*dt*dt;nextv[i]=v[i]+accel*dt
 end
 local world={};for i=1,3 do world[i]=w[1]*b1[i]+w[2]*b2[i]+w[3]*b3[i] end
 local dq=mul({0,world[1],world[2],world[3]},q);local nextq={};for i=1,4 do nextq[i]=q[i]+dq[i]*dt*.5 end
 return nextp,nextv,norm(nextq)
end
local function generic_step(p,v,profile,t,dt,wind)
 local d=profile.foxsight;local rho,sound=M.atmosphere(p[2])
 local rel={v[1]-wind.x,v[2]-wind.y,v[3]-wind.z};local speed=math.sqrt(dot(rel,rel))
 local mass=profile.mass;local burn=profile.burnTime or 0;local clock=t-(profile.ignitionDelay or 0)
 if burn>0 then mass=mass-(profile.fuelMass or 0)*math.max(0,math.min(1,clock/burn)) end
 if mass<=0 then return nil,'BAD_MASS' end
 local area=profile.dragArea
 if d then
  local cx=M.cx0(speed/sound,d.cx0,.2) or (#(d.cx or {})>=5 and M.cx(speed/sound,d.cx) or d.cd)
  local s=d.caliber and math.pi*.25*d.caliber^2 or d.area
  area=s*cx
  if profile.retarderEnabled then
   local explicit=(d.chute_diam or 0)>0 and t>=(d.chute_open_time or 0) and ((d.chute_cut_time or 0)<=0 or t<d.chute_cut_time)
   if explicit then area=math.pi*.25*d.chute_diam^2*d.chute_cx
   elseif (d.cx_factor or 0)>0 and t>=(d.open_delay or 0) and ((d.chute_cut_time or 0)<=0 or t<d.chute_cut_time) then
    local c=cx*d.cx_factor;if (d.chute_cx_max or 0)>0 then c=math.min(c,d.chute_cx_max) end;area=s*c
   end
  end
 elseif profile.retarder and t>=profile.retarder.delay then area=profile.retarder.dragArea end
 local k=.5*rho*area*speed/mass;local a={-k*rel[1],-9.80665-k*rel[2],-k*rel[3]}
 if profile.thrust and clock>=0 and clock<burn then
  local direction=profile.direction;local n=direction and math.sqrt(direction.x^2+direction.y^2+direction.z^2) or 0
  if profile.alignThrust and speed>1 then direction={x=rel[1]/speed,y=rel[2]/speed,z=rel[3]/speed};n=1 end
  if not direction or n<1e-10 then return nil,'NO_MOTOR_AXIS' end
  local thrust=profile.thrust/mass/n;a[1]=a[1]+thrust*direction.x;a[2]=a[2]+thrust*direction.y;a[3]=a[3]+thrust*direction.z
 end
 local np,nv={},{ }
 for i=1,3 do nv[i]=v[i]+a[i]*dt;np[i]=p[i]+nv[i]*dt end
 return np,nv
end
function M.solve(origin,velocity,profile,terrain,wind)
 if type(profile)~='table' or not(profile.verified or profile.estimated) then return nil,'NO_PROFILE' end
 if type(terrain)~='function' or not profile.mass or profile.mass<=0 then return nil,'BAD_PROFILE' end
 local p,v={origin.x,origin.y,origin.z},{velocity.x,velocity.y,velocity.z}
 for _,vec in ipairs({p,v}) do if #vec~=3 then return nil,'BAD_STATE' end;for _,x in ipairs(vec) do if x~=x or math.abs(x)>1e12 then return nil,'BAD_STATE' end end end
 wind=wind or {x=0,y=0,z=0};for _,k in ipairs({'x','y','z'}) do if type(wind[k])~='number' or wind[k]~=wind[k] then return nil,'BAD_WIND' end end
 local ground=terrain(p[1],p[3]);if type(ground)~='number' or p[2]<=ground then return nil,'BAD_TERRAIN' end
 local fm=profile.foxsight and profile.foxsight.afm
 if fm and not next(fm) then fm=nil end
 local dt=fm and fm.dt or .01;local q=profile.orientation or {1,0,0,0};local w={0,0,0}
 if fm then q=mul(q,{math.cos(fm.model_roll*.5),math.sin(fm.model_roll*.5),0,0}) end
 local t=0
 for step=1,math.ceil(120/dt) do
  if profile.yield_step and step%64==0 then profile.yield_step() end
  local np,nv,nq
  if fm then np,nv,nq=afm_step(fm,p,v,q,w,t,dt,wind) else np,nv=generic_step(p,v,profile,t,dt,wind) end
  if not np then return nil,nv end
  local g=terrain(np[1],np[3]);if type(g)~='number' or g~=g then return nil,'NO_TERRAIN' end
  if np[2]<=g then
   -- Refine the segment against the actual sampled terrain rather than a flat AGL plane.
   local lo,hi=0,1
   for _=1,12 do local f=(lo+hi)*.5;local x,z=p[1]+(np[1]-p[1])*f,p[3]+(np[3]-p[3])*f;local h=terrain(x,z);if type(h)~='number' then return nil,'NO_TERRAIN' end;if p[2]+(np[2]-p[2])*f>h then lo=f else hi=f end end
   local f=(lo+hi)*.5
   return {x=p[1]+(np[1]-p[1])*f,y=p[2]+(np[2]-p[2])*f,z=p[3]+(np[3]-p[3])*f,time=t+f*dt,model=fm and 'FOXSIGHT_AFM_NEUTRAL' or 'FOXSIGHT_POINT_MASS'},'OK'
  end
  p,v,q=np,nv,nq or q;t=t+dt
 end
 return nil,'NO_IMPACT'
end
return M
