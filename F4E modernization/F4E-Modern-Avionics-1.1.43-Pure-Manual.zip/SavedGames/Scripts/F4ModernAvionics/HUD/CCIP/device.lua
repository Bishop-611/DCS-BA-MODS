local root=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/]])
local mathlib=dofile(root..'flight_math.lua')
local M={}
local packet,pending,sequence=nil,nil,nil
local smoothX,smoothY,smoothZ,lastDistance=0,0,0,0
local smoothingTime=.03
local params,values={},{ }
local staged,buffer=nil,{}
local function finite(v) return type(v)=='number' and v==v and math.abs(v)<1e12 end
local function set(n,v) if staged then staged[n]=v;return end;if values[n]==v then return end;if not params[n] then params[n]=get_param_handle('F4MH_'..n) end;values[n]=v;params[n]:set(v) end
function M.command(cmd,value)
    if cmd<3900 or cmd>3913 or not finite(value) then pending=nil;return end
    if cmd==3900 then sequence=value;pending={};return end
    if not pending then return end
    if cmd==3913 then
        if value~=sequence then pending=nil;return end
        for i=1,12 do if not finite(pending[i]) then pending=nil;return end end
        if (pending[1]~=0 and pending[1]~=1) or pending[7]<0 or pending[7]>9 then pending=nil;return end
        local dt=packet and pending[2]-packet[2] or 0
        if packet and packet[1]==1 and pending[1]==1 and packet[8]==pending[8] and packet[9]==pending[9] and dt>0 and dt<=.3 then
            local decay=math.exp(-dt/smoothingTime)
            smoothX=packet[3]+packet[10]*dt+smoothX*decay-pending[3]
            smoothY=packet[4]+smoothY*decay-pending[4]
            smoothZ=packet[5]+packet[12]*dt+smoothZ*decay-pending[5]
            local limit=math.max(5,math.min(200,lastDistance*.04))
            if smoothX*smoothX+smoothY*smoothY+smoothZ*smoothZ>limit*limit then smoothX,smoothY,smoothZ=0,0,0 end
        else smoothX,smoothY,smoothZ=0,0,0 end
        packet=pending;pending=nil;return
    end
    pending[cmd-3900]=value
end
local visible_lines={}
local generation=0
local function update(s)
    set('CCIP_VALID',0);set('CCIP_MISSING',0);set('CCIP_UNSUPPORTED',0);set('CCIP_NO_SOLUTION',0)
    set('CCIP_NO_SELECTION',0);set('CCIP_MIXED',0);set('CCIP_WEAPON',0)
    for i=1,5 do set('CCIP_WEAPON_'..i,0) end
    if not s.ag then smoothX,smoothY,smoothZ=0,0,0;return end
    local age=packet and s.time-packet[2] or nil
    if not packet or age<-.1 or age>1 then smoothX,smoothY,smoothZ=0,0,0;set('CCIP_MISSING',1);return end
    if packet[1]~=1 then
        if packet[7]==8 or packet[7]==9 then return end -- Excluded weapons or above the 12000 ft AGL gate.
        if packet[7]==3 then set('CCIP_UNSUPPORTED',1)
        elseif packet[7]==2 then set('CCIP_NO_SELECTION',1)
        elseif packet[7]==7 then set('CCIP_MIXED',1)
        else set('CCIP_NO_SOLUTION',1) end
        return
    end
    if not(s.x and s.y and s.z and s.pitch and s.bank and s.heading) then set('CCIP_MISSING',1);return end
    -- Extrapolate the last footprint with launch-platform translation between solutions.
    local decay=math.exp(-math.max(0,age)/smoothingTime)
    local dx=packet[3]+packet[10]*age+smoothX*decay-s.x
    local dy=packet[4]+smoothY*decay-s.y -- footprint remains on terrain, not translated by aircraft vertical speed
    local dz=packet[5]+packet[12]*age+smoothZ*decay-s.z
    lastDistance=math.sqrt(dx*dx+dy*dy+dz*dz)
    local f,u,r=mathlib.body(dx,dy,dz,s.pitch,s.bank,s.heading)
    local x,y=mathlib.ray(f,u,r,0,false)
    if not x then set('CCIP_NO_SOLUTION',1);return end
    local scale=math.max(math.abs(x)/100,y>=0 and y/15 or -y/100,1)
    x,y=x/scale,y/scale
    set('CCIP_VALID',1);set('CCIP_X',x);set('CCIP_Y',y);set('CCIP_LIMIT',scale>1 and 1 or 0)
    set('CCIP_TOF',packet[6]);set('CCIP_WEAPON',packet[8])
    if packet[8]>=1 and packet[8]<=5 then set('CCIP_WEAPON_'..packet[8],1) end
    if scale==1 then
        local fx,fy=s.fpm_x or 0,s.fpm_y or 0
        local length=math.sqrt((x-fx)^2+(y+16-fy)^2)
        local count=math.min(128,math.max(1,math.ceil(length/.8)))
        for i=1,count do
            local t=(i-1)/count;local px,py=fx+(x-fx)*t,fy+(y+16-fy)*t
            if math.abs(px)<=110 and py>=-110 and py<=40 then
                visible_lines[i]=generation
                set('CCIP_LINE_X_'..i,px);set('CCIP_LINE_Y_'..i,py);set('CCIP_LINE_SHOW_'..i,1)
            end
        end
    end
end
function M.update(s)
    staged=buffer
    generation=generation+1
    update(s)
    -- Keep unchanged segments alive rather than clearing/re-showing 128
    -- controllers at 100 Hz. Clear only segments absent from this frame.
    for i,seen in pairs(visible_lines)do
        if seen~=generation then set('CCIP_LINE_SHOW_'..i,0);visible_lines[i]=nil end
    end
    local final=staged;staged=nil
    for n,v in pairs(final)do set(n,v);final[n]=nil end
end
return M
