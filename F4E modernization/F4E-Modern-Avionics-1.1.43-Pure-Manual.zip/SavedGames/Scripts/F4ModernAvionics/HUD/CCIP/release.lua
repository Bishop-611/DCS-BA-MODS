-- Consent gating only. All actual release commands still go through native weapons.
local M={}
function M.new(native,forward,ready,report)
 local c={physical=false,held=false,fired=false,blocked=false,active=false,epoch=nil,windowConsumed=false}
 function c:update(ag,now,snapshot)
  local s=snapshot or(native and (native.ag_control or native.ag_state)())or {mode=0}
  local active=ag and s.mode==1
  if self.epoch~=nil and s.epoch~=self.epoch or active~=self.active then
   if self.physical or self.fired then
    if report and self.fired then report('NATIVE_HOLD_END MODE_OR_TARGET_CHANGE')end
    forward(0);self.blocked=self.physical
   end
   self.held=false;self.fired=false;if native then native.ag_hold(0)end
   self.windowConsumed=false
  end
  self.epoch=s.epoch;self.active=active
  -- Once the computed release point opens consent, keep the native button
  -- held for the pilot's physical hold. Native quantity/interval controls own
  -- the salvo; an artificial 120 ms pulse can truncate a ripple.
  if self.fired and ready and not ready() then
   if report then report('NATIVE_HOLD_END DISARM')end
   forward(0);self.fired=false;self.held=false;self.blocked=self.physical
   if native then native.ag_hold(0)end
  end
  if report and self.physical and active and now>=(self.nextLog or -1) then
   self.nextLog=now+1
   report(string.format('held=%s blocked=%s fired=%s target=%s valid=%s window=%s alignment=%s armed=%s ttr=%.3f along=%.1f cross=%.1f age=%.3f',
    tostring(self.held),tostring(self.blocked),tostring(self.fired),tostring(s.target),tostring(s.valid),tostring(s.release),s.status==1 and 'OFF' or 'OK',tostring(not ready or ready()),s.ttr or -1,s.along or 0,s.cross or 0,now-(s.stamp or now)))
  end
  if s.release~=1 then self.windowConsumed=false end
  if active and self.held and not self.blocked and not self.fired and not self.windowConsumed and s.target==1 and s.valid==1 and s.release==1 and now-s.stamp>=0 and now-s.stamp<.35 and (not ready or ready()) then
   forward(1);self.fired=true;self.windowConsumed=true
   if report then report('NATIVE_HOLD_BEGIN')end
  end
 end
 function c:command(value,ag,now)
  self:update(ag,now)
  self.physical=value>.5
  if report then report(self.physical and 'PHYSICAL_DOWN' or 'PHYSICAL_UP')end
  if not self.physical then
   if report and self.fired then report('NATIVE_HOLD_END KEY_UP')end
   self.blocked=false;self.held=false;self.fired=false;forward(0);if native then native.ag_hold(0)end;return
  end
  if self.blocked then return end
  if self.active then self.held=true;if native then native.ag_hold(1)end
  else forward(1)end
 end
 return c
end
return M
