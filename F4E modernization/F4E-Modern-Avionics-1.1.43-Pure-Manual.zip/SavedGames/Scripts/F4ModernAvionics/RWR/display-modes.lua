-- F4 panel compatibility layer. Never modifies received contacts or audio logic.
local M={}
function M.new(param)
 local selected,sequence=nil,0
 local function value(name)return param('ALR56_'..name):get()end
 return function(contacts)
  local list={}
  for _,c in ipairs(contacts)do
   local warning=c.signal>=2 or c.threat
   if (value('SEARCH')>.5 or warning)and(value('UNKNOWN')>.5 or c.code~='U' or warning)then
    list[#list+1]=c
   end
  end
  if value('PRIORITY')>.5 then
   table.sort(list,function(a,b)
    local sa=(a.threat and 4 or a.signal);local sb=(b.threat and 4 or b.signal)
    if sa~=sb then return sa>sb end
    if a.power~=b.power then return a.power>b.power end
    return tostring(a.key)<tostring(b.key)
   end)
   -- Keep every lock/launch warning even when more than five exist.
   while #list>5 and list[#list].signal<2 and not list[#list].threat do table.remove(list)end
  end
  local n=value('HANDOFF_SEQ')
  local found
  for i,c in ipairs(list)do if c.key==selected then found=i end end
  if n~=sequence then
   sequence=n
   selected=#list>0 and list[((found or 0)%#list)+1].key or nil
  elseif not found then selected=nil end
  local selectedIndex=0
  for i,c in ipairs(list)do if c.key==selected then selectedIndex=i end end
  param('ALR56_SELECTED'):set(selectedIndex)
  local primary=selectedIndex
  if primary==0 then
   local best=-1
   for i,c in ipairs(list)do
    local score=(c.threat and 4 or c.signal)*10+c.power
    if score>best then best=score;primary=i end
   end
  end
  param('ALR56_PRIMARY'):set(primary)
  return list
 end
end
-- Spread only overlapping symbols. Received bearing and threat data stay intact.
local separationCache={}
function M.separate(x,y,placed,enabled,label,warning)
 -- Account for 175% text width and enclosing warning symbols, rather than
 -- rotating every contact clockwise by a fixed angle. This is a local layout
 -- adapter, not the unavailable native F16 RWR_ThreatPos implementation.
 local w=math.max(.12,math.min(4,#tostring(label or '15'))*.045+.025)
 local h=warning and .18 or .12
 if warning then w=math.max(w,.18)end
 local function fits(px,py)
  if math.sqrt(px*px+py*py)+math.max(w,h)>.98 then return false end
  for _,p in ipairs(placed)do
   if math.abs(px-p[1])<w+p[3]+.02 and math.abs(py-p[2])<h+p[4]+.02 then return false end
  end
  return true
 end
 local ix,iy,index=x,y,#placed+1
 local saved=separationCache[index]
 local reused=false
 -- If the scope was already saturated, retry only after its inputs change.
 if enabled and saved and saved.failed and saved.ix==x and saved.iy==y
  and saved.label==label and saved.warning==warning then
  reused=true
  for i,p in ipairs(placed)do local q=saved.prefix[i]
   if not q or p[1]~=q[1]or p[2]~=q[2]or p[3]~=q[3]or p[4]~=q[4]then reused=false;break end
  end
 end
 if enabled and not fits(x,y)and saved and saved.label==label and saved.warning==warning
  and math.abs(x-saved.ix)<.05 and math.abs(y-saved.iy)<.05 then
  local px,py=saved.x+x-saved.ix,saved.y+y-saved.iy
  if fits(px,py)then x,y=px,py;reused=true end
 end
 if enabled and not reused and not fits(x,y)then
  local best,bx,by
  -- Deterministic bounded search; choose the nearest collision-free position.
  for row=-16,16 do for col=-16,16 do
   local px,py=col*.05,row*.05
   local cost=(px-x)^2+(py-y)^2
   if (not best or cost<best)and fits(px,py)then best,bx,by=cost,px,py end
  end end
  if best then x,y=bx,by end
 end
 local cache={ix=ix,iy=iy,x=x,y=y,label=label,warning=warning}
 if enabled and not fits(x,y)then
  cache.failed=true;cache.prefix={}
  for i,p in ipairs(placed)do cache.prefix[i]={p[1],p[2],p[3],p[4]}end
 end
 separationCache[index]=cache
 placed[#placed+1]={x,y,w,h}
 return x,y
end
return M
