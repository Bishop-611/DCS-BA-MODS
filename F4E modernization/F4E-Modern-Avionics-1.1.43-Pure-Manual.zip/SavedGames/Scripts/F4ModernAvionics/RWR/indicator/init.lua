dofile(LockOn_Options.common_script_path..'devices_defs.lua')
indicator_type=indicator_types.COMMON
purposes={render_purpose.SCREENSPACE_INSIDE_COCKPIT,render_purpose.HUD_ONLY_VIEW}
page_subsets={[1]=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/RWR/indicator/page.lua]])}
pages={{1}};init_pageID=1
