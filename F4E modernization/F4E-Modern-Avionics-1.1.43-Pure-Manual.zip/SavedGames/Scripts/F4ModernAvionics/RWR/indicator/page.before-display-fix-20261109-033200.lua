dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/RWR/common.lua]]))
dofile(LockOn_Options.script_path..'Displays/common.lua')
SetCustomScale(1)
local nativeAdd=Add
function Add(e)
 e.screenspace=ScreenType.SCREENSPACE_TRUE
 e.isdraw=true;e.isvisible=true;e.additive_alpha=false
 if e.element_params then
  for i,n in ipairs(e.element_params)do
   if not n:match('^EXFULL_') and not n:match('^RWR_CONTACT_')then e.element_params[i]='EXFULL_'..n end
  end
 end
 nativeAdd(e)
end
local root=CreateElement 'ceSimple';root.name='EXFULL_SCREEN';root.init_pos={.65,-.5,0}
root.element_params={'EXFULL_RWR_POWER'};root.controllers={{'parameter_in_range',0,.5,1.5}};Add(root)
XF={k=.32,root=root}
poly({{-1,-1},{-1,1},{1,1},{1,-1}},BLACK)
-- This is the original RWR page. The only omitted control is the LAD button
-- that opens the unrelated countermeasure-program editor on an F15 touchscreen.
function lad_legend()end
dofile(LockOn_Options.script_path..'Displays/formats/TEWS.lua')
EXFULL_log('DISPLAY_INIT original_TEWS_format=true independent_screen=true')
