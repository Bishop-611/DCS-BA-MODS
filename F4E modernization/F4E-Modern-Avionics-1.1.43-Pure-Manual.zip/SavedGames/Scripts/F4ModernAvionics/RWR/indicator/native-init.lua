-- Preserve both native display classes and their render targets/dependencies.
dofile(LockOn_Options.script_path..'Scripts/RWR/indicator/init_46.lua')
page_subsets[RWR]=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/RWR/indicator/page.lua]])
-- The added receiver owns power visibility. Native page selection must not
-- hide a valid new display because the native receiver has a long timer.
pages={{BASE,RWR},{BASE,RWR},{BASE,RWR}}
init_pageID=RWR
