dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/RWR/common.lua]]))
local nativeMaterial,nativeFont=MakeMaterial,MakeFont
local colors={}
function MakeMaterial(texture,rgba)local m=nativeMaterial(texture,rgba);colors[m]=rgba;return m end
function MakeFont(desc,rgba,...)local m=nativeFont(desc,rgba,...);colors[m]=rgba;return m end
dofile(LockOn_Options.script_path..'Displays/common.lua')
SetCustomScale(1)
BRT_PARAM='ALR56_BRIGHTNESS'
local nativeAdd,nativeCreate=Add,CreateElement
local elementKinds=setmetatable({},{__mode='k'})
-- Build Lua descriptors, then write once into native userdata. Native element
-- property getters do not necessarily return the Lua tables previously assigned.
function CreateElement(kind)
 local descriptor={};elementKinds[descriptor]=kind;return descriptor
end
function Add(e)
 e.screenspace=ScreenType.SCREENSPACE_TRUE
 e.isdraw=true;e.isvisible=true;e.additive_alpha=false
 -- The transplanted texture font uses an 8-unit nominal cell. In this
 -- screen-space indicator normalize glyph dimensions without changing
 -- positions, mesh geometry, or parameter-driven contact movement.
 if elementKinds[e]=='ceStringPoly' and e.stringdefs then
  local d=e.stringdefs
  e.stringdefs={1.75*d[1]/TEXFONT_SIZE[1],1.75*d[2]/TEXFONT_SIZE[2],d[3],d[4]}
 end
 local rgba=colors[e.material]
 if rgba and math.max(rgba[1],rgba[2],rgba[3])>0 then
  local params,controllers={},{}
  for i,n in ipairs(e.element_params or {})do params[i]=n end
  for _,c in ipairs(e.controllers or {})do if c[1]~='opacity_using_parameter'then controllers[#controllers+1]=c end end
  params[#params+1]='ALR56_BRIGHTNESS_LEVEL'
  for level=0,32 do local g=level/32
   controllers[#controllers+1]={'change_color_when_parameter_equal_to_number',#params-1,level,rgba[1]/255*g,rgba[2]/255*g,rgba[3]/255*g}
  end
  e.element_params=params;e.controllers=controllers;e.change_opacity=false
 end
 if e.element_params then
  for i,n in ipairs(e.element_params)do
   if not n:match('^EXFULL_') and not n:match('^RWR_CONTACT_')then e.element_params[i]='EXFULL_'..n end
  end
 end
 local native=nativeCreate(assert(elementKinds[e]))
 -- Native setters may bind immediately: establish parameters before controllers.
 for k,v in pairs(e)do
  if k~='element_params' and k~='controllers' then native[k]=v end
 end
 if e.element_params then native.element_params=e.element_params end
 if e.controllers then native.controllers=e.controllers end
 nativeAdd(native)
end
local root=CreateElement 'ceSimple';root.name='ALR56M_SCREEN';root.init_pos={0,0,0}
root.element_params={'EXFULL_RWR_POWER'};root.controllers={{'parameter_in_range',0,.5,1.5}};Add(root)
XF={k=1,root=root}
poly({{-1,-1},{-1,1},{1,1},{1,-1}},BLACK)
dofile(EXFULL_ROOT..'indicator/standalone.lua')
