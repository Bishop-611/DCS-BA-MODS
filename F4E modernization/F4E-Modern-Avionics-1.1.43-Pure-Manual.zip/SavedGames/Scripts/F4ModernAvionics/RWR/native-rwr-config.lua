-- Retain the native class, page dependencies and Lua-state lifetime.
dofile(LockOn_Options.script_path..'Scripts/RWR/rwr.lua')
device_timer_dt=172800.0
-- Requested native period, not a claim that its internal event queue is disabled.
