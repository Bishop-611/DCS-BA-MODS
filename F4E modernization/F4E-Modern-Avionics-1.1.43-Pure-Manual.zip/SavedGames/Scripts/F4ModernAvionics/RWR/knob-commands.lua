-- Existing F-4 controls; device 67 is rerouted to receiver 202, without new keys.
return {
 [3001]={field='brightness',kind='absolute',arg=976},[3023]={field='brightness',kind='step',arg=976},[3046]={field='brightness',kind='axis',arg=976},
 [3002]={field='volume',kind='absolute',arg=977},[3024]={field='volume',kind='step',arg=977},[3045]={field='volume',kind='axis',arg=977},
 [3026]={field='brightness',kind='absolute',arg=2625},[3027]={field='brightness',kind='step',arg=2625},[3048]={field='brightness',kind='axis',arg=2625},
 [3025]={field='volume',kind='absolute',arg=2624},[3028]={field='volume',kind='step',arg=2624},[3047]={field='volume',kind='axis',arg=2624},
 [3049]={field='brightness',kind='absolute',arg=975},[3050]={field='brightness',kind='step',arg=975},[3053]={field='brightness',kind='axis',arg=975},
 [3051]={field='brightness',kind='absolute',arg=2809},[3052]={field='brightness',kind='step',arg=2809},[3054]={field='brightness',kind='axis',arg=2809}
}
