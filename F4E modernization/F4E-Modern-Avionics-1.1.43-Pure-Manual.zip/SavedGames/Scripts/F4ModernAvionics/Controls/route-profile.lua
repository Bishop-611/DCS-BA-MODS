-- Runs inside the input-profile environment after its original binds are built.
-- Original options keep their names and physical combinations; no new bindings.
local map=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/Controls/input-map.lua]]))
local rwrKnobs=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/RWR/knob-commands.lua]]))
return function(res)
    for _,group in ipairs({res.keyCommands or {},res.axisCommands or {}}) do
        for _,bind in ipairs(group) do
            if bind.cockpit_device_id~=203 then
                for _,entry in ipairs(map) do
                    if bind.cockpit_device_id==entry.device and
                        (bind.down==entry.command or bind.action==entry.command or bind.pressed==entry.command) then
                        local target=bind.action and (entry.axis_routed or entry.routed) or entry.routed
                        for _,field in ipairs({'down','up','pressed','action'}) do
                            if bind[field]==entry.command then bind[field]=target end
                        end
                        bind.cockpit_device_id=203
                        break
                    end
                end
                -- Original radar controls keep their names/bindings but terminate at a sink.
                if bind.cockpit_device_id==52 then bind.cockpit_device_id=204 end
            end
        end
    end
    for _,group in ipairs({res.keyCommands or {},res.axisCommands or {}})do
        for _,bind in ipairs(group)do
            if bind.cockpit_device_id==67 then
                for _,field in ipairs({'down','up','pressed','action'})do
                    if rwrKnobs[bind[field]]then bind.cockpit_device_id=202;break end
                end
            end
        end
    end
    return res
end
