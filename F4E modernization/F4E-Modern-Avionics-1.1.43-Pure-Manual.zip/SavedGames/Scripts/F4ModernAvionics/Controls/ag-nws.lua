-- Reuses the existing NWS input: long hold toggles; short press designates/cancels.
local M={}
function M.new(native)
 local c={down=false,long=false,started=0}
 function c:tick(now,ag)
  if not ag then self.down=false;self.long=false;return end
  if self.down and not self.long and now-self.started>=.6 then
   self.long=true;if native then native.ag_command(1)end
  end
 end
 function c:command(value,now,ag)
  if not ag then self.down=false;self.long=false;return false end
  local pressed=value>.5
  if pressed and not self.down then self.down=true;self.long=false;self.started=now
  elseif not pressed and self.down then
   self:tick(now,true)
   if not self.long and native then native.ag_command(2)end
   self.down=false;self.long=false
  end
  return true
 end
 return c
end
return M
