local dev=GetSelf()
local reportedLevel=-1
local display=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/Controls/display-controls.lua]])).router(
 function(name,value)get_param_handle(name):set(value)end,
 function(arg,value)pcall(set_cockpit_draw_argument_value,arg,value)end,
 function(command,value)GetDevice(52):performClickableAction(command,value,false)end,
 function()local ok,v=pcall(get_cockpit_draw_argument_value,2599);return ok and type(v)=='number'and v>.75 end)
local displayCommands={}
for _,id in ipairs({3031,3053,3065,3080,3028,3029,3030,3051,3052,3070,3095,3096,3097,
 3023,3025,3032,3033,3045,3046,3048,3102,3105,3106,3107,
 3024,3026,3047,3049,3103,3104,3066,3067,3098,3068,3069,3099,3112})do displayCommands[id]=true end
for command=3001,3999 do dev:listen_command(command) end
need_to_be_closed=false
make_default_activity(.02)
local transmitterPower={[3004]=true,[3038]=true,[3057]=true,[3086]=true}
function SetCommand(command,value)
    if transmitterPower[command] then
        log.write('F4_SIMPLE_RADAR_BLOCK',log.INFO,'BLOCKED native transmitter power command='..tostring(command))
        return
    end
    local ok,tv=pcall(get_cockpit_draw_argument_value,2599)
    if ok and type(tv)=='number'and tv>.75 then
        GetDevice(52):performClickableAction(command,value,false);return
    end
    if display:command(command,value)then
        local ok,level=pcall(function()return get_param_handle('F4_SR_SCREEN_FOREGROUND_LEVEL'):get()end)
        if ok and level~=reportedLevel then
            reportedLevel=level
            log.write('F4_SIMPLE_RADAR_BLOCK',log.INFO,'DISPLAY_RGB command='..tostring(command)..' input='..tostring(value)..' level='..tostring(level)..'/32')
        end
        return
    end
    -- Native DSCG Radar/Off/TV selection controls the video compositor, not
    -- the radar transmitter. Keep the original four UI routes functional.
    if displayCommands[command] then
        if command==3031 or command==3053 or command==3065 or command==3080 then
            log.write('F4_SIMPLE_RADAR_BLOCK',log.INFO,'DISPLAY_MODE command='..tostring(command)..' value='..tostring(value))
        end
        GetDevice(52):performClickableAction(command,value,false)
        return
    end
    log.write('F4_SIMPLE_RADAR_BLOCK',log.INFO,'IGNORED original radar control '..tostring(command)..' value='..tostring(value))
end
function post_initialize()
    display:initialize()
    log.write('F4_SIMPLE_RADAR_BLOCK',log.INFO,'Original radar controls blocked; native DSCG mode and display adjustments forwarded')
end
function update()display:tick()end
