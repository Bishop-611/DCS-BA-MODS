-- Executed by mainpanel_init.lua, not by an avLuaDevice.
for i,nm in ipairs({5,10,25,50}) do
    local gauge=CreateGauge('parameter')
    gauge.parameter_name='F4_SR_RANGE_LIGHT_'..nm
    gauge.arg_number=2532+i
    gauge.input={0,1}
    gauge.output={0,1}
end
