-- Shared once by the native OFF and RADAR page definitions.
dofile(LockOn_Options.common_script_path..'elements_defs.lua')
SetCustomScale(1)
local scale=.85
local root=CreateElement 'ceSimple'
root.name='F4_SR_CURSOR_SHARED_ROOT';root.init_pos={0,0,0}
root.element_params={'F4_SR_AA_ACTIVE'}
root.controllers={{'parameter_in_range',0,.5,1.5}}
root.screenspace=ScreenType.SCREENSPACE_TRUE;Add(root)
local tdc=CreateElement 'ceSimple'
tdc.name='F4_SR_CURSOR_SHARED_POSITION';tdc.parent_element=root.name;tdc.init_pos={0,0,0}
tdc.element_params={'F4_SR_TDC_SHOW','F4_SR_TDC_X','F4_SR_TDC_Y'}
tdc.controllers={{'parameter_in_range',0,.5,1.5},{'move_left_right_using_parameter',1,scale},{'move_up_down_using_parameter',2,scale}}
tdc.screenspace=ScreenType.SCREENSPACE_TRUE;Add(tdc)
local cursor=CreateElement 'ceMeshPoly'
cursor.name='F4_SR_CURSOR_SHARED_MESH';cursor.parent_element=tdc.name
cursor.primitivetype='triangles';cursor.material=MakeMaterial(nil,{50,255,90,255})
local vertices,indices,controllers={},{},{}
cursor.init_pos={0,0,0}
for _,center in ipairs({-.07,.07})do
 local n=#vertices
 for _,p in ipairs({{center-.006,-.054},{center+.006,-.054},{center+.006,.054},{center-.006,.054}})do
  vertices[#vertices+1]={p[1]*scale,p[2]*scale}
 end
 for _,i in ipairs({n+2,n+1,n,n+3,n+2,n})do indices[#indices+1]=i end
end
cursor.vertices=vertices;cursor.indices=indices
cursor.element_params={'F4_SR_SCREEN_CURSOR_LEVEL'}
for level=0,32 do local g=level/32
 controllers[#controllers+1]={'change_color_when_parameter_equal_to_number',0,level,50/255*g,g,90/255*g}
end
cursor.controllers=controllers
cursor.screenspace=ScreenType.SCREENSPACE_TRUE
cursor.isdraw=true;cursor.isvisible=true;cursor.additive_alpha=false
cursor.use_mipfilter=false;cursor.change_opacity=false
Add(cursor)
