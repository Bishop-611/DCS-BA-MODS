-- Publish to mainpanel parameter gauges; direct draw setters are not reliable
-- for these native-owned lamp arguments.
local ranges={5,10,25,50}
return function(range_nm,active,write)
    if type(write)~='function' then return end
    for i,nm in ipairs(ranges) do
        write('F4_SR_RANGE_LIGHT_'..nm,active and range_nm==nm and 1 or 0)
    end
end
