F4E Modern Avionics 1.1.43 - Pure Manual Installation
====================================================
No PowerShell, command prompt or EXE is needed. Use File Explorer and a text
editor such as Notepad. This package targets DCS 2.9.31.29434 only.

DCS_ROOT means YOUR DCS World installation folder.
PROFILE means YOUR active Saved Games DCS profile (DCS, DCS.openbeta, etc.).
No computer name, username or fixed personal path is required in these files.
Runtime paths are resolved from the active profile by DCS itself.

BEFORE STARTING
Close DCS. If the EXE/script-managed edition is currently installed, restore it
with its original manager first. Do not layer this unmanaged edition over an
installer-managed copy. This package does not create installer receipts.
Keep a backup of every file listed below OUTSIDE DCS and the ZIP. Preserve
Niko and other mods' existing content. Do not proceed if a FIND text is absent
or appears more than once: the game version or file modifications may differ.

1. BACK UP THE FILES YOU WILL CHANGE
Under DCS_ROOT:
 Mods/aircraft/F-4E/Cockpit/device_init.lua
 Mods/aircraft/F-4E/Cockpit/mainpanel_init.lua
 Mods/aircraft/F-4E/Cockpit/clickabledata.lua
 Mods/aircraft/F-4E/Input/F-4E-Pilot/keyboard/default.lua
 Mods/aircraft/F-4E/Input/F-4E-Pilot/joystick/default.lua
 Mods/aircraft/F-4E/fxo/DSCG.fxo
Under PROFILE:
 Scripts/Export.lua (if it exists)
 Config/Input/F-4E-45MC (your bindings)
Record whether each file/folder already existed; do not discard other mods.

2. COPY THE PROVIDED FILES
Copy the CONTENTS of the package's DCS folder into DCS_ROOT.
Copy the CONTENTS of the package's SavedGames folder into PROFILE.
The result must include PROFILE/Scripts/F4ModernAvionics and
PROFILE/Mods/tech/F4ModernAvionicsRwrResources/entry.lua.
Do not create an extra SavedGames folder inside your profile.

3. EDIT device_init.lua
Open DCS_ROOT/Mods/aircraft/F-4E/Cockpit/device_init.lua in a text editor.
Apply all FOUR exact replacements in Merge-Snippets/device_init-REPLACEMENTS.txt.
Then append the contents of Merge-Snippets/device_init-APPEND.txt at the end.
Preserve every unrelated line, including the Niko block.
Device IDs 200 through 206 must not already be assigned by another mod.

4. EDIT mainpanel_init.lua AND clickabledata.lua
Append Merge-Snippets/mainpanel_init-APPEND.txt to mainpanel_init.lua.
Append Merge-Snippets/clickabledata-APPEND.txt to clickabledata.lua.
Keep the existing Niko panel block and other integrations.

5. EDIT BOTH PILOT INPUT PROFILES
In BOTH keyboard/default.lua and joystick/default.lua listed above, replace
only the final line "return res" with Merge-Snippets/input-REPLACE-RETURN.txt.
Do not append code after return. Keep the rest of each file unchanged.

6. EDIT Export.lua
Open PROFILE/Scripts/Export.lua, or create it if absent.
Append Merge-Snippets/Export-APPEND.txt. Preserve existing export hooks.
Save as UTF-8 Lua text, not Export.lua.txt. Append each snippet only once.

7. PRESERVE CUSTOM INPUT BINDINGS
Routed cockpit commands use new IDs. For existing custom .diff.lua files under
PROFILE/Config/Input/F-4E-45MC, INPUT-BINDING-MAP.tsv lists OLD_ID then NEW_ID.
In a text editor, replace exact quoted keys ["OLD_ID"] with ["NEW_ID"] where
present. Do not replace substrings or unrelated numbers. If both keys already
exist, resolve the conflict in DCS Controls instead of blindly replacing them.
Alternatively reassign the affected Cage, NWS, HCU and RWR/radar controls in
DCS Controls after installation. Keep your original bindings backup.

8. START DCS AND CHECK
In A/A radar operation, short Cage presses cycle 5/10/25/50 NM and the matching
range lamp. Hold Cage for 10 NM ACM. Check HUD, radar, RWR and your bindings.
Pure-manual path resolution is syntax/mapping checked offline; installer tests
apply to the EXE edition. No separate pure-manual in-game test is claimed.

UNINSTALL / SWITCH TO THE EXE EDITION
Close DCS. Reverse the four device_init replacements, remove only the exact
F4_PURE_MANUAL marked blocks, and restore the two final input return lines.
Restore DSCG.fxo from your backup. Reverse any input key remapping (new to old)
or restore your bindings backup if there have been no later binding changes.
Remove Scripts/F4ModernAvionics and Mods/tech/F4ModernAvionicsRwrResources only
if they were added by this manual installation. If Export.lua was newly created,
remove it only if it contains no other content after removing our block.
For shared files, restore whole backups only if no later edits were made;
otherwise remove/reverse only this mod's changes to preserve those edits.
The EXE manager cannot automatically remove an unmanaged manual installation.
After restoring the native baseline, you can install the EXE edition normally.

GAME UPDATES
DCS repair/update may overwrite these changes. Restore this manual version
before updating, then obtain a package supporting the new game version.
Do not apply these replacements blindly to an unsupported DCS version.
Multiplayer integrity-check compatibility is not claimed.
