-- HARM plan page: simple cross, no rings, angle scales or range grid.
-- Staged module: caller supplies active/context parameters and validated target positions.
dofile(LockOn_Options.common_script_path..'elements_defs.lua')
SetCustomScale(1)
local scale=1
local brightness_gain=2 -- HARM page only; existing screen controls remain authoritative.
local green=MakeMaterial(nil,{50,255,90,255})
local serial=0
local function add(kind,desc)
 serial=serial+1;desc.name=desc.name or ('F4_HARM_PLAN_'..serial)
 desc.screenspace=ScreenType.SCREENSPACE_TRUE;desc.isdraw=true;desc.isvisible=true
 desc.additive_alpha=false;desc.use_mipfilter=false
 local e=CreateElement(kind)
 for k,v in pairs(desc)do if k~='element_params'and k~='controllers'then e[k]=v end end
 if desc.element_params then e.element_params=desc.element_params end
 if desc.controllers then e.controllers=desc.controllers end
 Add(e);return desc.name
end
local root=add('ceSimple',{name='F4_HARM_PLAN_ROOT',init_pos={0,0,0},
 element_params={'F4_RADAR_PLAN_PAGE'},controllers={{'parameter_in_range',0,.5,1.5}}})
add('ceMeshPoly',{parent_element=root,init_pos={0,0,0},vertices={{-1,-1},{1,-1},{1,1},{-1,1}},
 indices={0,1,2,0,2,3,2,1,0,3,2,0},primitivetype='triangles',material=MakeMaterial(nil,{0,0,0,255})})
local textStyle=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/text-style.lua]]))
local font=textStyle.font
-- Only status annotations shrink; emitter identifiers retain their accepted size.
local annotationDefs={textStyle.stringdefs[1]*.5,textStyle.stringdefs[2]*.5,textStyle.stringdefs[3],textStyle.stringdefs[4]}
-- A stale station can briefly lag the physical selector. Show the page without
-- presenting the previous page's data or promising a completed input.
local syncControls={{'parameter_in_range',0,.5,1.5}}
for level=0,32 do
 local gain=level/32*brightness_gain
 syncControls[#syncControls+1]={'change_color_when_parameter_equal_to_number',1,level,50/255*gain,gain,90/255*gain}
end
add('ceStringPoly',{parent_element=root,init_pos={0,.20,0},material=font,value='SYNC',alignment='CenterCenter',
 stringdefs=annotationDefs,change_opacity=false,element_params={'F4_RADAR_STATION_SYNC','F4_SR_SCREEN_FOREGROUND_LEVEL'},controllers=syncControls})
local geometry=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/plan-view.lua]]))
local movingPrefix
local function line(a,b,width,parent,bright)
 local dx,dy=b[1]-a[1],b[2]-a[2];local length=math.sqrt(dx*dx+dy*dy)
 local nx,ny=-dy/length*width,dx/length*width
 local vertices={{(a[1]+nx)*scale,(a[2]+ny)*scale},{(b[1]+nx)*scale,(b[2]+ny)*scale},
 {(b[1]-nx)*scale,(b[2]-ny)*scale},{(a[1]-nx)*scale,(a[2]-ny)*scale}}
 local controls={};for i=0,32 do local v=i/32*brightness_gain
  controls[#controls+1]={'change_color_when_parameter_equal_to_number',0,i,50/255*v,v,90/255*v}
 end
 local params={bright or 'F4_SR_SCREEN_FOREGROUND_LEVEL'}
 if movingPrefix then params[2]=movingPrefix..'X';params[3]=movingPrefix..'Y';controls[#controls+1]={'move_left_right_using_parameter',1,scale};controls[#controls+1]={'move_up_down_using_parameter',2,scale}end
 add('ceMeshPoly',{parent_element=parent or root,init_pos={0,0,0},vertices=vertices,
 indices={2,1,0,3,2,0},primitivetype='triangles',material=green,change_opacity=false,
 element_params=params,controllers=controls})
end
line({-.9975,0},{.9975,0},.004,root,'F4_SR_SCREEN_FOREGROUND_LEVEL')
line({0,-.9975},{0,.9975},.004,root,'F4_SR_SCREEN_FOREGROUND_LEVEL')
for i=1,16 do
 local p='F4_HARM_T'..i..'_';movingPrefix=p
 local target=add('ceSimple',{parent_element=root,init_pos={0,0,0},element_params={p..'SHOW'},
 controllers={{'parameter_in_range',0,.5,1.5}}})
 -- Same typed numeric/text split used by the established RWR page.
 for numeric=0,1 do
  local labelControls={{'parameter_in_range',4,numeric-.1,numeric+.1},{'text_using_parameter',0,0},{'move_left_right_using_parameter',2,scale},{'move_up_down_using_parameter',3,scale}}
  for level=0,32 do local gain=level/32*brightness_gain;labelControls[#labelControls+1]={'change_color_when_parameter_equal_to_number',1,level,50/255*gain,gain,90/255*gain}end
  add('ceStringPoly',{parent_element=target,init_pos={0,0,0},material=font,formats={numeric==1 and '%.0f' or '%s'},alignment='CenterCenter',
  stringdefs=textStyle.stringdefs,element_params={p..(numeric==1 and 'NUM' or 'TXT'),'F4_SR_SCREEN_FOREGROUND_LEVEL',p..'X',p..'Y',p..'CN'},controllers=labelControls})
 end
 -- The display list puts the selected contact in slot 1 (see HARM/device.lua).
 if i==1 then
  local selected=add('ceSimple',{parent_element=target,init_pos={0,0,0},element_params={p..'SELECTED'},controllers={{'parameter_in_range',0,.5,1.5}}})
  for _,annotation in ipairs({{'IN RNG','F4_HARM_IN_RANGE','LABEL_'},{'H-OFF','F4_HARM_HANDOFF_READY','LOWER_'}})do
   local controls={{'parameter_in_range',0,.5,1.5},{'move_left_right_using_parameter',2,scale},{'move_up_down_using_parameter',3,scale}}
   for level=0,32 do local gain=level/32*brightness_gain;controls[#controls+1]={'change_color_when_parameter_equal_to_number',1,level,50/255*gain,gain,90/255*gain}end
   add('ceStringPoly',{parent_element=selected,init_pos={0,0,0},material=font,value=annotation[1],alignment='CenterCenter',
   stringdefs=annotationDefs,element_params={annotation[2],'F4_SR_SCREEN_FOREGROUND_LEVEL',p..annotation[3]..'X',p..annotation[3]..'Y'},controllers=controls})
  end
  local h=geometry.frame_half
  line({-h,-h},{-h,h},.0032,selected);line({-h,h},{h,h},.0032,selected)
  line({h,h},{h,-h},.0032,selected);line({h,-h},{-h,-h},.0032,selected)
 end
end
