-- F-4-only HARM selection core. No native launch or file I/O in this module.
local M={};M.__index=M
local function finite(n)return type(n)=='number' and n==n and math.abs(n)<1e10 end
local function vector(p)return type(p)=='table' and finite(p.x)and finite(p.y)and finite(p.z)end
local function fresh(stamp,now)return finite(stamp)and stamp<=now+.1 and now-stamp<=.5 end
function M.new()return setmetatable({targets={},selected=nil,held=false,active=false,revision=0},M)end
function M:update(context,contacts,own,now)
 self.active=context.ag==true and context.radarDisplay==true and context.harm==true
 self.targets={}
 self.canDisplay=self.active and context.exportAllowed==true
 if not self.active or context.rwrPower~=true or context.exportAllowed~=true or not finite(now)then return end
 local seen={}
 for _,t in ipairs(contacts or {})do
  -- SP: no friend/foe classification. Only resolved, current RWR detections qualify.
  if t.detected==true and t.identityVerified==true
   and finite(t.id)and t.id>0 and t.id%1==0 and t.id<=4294967295 and fresh(t.stamp,now)
   and vector(t.position)and not seen[t.id] then
   seen[t.id]=true;self.targets[#self.targets+1]=t
  end
 end
 table.sort(self.targets,function(a,b)return a.id<b.id end)

end
function M:nws(value)
 local down=value>.5;local edge=down and not self.held;self.held=down
 if not self.active then return false end
 if edge and #self.targets>0 then
  local nextIndex=1;for i,t in ipairs(self.targets)do if t.id==self.selected then nextIndex=i%#self.targets+1;break end end
  local t=self.targets[nextIndex]
  self.selected=t.id
  self.remembered={id=t.id,stamp=t.stamp,position={x=t.position.x,y=t.position.y,z=t.position.z}}
  self.revision=self.revision+1
 end
 return true
end
function M:target()
 return self.canDisplay and self.remembered or nil
end
function M:handoff(context,now,allow_unassigned)
 local t=self.remembered
 if not self.active or context.ag~=true or context.radarDisplay~=true or context.harm~=true then return nil,'INACTIVE' end
 if context.masterArm~=true then return nil,'MASTER_SAFE'end
 if not context.stationVerified or not finite(context.station)or not ({[1]=true,[3]=true,[11]=true,[13]=true})[context.station] then return nil,'STATION_UNVERIFIED'end
 if not t then
  if allow_unassigned then return {mode='UNASSIGNED',station=context.station}end
  return nil,'NO_CURRENT_TARGET'
 end
 if context.rwrPower~=true or context.exportAllowed~=true then return nil,'DATA_UNAVAILABLE' end

 return {mode='SP',station=context.station,emitter=t.id,x=t.position.x,y=t.position.y,z=t.position.z,stamp=t.stamp,revision=self.revision}
end
return M
