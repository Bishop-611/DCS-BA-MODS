local M={receiver_lifetime=7.0} -- Matches the installed modern receiver EmitterLiveTime.
local pylons={1,3,11,13};local lamps={[1]=256,[3]=257,[11]=259,[13]=260}
local function finite(n)return type(n)=='number'and n==n and math.abs(n)<1e10 end
local function vector(p)return type(p)=='table'and finite(p.x)and finite(p.y)and finite(p.z)end
local function harm(s)
 if type(s)~='table'or not finite(s.count)or s.count<=0 or type(s.weapon)~='table'then return false end
 local w=s.weapon;return(w.level1 or w[1])==4 and(w.level2 or w[2])==4 and(w.level4 or w[4])==65
end
-- UI ownership is independent of the operational station from DCS. The five
-- panel lamps can represent multiple exported stores on a triple launcher.
local panelGroups={{256,1},{257,2,3,4},{258,7},{259,10,11,12},{260,13}}
local previousCount,holding,lastConfirmation
function M.resetPage()
 previousCount,holding,lastConfirmation=nil,false,nil
end
-- First inspect the amber ARM legends. The numbered station button lamps
-- can stay lit for other preselected racks at the same time.
local armLamps={262,263,264,265,266}
local function planPage(draw,stations,current)
 local seenHarm,seenOther,armed=false,false,false
 for index,group in ipairs(panelGroups)do
  if draw(armLamps[index])>.05 then
   armed=true
   for n=2,#group do
    local id=group[n]
    local item=stations[id]
    if item and finite(item.count) and item.count>0 then
     local isHarm=lamps[id]~=nil and harm(item)
     if id==current then return isHarm,false end
     if isHarm then seenHarm=true else seenOther=true end
    end
   end
  end
 end
 if armed then
  if seenHarm and seenOther then
   local selector=draw(273)
   return selector>=.10 and selector<=.17,false
  end
  return seenHarm,not seenOther and not seenHarm
 end
 local selector=draw(273)
 if selector<.10 or selector>.17 then return false,false end
 local selected=stations[current]
 local currentLoaded=selected and finite(selected.count) and selected.count>0
 local anyLamp,planLit,nativeLit=false,false,false
 for _,group in ipairs(panelGroups)do
  if draw(group[1])>.05 then
   anyLamp=true
   for index=2,#group do
    local id=group[index]
    local item=stations[id]
    if item and finite(item.count) and item.count>0 then
     local isPlan=lamps[id]~=nil and harm(item)
     if id==current then return isPlan,false end
     if isPlan then planLit=true else nativeLit=true end
    end
   end
  end
 end
 if not anyLamp and currentLoaded then return lamps[current]~=nil and harm(selected),false end
 -- A single identified type can bridge a lagging station report. Mixed
 -- indications without a matching current store leave native video in control.
 if nativeLit then return false,false end
 return planLit,not planLit
end
function M.capture(api,raw,now)
 local function call(name,...)if type(api[name])=='function'then local ok,v=pcall(api[name],...);if ok then return v end end end
 local own=call('LoGetSelfData');if not own or own.Name~='F-4E-45MC'or not vector(own.Position)then M.resetPage();return {{'OFF',now}}end
 local panel=call('GetDevice',0)
 local function draw(n)local ok,v=pcall(function()return panel:get_argument_value(n)end);return ok and finite(v)and v or -1 end
 local payload=call('LoGetPayloadInfo')or {};local stations=payload.Stations or {}
 local station=payload.CurrentStation;local counts={'C'}
 for _,p in ipairs(pylons)do counts[#counts+1]=stations[p]and stations[p].count or 0 end
 if not finite(station)or station==0 then
  station=0;local arm=draw(273);if arm>=.10 and arm<=.17 then
   for _,p in ipairs(pylons)do if draw(lamps[p])>.05 and harm(stations[p])then station=p;break end end
  end
 end
 local isHarm=lamps[station]~=nil and harm(stations[station]);local allowed=call('LoIsObjectExportAllowed')==true
 local ag=math.floor(draw(271)/.1666+.5)==3
 local screen=draw(2599)
 local radarDisplay=screen>=0 and screen<.25
 local p=own.Position
 -- One scalar sample at the existing 10 Hz Export cadence, only on the active
 -- HARM page. TAS is an explicit interface choice for the native launch table;
 -- it is not a claim that this reproduces an aircraft-specific HARM envelope.
 -- Missing speed must remain unknown, never a fabricated zero-speed solution.
 local speed=isHarm and ag and radarDisplay and call('LoGetTrueAirSpeed')or nil
 local speedValid=finite(speed)and speed>=0 and speed<=1500
 local rows={{'H',now,p.x,p.y,p.z,own.Heading or 0,station,isHarm and stations[station].count or 0,isHarm and 1 or 0,allowed and 1 or 0,ag and 1 or 0,radarDisplay and 1 or 0,speedValid and 1 or 0,speedValid and speed or 0},counts}
 -- Optional display field. Keep the existing operational station and flags intact.
 local page,gap=false,false
 if ag and radarDisplay then page,gap=planPage(draw,stations,payload.CurrentStation) end
 local remaining=0
 for _,id in ipairs(pylons)do
  if harm(stations[id]) then remaining=remaining+stations[id].count end
 end
 -- Keep the display across a short station-lamp gap. The quantity and
 -- panel can change on separate frames. A confirmed native selection wins.
 if remaining==0 or not (page or gap) then
  M.resetPage()
 else
  if page then lastConfirmation=now end
  if lastConfirmation and now>=lastConfirmation and now-lastConfirmation<=.35 then
   if previousCount and remaining<previousCount then holding=true end
  elseif not holding then lastConfirmation=nil end
 end
 previousCount=remaining
 rows[1][15]=page and 1 or 0
 if gap and (holding or lastConfirmation) then rows[1][16]=1 end
 if not(isHarm and ag and radarDisplay and allowed)then return rows end
 local header=raw[1]
 if not header or header[1]~='R'or not finite(header[2])or now-header[2]<-.1 or now-header[2]>.3 or header[3]~=1 then return rows end
 local seen={}
 for i=2,math.min(17,#raw)do
  local r=raw[i];local id=r[1];local age=r[3]
  if finite(id)and id>0 and id%1==0 and id<=4294967295 and type(r[2])=='string'and finite(age)and age>=0 and age+math.max(0,now-header[2])<=M.receiver_lifetime and finite(r[4])and r[4]>0 and finite(r[5])and r[5]>=.5 and not seen[id]then
   local object=call('LoGetObjectById',id)
   -- SOURCE is not assumed to be a world ID unless the exported unit type matches.
   if object and object.Name==r[2]and vector(object.Position)then
    seen[id]=true;local q=object.Position;rows[#rows+1]={'T',id,q.x,q.y,q.z,now}
   end
  end
 end
 return rows
end
function M.decode(rows)
 local r=rows[1];if not r or r[1]~='H'then return nil end
 for i=2,12 do if not finite(r[i])then return nil end end
 local f={time=r[2],own={position={x=r[3],y=r[4],z=r[5]},heading=r[6]},station=r[7],count=r[8],harm=r[9]==1,allowed=r[10]==1,ag=r[11]==1,radarDisplay=r[12]==1,counts={},contacts={}}
 if r[15]==0 or r[15]==1 then f.planPage=r[15]==1 else f.planPage=f.harm end
 if r[16]==1 then f.keepDisplay=true end
 -- Keep legacy H12 frames usable for target display and handoff. Only the
 -- range cue requires the additional, validated H14 speed sample.
 if r[13]==1 and finite(r[14])and r[14]>=0 and r[14]<=1500 then f.own.speed=r[14]end
 local counts=rows[2];if not counts or counts[1]~='C'then return nil end
 for i,p in ipairs(pylons)do if not finite(counts[i+1])then return nil end;f.counts[p]=counts[i+1]end
 for i=3,math.min(18,#rows)do local t=rows[i]
  if t[1]=='T'and finite(t[2])and finite(t[3])and finite(t[4])and finite(t[5])and finite(t[6])then
   f.contacts[#f.contacts+1]={id=t[2],position={x=t[3],y=t[4],z=t[5]},stamp=t[6],detected=true,identityVerified=true}
  end
 end
 return f
end
return M
