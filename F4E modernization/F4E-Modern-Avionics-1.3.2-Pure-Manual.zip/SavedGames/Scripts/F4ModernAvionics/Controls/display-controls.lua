-- Read the original pilot/WSO screen controls. No additional input bindings.
local M={}
local function clamp(x)return math.max(0,math.min(1,x))end
function M.new(read,set)
 local values={brightness=.5,contrast=.5,scale=.5,grid=.5,cursor=.5,offset=.5}
 local slots={{1206,'brightness',true},{1402,'brightness'},{1203,'contrast',true},{1400,'contrast'},
 {1202,'scale',true},{2672,'scale'},{334,'grid',true},{1401,'cursor',true},{1403,'offset',true}}
 local previous,output={},{}
 return function()
  for _,slot in ipairs(slots)do
   local ok,v=pcall(read,slot[1])
   if ok and type(v)=='number'and v==v then
    v=clamp(v)
    if (previous[slot[1]]==nil and slot[3])or(previous[slot[1]]~=nil and math.abs(previous[slot[1]]-v)>1e-5)then values[slot[2]]=v end
    previous[slot[1]]=v
   end
  end
  local b=clamp(values.brightness)
  local foreground=clamp(b*values.contrast*2)
  local result={F4_SR_SCREEN_FOREGROUND=foreground,F4_SR_SCREEN_GRID=clamp(foreground*(1.25-.5*values.contrast)*values.grid*2),
   F4_SR_SCREEN_TEXT=foreground*clamp(values.scale*2),F4_SR_SCREEN_CURSOR=foreground*clamp(values.cursor*2),
   F4_SR_SCREEN_OFFSET=foreground*clamp(values.offset*2)}
  for k,v in pairs(result)do
   if output[k]~=v then output[k]=v;set(k,v);set(k..'_LEVEL',math.floor(v*32+.5))end
  end
 end
end
-- Own display controls in radar mode; the native video gain must not also
-- amplify the inserted vector page. Native TV keeps its original controls.
function M.router(set,draw,forward,screenSource,read,birth)
 local args={};for _,id in ipairs({1206,1402,1203,1400,1202,2672,334,1401,1403})do args[id]=.5 end
 local cold=birth=='GROUND_COLD'
 args[1206]=cold and 0 or .8;args[1402]=args[1206]
 -- Keep the birth defaults only if the native panel has no readable positions.
 local observing=type(read)=='function'
 local bootTicks=0
 local touched={}
 local positions={1206,1402,1203,1400,1202,2672,334,1401,1403}
 local shared={{1206,1402},{1203,1400},{1202,2672}}
 local samples={}
 local panelSeen=false
 local function samplePanel()
  if not observing then return false end
  local populated=false
  for _,id in ipairs(positions)do
   local ok,v=pcall(read,id)
   if ok and type(v)=='number' and v==v and v>=0 and v<=1 then
    samples[id]=v
    if v>0 and not touched[id] then populated=true end
   else samples[id]=nil end
  end
  panelSeen=panelSeen or populated
  if panelSeen or cold then
   for _,id in ipairs(positions)do
    if samples[id]~=nil and not touched[id] then args[id]=samples[id] end
   end
   -- The shared display follows the front knob at birth. Both seats can
   -- still take ownership with their first routed adjustment.
   for _,pair in ipairs(shared)do
    local front,rear=pair[1],pair[2]
    local value=samples[front] or samples[rear]
    if not touched[front] and value~=nil then args[front],args[rear]=value,value end
   end
  end
  return panelSeen
 end
 local specs={}
 local function family(ids,positions)
  for i,id in ipairs(ids)do specs[id]={positions=positions,kind=i==1 and 'absolute' or(i==2 and 'step' or 'axis')}end
 end
 family({3029,3052,3097},{1206,1402});family({3025,3048,3106},{1206,1402})
 family({3028,3051,3096},{1203,1400});family({3023,3046,3105},{1203,1400})
 family({3030,3070,3095},{1202,2672});family({3033,0,3107},{1202,2672})
 family({3032,3045,3102},{334});family({3024,3047,3103},{1401});family({3026,3049,3104},{1403})
 specs[0]=nil
 local publish=M.new(function(id)return args[id]end,set)
 local lastTV,lastRadar
 local sendingNative=false
 local function sendNative(command,value)
  sendingNative=true
  local ok,err=pcall(forward,command,value)
  sendingNative=false
  if not ok then error(err,0)end
 end
 -- Track the native gain independently of the physical selector. At birth
 -- there has been no transition, so its current setting is unknown.
 local nativeGainSource
 local function nativeBrightness(id)return id==1206 or id==1402 end
 local gains={{1206,3029},{1402,3025},{1203,3028},{1400,3023}}
 local function source()
  local tv,radar=screenSource()
  local enteringTV=lastTV==false and tv
  local enteringRadar=radar and nativeGainSource~='radar' and (not observing or nativeGainSource=='tv')
  local radarChanged=lastRadar~=radar
  lastTV,lastRadar=tv,radar
  if radarChanged then set('F4_SR_SCREEN_RADAR',radar and 1 or 0)end
  if tv then nativeGainSource='tv' elseif enteringRadar then nativeGainSource='radar' end
  if enteringTV or enteringRadar then observing=false end
  if enteringTV then
   -- Set absolute gain before forwarding a possible first increment in TV.
   for _,g in ipairs(gains)do sendNative(g[2],args[g[1]])end
  elseif enteringRadar then
   -- Contrast is neutral in RADAR. Its shader already uses the vector
   -- brightness, so the physical brightness controls can follow the panel.
   for _,g in ipairs(gains)do
    sendNative(g[2],nativeBrightness(g[1]) and args[g[1]] or .5)
   end
  end
  return tv
 end
 local c={}
 local function syncBrightnessKnob(id)
  if not touched[id] or not read then return end
  local ok,pose=pcall(read,id)
  if ok and type(pose)=='number' and math.abs(pose-args[id])>0.00001 then
   pcall(draw,id,args[id])
  end
 end
 local function paint(tv)
  publish()
  syncBrightnessKnob(1206)
  syncBrightnessKnob(1402)
  if not tv then
   for id,v in pairs(args)do if not nativeBrightness(id) and (not observing or touched[id])then draw(id,v)end end
  end
 end
 function c:command(command,value)
  local spec=specs[command];if not spec then return false end
  -- A native clickable action may notify this listener before returning.
  if sendingNative then return true end
  if spec.kind~='step' then samplePanel()end
  local tv=source()
  local old=args[spec.positions[1]]
  local v=spec.kind=='step' and old+value or(spec.kind=='axis' and (value+1)*.5 or value)
  for _,id in ipairs(spec.positions)do args[id]=clamp(v);touched[id]=true end
  if nativeBrightness(spec.positions[1]) then
   -- Send native absolute positions to both modeled knobs. A drawing override
   -- can be replaced on the next native animation update.
   sendNative(3029,args[1206])
   sendNative(3025,args[1402])
  elseif tv then sendNative(command,value)end
  paint(tv);return true
 end
 function c:tick()
  local populated=samplePanel()
  local tv=source()
  if observing then
   bootTicks=bootTicks+1
   if bootTicks>=50 then
    -- One second at the 50 Hz device rate allows late native initialization.
    observing=false
    if tv and not populated and not cold then
     -- An empty hot panel needs its birth gain in both the video and the knobs.
     for _,g in ipairs(gains)do sendNative(g[2],args[g[1]])end
     for id,v in pairs(args)do if not nativeBrightness(id)then draw(id,v)end end
    end
   end
  end
  paint(tv)
 end
 function c:initialize()
  samplePanel()
  paint(source())
 end
 return c
end
return M
