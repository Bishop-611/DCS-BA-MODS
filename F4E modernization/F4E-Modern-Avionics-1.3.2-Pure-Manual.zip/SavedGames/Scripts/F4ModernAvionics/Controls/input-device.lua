local root=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/]])
local Controller=dofile(root..'Controls/manual-controller.lua')
local update_range_lights=dofile(root..'Controls/range-lights.lua')
local update_display=dofile(root..'display-data.lua')
local map=dofile(root..'Controls/input-map.lua')
local force_interlock=dofile(root..'Controls/force-interlock.lua')
local agNative=dofile(root..'HUD/CCIP/native.lua')
local agNws=dofile(root..'Controls/ag-nws.lua').new(agNative)
local Release=dofile(root..'HUD/CCIP/release.lua')
local dev=GetSelf()
local time=0
local update_period=1/120
local next_display=0
local last_display_active=nil
local last_slew_x,last_slew_y,last_slew_epoch
local draw_knob=type(set_cockpit_draw_argument_value)=='function'and set_cockpit_draw_argument_value or nil
local last_knob,next_knob_retry=nil,0
local held,forwarded={},{}
local agSlew={}
local reset_until,start_at,release_at=nil,nil,nil
local mode=get_param_handle('RADAR_MODE')
local tdc_az=get_param_handle('RADAR_TDC_AZIMUTH')
local tdc_range=get_param_handle('RADAR_TDC_RANGE')
local ui_az=get_param_handle('F4_SR_UI_TDC_AZ')
local ui_range=get_param_handle('F4_SR_UI_TDC_RANGE')
local range=get_param_handle('F4_SR_RANGE_MAX_NM')
local acm=get_param_handle('F4_SR_ACM')
local sensors=get_base_data()
local power_switch=0
local iff_enabled=false
local last_radar_power=nil
local parameterHandles={}
local function parameter(name)
    local h=parameterHandles[name]
    if not h then h=get_param_handle(name);parameterHandles[name]=h end
    return h
end
local published={}
local function publish_ui(name,value)
    if published[name]==value then return end
    published[name]=value;parameter(name):set(value)
end
local function powered() return power_switch>=.74 end
local function radar() return assert(GetDevice(201),'Simple radar unavailable') end
local function aa_context()
    local ok,v=pcall(get_cockpit_draw_argument_value,271)
    if not ok or type(v)~='number' then return false end
    local index=math.floor(v/.1666+.5)
    -- Same A/A and CAGE HUD positions used by the modern-HUD implementation.
    if index~=4 and index~=2 then return false end
    -- A/G/TV uses HUD index 3; a screen-selector value alone must not disable A/A inputs.
    return true
end
local function airborne()
    local ok,n,l,r=pcall(function()
        return sensors.getWOW_NoseLandingGear(),sensors.getWOW_LeftMainLandingGear(),sensors.getWOW_RightMainLandingGear()
    end)
    return ok and type(n)=='number' and type(l)=='number' and type(r)=='number' and n<.5 and l<.5 and r<.5
end
local routes={}
for _,entry in ipairs(map) do
    routes[entry.routed]=entry
    if entry.axis_routed then routes[entry.axis_routed]=entry end
end
for command in pairs(routes) do dev:listen_command(command) end
local function forward(command,value)
    local entry=routes[command]
    if entry then dispatch_action(entry.device,entry.command,value) end
end
local harmInput=dofile(root..'HARM/input.lua').new(
 function()return parameter('F4_HARM_ACTIVE'):get()==1 end,
 function(command,value)GetDevice(207):performClickableAction(command,value,false)end,
 function()return parameter('F4_RADAR_PLAN_FOCUS'):get()==1 end)
local bombRelease=Release.new(agNative,function(value)dispatch_action(27,3002,value)end,function()
    local ok,armed=pcall(get_cockpit_draw_argument_value,247)
    return ok and type(armed)=='number' and armed>.5
end)
local function ag_context()
    local ok,v=pcall(get_cockpit_draw_argument_value,271)
    local selected,k=pcall(get_cockpit_draw_argument_value,273)
    if selected and type(k)=='number' and ((k>=.10 and k<=.17) or (k>=.24 and k<=.30)) then return false end
    return ok and type(v)=='number' and math.floor(v/.1666+.5)==3
end
local function release_time()
    if type(get_model_time)=='function' then local ok,t=pcall(get_model_time);if ok and type(t)=='number' and t==t then return t end end
    return time
end
local aaMissiles=dofile(root..'AMRAAM/device.lua').new(dofile(root..'HARM/native.lua'),{
 get=function(n)return parameter(n):get()end,
 radarLink=function()local d=GetDevice(201);return d and d.link end,
 draw=function(n)local ok,v=pcall(get_cockpit_draw_argument_value,n);return ok and type(v)=='number'and v or nil end,
 forward=function(device,command,value)dispatch_action(device,command,value)end,
 publish=publish_ui,
})
local contacts={}
for i=1,128 do
    local prefix=string.format('RADAR_CONTACT_%02d_',i)
    contacts[i]={range=parameter(prefix..'RANGE'),az=parameter(prefix..'AZIMUTH'),age=parameter(prefix..'TIME'),
        elevation=parameter(prefix..'ELEVATION')}
end
local function restore_scan_volume()
    parameter('SCAN_ZONE_VOLUME_AZIMUTH'):set(math.rad(acm:get()==1 and 40 or 80))
    parameter('SCAN_ZONE_VOLUME_ELEVATION'):set(math.rad(acm:get()==1 and 60 or 20))
    parameter('SCAN_ZONE_ORIGIN_AZIMUTH'):set(0)
    parameter('SCAN_ZONE_ORIGIN_ELEVATION'):set(0)
end
local controller=Controller.new({
    mode=function() return mode:get() end,
    busy=function() return reset_until~=nil or start_at~=nil or release_at~=nil end,
    state=function(active,maxrange)
        -- Changing range or acquisition mode cancels a held acquisition first.
        start_at=nil
        if release_at then dispatch_action(nil,510);release_at=nil end
        acm:set(active and 1 or 0);range:set(maxrange);
        parameter('SCAN_ZONE_VOLUME_AZIMUTH'):set(math.rad(active and 40 or 80))
        parameter('SCAN_ZONE_VOLUME_ELEVATION'):set(math.rad(active and 60 or 20))
        parameter('SCAN_ZONE_ORIGIN_AZIMUTH'):set(0)
        parameter('SCAN_ZONE_ORIGIN_ELEVATION'):set(0)
         end,
    locked_range=function() return parameter('RADAR_STT_RANGE'):get() end,
    cursor=function(az,r)
        tdc_az:set(az);tdc_range:set(r)
        publish_ui('F4_SR_UI_TDC_AZ',az);publish_ui('F4_SR_UI_TDC_RANGE',r)
    end,
    unlock=function()
        start_at=nil
        if release_at then dispatch_action(nil,510);release_at=nil end
        radar():set_power(false);reset_until=time+(acm:get()==1 and .05 or .2)
        parameter('IFF_INTERROGATOR_STATUS'):set(0);iff_enabled=false
        restore_scan_volume()

    end,
    lock_at=function(az,r,elevation)
        if reset_until then return end
        tdc_az:set(az);tdc_range:set(r);parameter('RADAR_TDC_RANGE_CARRET_SIZE'):set(3000)
        publish_ui('F4_SR_UI_TDC_AZ',az);publish_ui('F4_SR_UI_TDC_RANGE',r)
        -- Focus only on an existing native return. The narrow capture volume
        -- does not raise scan speed or receiver power.
        -- Normal capture may center on a +/-40 search-edge return; its full
        -- window remains inside the configured +/-60 native tracking gimbals.
        -- ACM keeps its separate +/-20 azimuth, +/-30 elevation boundaries.
        local azLimit=math.rad(acm:get()==1 and 10 or 50)
        local elLimit=math.rad(acm:get()==1 and 20 or 50)
        parameter('SCAN_ZONE_VOLUME_AZIMUTH'):set(math.rad(20))
        parameter('SCAN_ZONE_VOLUME_ELEVATION'):set(math.rad(20))
        parameter('SCAN_ZONE_ORIGIN_AZIMUTH'):set(math.max(-azLimit,math.min(azLimit,az)))
        parameter('SCAN_ZONE_ORIGIN_ELEVATION'):set(math.max(-elLimit,math.min(elLimit,elevation or 0)))
        start_at=time+(acm:get()==1 and .03 or .2)

    end,
    iff=function()
        if not iff_enabled then parameter('IFF_INTERROGATOR_STATUS'):set(1);iff_enabled=true end
    end,
    contacts=function()
        local result={}
        for _,target in ipairs(contacts) do
            local age=target.age:get()
            if age>=0 and age<=(acm:get()==1 and 2.5 or 2) and target.range:get()>0 then
                result[#result+1]={range=target.range:get(),az=target.az:get(),age=age,elevation=target.elevation:get()}
            end
        end
        -- Acquisition uses all native echoes within its existing age limit.
        -- A newer, unrelated return must not remove an otherwise valid weak
        -- return from the pilot's selection. No display history is reused here.
        return result
    end
})
make_default_activity(update_period)
need_to_be_closed=false
function post_initialize()
    local birth=LockOn_Options and LockOn_Options.init_conditions and LockOn_Options.init_conditions.birth_place
    -- The original transmitter is deliberately switched off before this device
    -- starts. Its resulting zero is not the new radar's requested hot-start state.
    power_switch=(birth=='AIR_HOT' or birth=='GROUND_HOT')and .75 or 0
    if parameter('F4_SR_START_POWER_VALID'):get()==1 then
        power_switch=math.max(0,math.min(1,parameter('F4_SR_START_POWER'):get()))
    end
    parameter('F4_SR_POWER_SWITCH'):set(power_switch)

end
function SetCommand(command,value)
    local routed=routes[command]
    if routed and type(value)=='number'and harmInput(routed.kind,value)then return end
    if routed and routed.kind=='bomb_release' then bombRelease:command(value,ag_context(),release_time());return end
    local entry=routes[command]
    if not entry or type(value)~='number' then return end
    if aaMissiles:command(entry,value,release_time(),aa_context())then return end
    local tvOK,tvMode=pcall(get_cockpit_draw_argument_value,2599)
    if (entry.kind=='x'or entry.kind=='y')and tvOK and type(tvMode)=='number'and tvMode>.75 then
        agSlew[command]=nil;forward(command,value);return
    end
    if entry.kind=='nws' and agNws:command(value,release_time(),ag_context()) then return end
    if entry.kind=='x' or entry.kind=='y' then
        local state=agNative and (agNative.ag_control or agNative.ag_state)()
        if ag_context() and state and state.mode==1 and state.target==1 then
            if forwarded[command] then forward(command,0);forwarded[command]=false end
            local v=value*(entry.scale or 1)
            if command==entry.axis_routed then
                local a=math.abs(v);v=a<=.12 and 0 or (v<0 and -1 or 1)*math.min(1,(a-.12)/.88)
            end
            agSlew[command]={kind=entry.kind,value=v}
            return
        end
        agSlew[command]=nil
    end
    if entry.kind=='interlock' then force_interlock('BLOCKED_INPUT');return end
    if entry.kind:sub(1,5)=='power' then
        if entry.kind=='power' then power_switch=value
        elseif entry.kind=='power_axis' then power_switch=(value+1)/2
        elseif entry.kind=='power_step' and value~=0 then power_switch=power_switch+(value>0 and .25 or -.25)
        elseif entry.kind=='power_next' and value>0 then power_switch=(power_switch+.25)%1.25 end
        power_switch=math.max(0,math.min(1,math.floor(power_switch*4+.5)/4))
        parameter('F4_SR_POWER_SWITCH'):set(power_switch)
        if not powered() then
            controller.cage_press=nil;controller.acm=false;controller.pending=false
            start_at=nil;reset_until=nil
            if release_at then dispatch_action(nil,510);release_at=nil end
            restore_scan_volume()
        end
        radar():set_power(powered() and aa_context());last_radar_power=nil

        return
    end
    local aa=aa_context()
    local consume=aa and (entry.kind~='nws' or airborne())
    if not consume then
        forward(command,value);forwarded[command]=math.abs(value)>.01
        return
    end
    if not powered() then return end
    if forwarded[command] then forward(command,0);forwarded[command]=false end
    if entry.kind=='cage' then controller:cage(value>.5,time)
    elseif entry.kind=='nws' then controller:nws(value>.5)
    else
        local axis=command==entry.axis_routed
        controller:slew((axis and 'axis_' or 'key_')..entry.kind,value*(entry.scale or 1))
    end
end
function update()
    time=time+update_period
    local ag,now=ag_context(),release_time()
    local aa=aa_context()
    agNws:tick(now,ag)
    aaMissiles:tick(now,aa)
    local state=agNative and(agNative.ag_control or agNative.ag_state)()or nil
    if agNative and agNative.ag_slew then
        local x,y=0,0
        if ag and state and state.mode==1 and state.target==1 then
            for _,v in pairs(agSlew)do if v.kind=='x' then x=x+v.value else y=y+v.value end end
        elseif next(agSlew)then agSlew={} end
        if math.abs(x)<.05 then x=0 end;if math.abs(y)<.05 then y=0 end
        x,y=math.max(-1,math.min(1,x)),math.max(-1,math.min(1,y))
        local epoch=state and state.epoch
        if x~=last_slew_x or y~=last_slew_y or epoch~=last_slew_epoch then
            agNative.ag_slew(x,y);last_slew_x=x;last_slew_y=y;last_slew_epoch=epoch
        end
    end
    bombRelease:update(ag,now,state)
    -- Cancel before dispatching a delayed lock if the pilot left A/A or
    -- switched radar power off between the request and this update.
    if not(aa and powered())and(start_at or release_at)then
        start_at=nil
        if release_at then dispatch_action(nil,510);release_at=nil end
        restore_scan_volume()
    end
    if reset_until and time>=reset_until then radar():set_power(powered() and aa_context());last_radar_power=nil;reset_until=nil end
    if start_at and time>=start_at then dispatch_action(nil,509);start_at=nil;release_at=time+(acm:get()==1 and 1.2 or 5) end
    if release_at and (mode:get()==3 or time>=release_at) then
        local acquired=mode:get()==3
        dispatch_action(nil,510);release_at=nil
        restore_scan_volume()

    end
    local should_scan=aa and powered() and reset_until==nil
    if should_scan~=last_radar_power then
        radar():set_power(should_scan);last_radar_power=should_scan

    end
    local screenOK,screenMode=pcall(get_cockpit_draw_argument_value,2599)
    local tvSelected=screenOK and type(screenMode)=='number' and screenMode>.75
    local screenRadar=not screenOK or type(screenMode)~='number' or screenMode<.25
    publish_ui('F4_SR_AA_ACTIVE',should_scan and screenRadar and not tvSelected and 1 or 0)
    controller:tick(time,update_period,aa and powered())
    update_range_lights(range:get(),aa and powered(),publish_ui)
    publish_ui('F4_SR_UI_TDC_VALID',aa and powered() and 1 or 0)
    if time>=next_display then
        if should_scan or last_display_active~=should_scan then update_display();last_display_active=should_scan end
        next_display=next_display+1/30;if next_display<time then next_display=time+1/30 end
    elseif should_scan then
        -- Cursor-only projection: no echo polling or association on these ticks.
        update_display(true)
    end
    -- The reused model knob visualizes the new radar, not the original transmitter state.
    if draw_knob and time>=next_knob_retry then
        next_knob_retry=time+.1 -- bounded animation ownership check, not a transmitter command
        local ok,v=pcall(get_cockpit_draw_argument_value,336)
        if last_knob~=power_switch or(ok and type(v)=='number' and math.abs(v-power_switch)>.001)then
            if pcall(draw_knob,336,power_switch)then last_knob=power_switch else next_knob_retry=time+1 end
        end
    end
end
