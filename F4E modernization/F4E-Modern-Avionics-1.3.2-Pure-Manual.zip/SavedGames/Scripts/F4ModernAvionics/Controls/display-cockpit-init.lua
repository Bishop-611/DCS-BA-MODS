-- Keep the native page IDs and draw one shared scope, followed by its cursor.
dofile(LockOn_Options.script_path..'Scripts/DSCG/indicator/init.lua')
local emptyPage=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/Controls/display-cockpit-empty.lua]])
local cursor=4
local scope=5
local harm=6
page_subsets[OFF]=emptyPage
page_subsets[RADAR]=emptyPage
page_subsets[cursor]=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/Controls/cursor-page.lua]])
page_subsets[scope]=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/Controls/display-cockpit-page.lua]])
page_subsets[harm]=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/plan-page.lua]])
-- The native transmitter can be off while the physical selector is on RADAR.
pages[2]={BASE,OFF,scope,cursor,harm}
pages[3]={BASE,RADAR,scope,cursor,harm}
