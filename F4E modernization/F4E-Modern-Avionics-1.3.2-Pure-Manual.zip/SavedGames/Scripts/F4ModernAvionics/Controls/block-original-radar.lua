local dev=GetSelf()
local function screenSource()
 local ok,v=pcall(get_cockpit_draw_argument_value,2599)
 if not ok or type(v)~='number' then return false,false end
 return v>.75,v>=0 and v<.25
end
local display=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/Controls/display-controls.lua]])).router(
 function(name,value)get_param_handle(name):set(value)end,
 function(arg,value)
  if arg==1206 or arg==1402 then
   local panel=GetDevice(0)
   if panel and panel.set_argument_value then
    pcall(panel.set_argument_value,panel,arg,value)
   end
  else
   pcall(set_cockpit_draw_argument_value,arg,value)
  end
 end,
 function(command,value)GetDevice(52):performClickableAction(command,value,false)end,
 screenSource,get_cockpit_draw_argument_value, LockOn_Options and LockOn_Options.init_conditions and LockOn_Options.init_conditions.birth_place)
local displayCommands={}
for _,id in ipairs({3031,3053,3065,3080,3028,3029,3030,3051,3052,3070,3095,3096,3097,
 3023,3025,3032,3033,3045,3046,3048,3102,3105,3106,3107,
 3024,3026,3047,3049,3103,3104,3066,3067,3098,3068,3069,3099,3112})do displayCommands[id]=true end
-- The supported F-4E build declares device 52 commands 3001 through 3120.
for command=3001,3120 do dev:listen_command(command) end
need_to_be_closed=false
make_default_activity(.02)
local transmitterPower={[3004]=true,[3038]=true,[3057]=true,[3086]=true}
function SetCommand(command,value)
    if transmitterPower[command] then

        return
    end
    if display:command(command,value)then
        return
    end
    local ok,tv=pcall(get_cockpit_draw_argument_value,2599)
    if ok and type(tv)=='number'and tv>.75 then
        GetDevice(52):performClickableAction(command,value,false);return
    end
    -- Native DSCG Radar/Off/TV selection controls the video compositor, not
    -- the radar transmitter. Keep the original four UI routes functional.
    if displayCommands[command] then
        GetDevice(52):performClickableAction(command,value,false)
        return
    end

end
function post_initialize()
    display:initialize()

end
function update()display:tick()end
