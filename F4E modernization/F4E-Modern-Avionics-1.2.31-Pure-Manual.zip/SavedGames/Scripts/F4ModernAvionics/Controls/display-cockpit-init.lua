-- Same native ccRadar subset entry used by the project's modern HUD.
-- Keep native compositor, geometry and TV indicators; do not replace the failed final bake pass.
dofile(LockOn_Options.script_path..'Scripts/DSCG/indicator/init.lua')
local page=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/Controls/display-cockpit-page.lua]])
page_subsets[OFF]=page
page_subsets[RADAR]=page
-- One cursor subset instead of constructing a separate cursor in both pages.
local CURSOR_SHARED=4
page_subsets[CURSOR_SHARED]=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/Controls/cursor-page.lua]])
pages[2]={BASE,OFF,CURSOR_SHARED}
pages[3]={BASE,RADAR,CURSOR_SHARED}

