-- WSO profiles retain all native controls except the existing AA weapon/trigger options.
-- Inherited profiles may already be routed; command-device matching makes this idempotent.
local map=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/Controls/input-map.lua]]))
return function(res)
 for _,group in ipairs({res.keyCommands or {},res.axisCommands or {}})do
  for _,bind in ipairs(group)do
   if bind.cockpit_device_id==27 then
    for _,entry in ipairs(map)do
     if entry.device==27 and entry.kind:sub(1,3)=='aa_'and
       (bind.down==entry.command or bind.action==entry.command or bind.pressed==entry.command)then
      local target=bind.action and(entry.axis_routed or entry.routed)or entry.routed
      for _,field in ipairs({'down','up','pressed','action'})do
       if bind[field]==entry.command then bind[field]=target end
      end
      bind.cockpit_device_id=203;break
     end
    end
   end
  end
 end
 return res
end
