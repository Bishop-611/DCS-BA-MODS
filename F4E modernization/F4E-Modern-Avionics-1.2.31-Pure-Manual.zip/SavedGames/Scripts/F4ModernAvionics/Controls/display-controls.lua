-- Read the original pilot/WSO screen controls. No additional input bindings.
local M={}
local function clamp(x)return math.max(0,math.min(1,x))end
function M.new(read,set)
 local values={brightness=.5,contrast=.5,scale=.5,grid=.5,cursor=.5,offset=.5}
 local slots={{1206,'brightness',true},{1402,'brightness'},{1203,'contrast',true},{1400,'contrast'},
 {1202,'scale',true},{2672,'scale'},{334,'grid',true},{1401,'cursor',true},{1403,'offset',true}}
 local previous,output={},{}
 return function()
  for _,slot in ipairs(slots)do
   local ok,v=pcall(read,slot[1])
   if ok and type(v)=='number'and v==v then
    v=clamp(v)
    if (previous[slot[1]]==nil and slot[3])or(previous[slot[1]]~=nil and math.abs(previous[slot[1]]-v)>1e-5)then values[slot[2]]=v end
    previous[slot[1]]=v
   end
  end
  local b=clamp(values.brightness)
  local foreground=clamp(b*values.contrast*2)
  local result={F4_SR_SCREEN_FOREGROUND=foreground,F4_SR_SCREEN_GRID=clamp(foreground*(1.25-.5*values.contrast)*values.grid*2),
   F4_SR_SCREEN_TEXT=foreground*clamp(values.scale*2),F4_SR_SCREEN_CURSOR=foreground*clamp(values.cursor*2),
   F4_SR_SCREEN_OFFSET=foreground*clamp(values.offset*2)}
  for k,v in pairs(result)do
   if output[k]~=v then output[k]=v;set(k,v);set(k..'_LEVEL',math.floor(v*32+.5))end
  end
 end
end
-- Own display controls in radar mode; the native video gain must not also
-- amplify the inserted vector page. Native TV keeps its original controls.
function M.router(set,draw,forward,isTV,read,birth)
 local args={};for _,id in ipairs({1206,1402,1203,1400,1202,2672,334,1401,1403})do args[id]=.5 end
 local cold=birth=='GROUND_COLD'
 args[1206]=cold and 0 or .8;args[1402]=args[1206]
 -- Owned initial values: the native devices do not populate these controls.
 -- Commands, including an explicit zero, remain authoritative after startup.
 local specs={}
 local function family(ids,positions)
  for i,id in ipairs(ids)do specs[id]={positions=positions,kind=i==1 and 'absolute' or(i==2 and 'step' or 'axis')}end
 end
 family({3029,3052,3097},{1206,1402});family({3025,3048,3106},{1206,1402})
 family({3028,3051,3096},{1203,1400});family({3023,3046,3105},{1203,1400})
 family({3030,3070,3095},{1202,2672});family({3033,0,3107},{1202,2672})
 family({3032,3045,3102},{334});family({3024,3047,3103},{1401});family({3026,3049,3104},{1403})
 specs[0]=nil
 local publish=M.new(function(id)return args[id]end,set)
 local c={}
 function c:command(command,value)
  local spec=specs[command];if not spec then return false end
  local old=args[spec.positions[1]]
  local v=spec.kind=='step' and old+value or(spec.kind=='axis' and (value+1)*.5 or value)
  for _,id in ipairs(spec.positions)do args[id]=clamp(v)end
  if isTV()then forward(command,value)end
  self:tick();return true
 end
 function c:tick()
  local tv=isTV()
  publish()
  -- Never overwrite native TV animation/output arguments while video is selected.
  if not tv then for id,v in pairs(args)do draw(id,v)end end
 end
 function c:initialize()
  publish()
  -- Seed model positions once even when a mission starts directly in TV.
  -- This changes animation only, not native video gain or transmitter power.
  for id,v in pairs(args)do draw(id,v)end
 end
 return c
end
return M
