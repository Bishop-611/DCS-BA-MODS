-- Independent scope inspired by the local F-16 ALR56 display layering.
-- Generic DCS parameter controllers, driven by F15EX processing; no F16 DLL.
dofile(LockOn_Options.script_path..'Displays/ew_geom.lua')
local C,H=GREEN,.065
for i=1,TEWS_MAX do
 local pre=string.format('TEWS_T%02d_',i)
 local n=node({0,0},nil,{pre..'X',pre..'Y'},
  {{'move_left_right_using_parameter',0,S(1)},{'move_up_down_using_parameter',1,S(1)}})
 local on={pre..'V',.5,1.5}
 text(nil,{0,0},H,C,'CenterCenter',n,{pre..'TXT','%s'},{on,{pre..'CN',-.5,.5}})
 text(nil,{0,0},H,C,'CenterCenter',n,{pre..'NUM','%.0f'},{on,{pre..'CN',.5,1.5}})
 -- Airborne chevron above the identifier, not a multifunction-page triangle.
 segments({{-.075,.09,0,.145},{0,.145,.075,.09}},.006,C,n,nil,{on,{pre..'AIR',.5,1.5}})
 -- Track box and launch circle have separate data gates.
 segments({{-.115,-.09,-.115,.09},{-.115,.09,.115,.09},{.115,.09,.115,-.09},{.115,-.09,-.115,-.09}},
  .005,C,n,nil,{on,{pre..'LOCK',.5,1.5}})
 circle(.16,.006,C,n,nil,32,{on,{string.format('ALR56_LAUNCH_%02d',i),.5,1.5}})
 segments({{0,.20,.20,0},{.20,0,0,-.20},{0,-.20,-.20,0},{-.20,0,0,.20}},.005,C,n,nil,
  {on,{'ALR56_PRIMARY',i-.1,i+.1}})
end
-- Search indication in the center follows the independent F16-style page.
-- Search filtering remains active; center S indication omitted by request.
text('PRI',{-.4,-.86},.035,C,'CenterCenter',nil,nil,{'ALR56_PRIORITY',.5,1.5})
text('SEP',{.4,-.86},.035,C,'CenterCenter',nil,nil,{'ALR56_SEPARATE',.5,1.5})
text('TEST',{0,.45},.065,C,'CenterCenter',nil,nil,{'ALR56_TEST',.5,1.5})
circle(.3,.006,C,nil,nil,32,{'ALR56_TEST',.5,1.5})
text('ALR-56M',{0,-.94},.04,C,'CenterCenter')

