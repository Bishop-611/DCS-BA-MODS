-- Run in existing avLuaDevice 206: native receiver VM has no reliable draw setter.
local M={}
function M.new(read,draw,readArgument)
 local previous={}
 local ticks=0
 return function()
  if not draw or read('ALR56_PANEL_READY')~=1 then return end
  ticks=ticks+1
  for _,group in ipairs({{'ALR56_BRIGHTNESS',975,976,2625,2809},{'ALR56_VOLUME',977,2624}})do
   local value=read(group[1])
   if type(value)=='number'and value==value then
    value=math.max(0,math.min(1,value))
    local changed=previous[group[1]]~=value
    if changed or (readArgument and ticks%5==0)then
     local ok=true
     for i=2,#group do
      local matches=false
      if not changed and readArgument then local valid,actual=pcall(readArgument,group[i]);matches=valid and type(actual)=='number'and math.abs(actual-value)<.001 end
      if not matches and not pcall(draw,group[i],value)then ok=false end
     end
     if ok then previous[group[1]]=value end
    end
   end
  end
 end
end
return M
