dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/RWR/common.lua]]))
local syncKnobs=dofile(EXFULL_ROOT..'knob-animation.lua').new(function(n)return get_param_handle(n):get()end,
 type(set_cockpit_draw_argument_value)=='function'and set_cockpit_draw_argument_value or nil,
 type(get_cockpit_draw_argument_value)=='function'and get_cockpit_draw_argument_value or nil)
local nativeHost=create_sound_host
local panelSounds={}
local modeTools=dofile(EXFULL_ROOT..'display-modes.lua')
ALR56_display_contacts=modeTools.new(get_param_handle)
ALR56_separate=modeTools.separate
local powered,gain=false,0
function create_sound_host(name,kind,x,y,z)
 local host=nativeHost('F4_MODERN_RWR_AUDIO','2D',x,y,z)
 local proxy={}
 function proxy:create_sound(path)
  local mapped=path:gsub('Aircrafts/F15EX/RWR/','EXFull/RWR/')
  local sound=host:create_sound(mapped)
  panelSounds[#panelSounds+1]=sound
  sound:update(nil,gain,0)
  local p={}
  function p:play_once()if powered then local v=sound:play_once();sound:update(nil,gain,0);return v end end
  function p:stop()return sound:stop()end
  function p:update(...)return sound:update(...)end
  if sound.play_continue then function p:play_continue()if powered then local v=sound:play_continue();sound:update(nil,gain,0);return v end end end
  function p:is_playing()return sound:is_playing()end
  return p
 end
 return proxy
end
dofile(LockOn_Options.script_path..'Systems/TEWS.lua')
local basePost,baseUpdate=post_initialize,update
local lastGain
local function volume()
 powered=get_param_handle('RWR_POWER'):get()>.5
 gain=powered and 2*get_param_handle('ALR56_VOLUME'):get()or 0
 if gain~=lastGain then for _,s in ipairs(panelSounds)do s:update(nil,gain,0)end;lastGain=gain end
 if not powered then for _,s in ipairs(panelSounds)do s:stop()end end
end
function post_initialize()
 get_param_handle('SMS_CHF'):set(-1);get_param_handle('SMS_FLR'):set(-1)
 get_param_handle('CMD_MODE'):set(1)
 volume();basePost();EXFULL_flush()

end
function update()syncKnobs();volume();baseUpdate();EXFULL_flush()end
