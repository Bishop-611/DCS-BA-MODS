local M={receiver_lifetime=7.0} -- Matches the installed modern receiver EmitterLiveTime.
local pylons={1,3,11,13};local lamps={[1]=256,[3]=257,[11]=259,[13]=260}
local function finite(n)return type(n)=='number'and n==n and math.abs(n)<1e10 end
local function vector(p)return type(p)=='table'and finite(p.x)and finite(p.y)and finite(p.z)end
local function harm(s)
 if type(s)~='table'or not finite(s.count)or s.count<=0 or type(s.weapon)~='table'then return false end
 local w=s.weapon;return(w.level1 or w[1])==4 and(w.level2 or w[2])==4 and(w.level4 or w[4])==65
end
function M.capture(api,raw,now)
 local function call(name,...)if type(api[name])=='function'then local ok,v=pcall(api[name],...);if ok then return v end end end
 local own=call('LoGetSelfData');if not own or own.Name~='F-4E-45MC'or not vector(own.Position)then return {{'OFF',now}}end
 local panel=call('GetDevice',0)
 local function draw(n)local ok,v=pcall(function()return panel:get_argument_value(n)end);return ok and finite(v)and v or -1 end
 local payload=call('LoGetPayloadInfo')or {};local stations=payload.Stations or {}
 local station=payload.CurrentStation;local counts={'C'}
 for _,p in ipairs(pylons)do counts[#counts+1]=stations[p]and stations[p].count or 0 end
 if not finite(station)or station==0 then
  station=0;local arm=draw(273);if arm>=.10 and arm<=.17 then
   for _,p in ipairs(pylons)do if draw(lamps[p])>.05 and harm(stations[p])then station=p;break end end
  end
 end
 local isHarm=lamps[station]~=nil and harm(stations[station]);local allowed=call('LoIsObjectExportAllowed')==true
 local ag=math.floor(draw(271)/.1666+.5)==3;local tv=draw(2599)>.75
 local p=own.Position
 -- One scalar sample at the existing 10 Hz Export cadence, only on the active
 -- HARM page. TAS is an explicit interface choice for the native launch table;
 -- it is not a claim that this reproduces an aircraft-specific HARM envelope.
 -- Missing speed must remain unknown, never a fabricated zero-speed solution.
 local speed=isHarm and ag and tv and call('LoGetTrueAirSpeed')or nil
 local speedValid=finite(speed)and speed>=0 and speed<=1500
 local rows={{'H',now,p.x,p.y,p.z,own.Heading or 0,station,isHarm and stations[station].count or 0,isHarm and 1 or 0,allowed and 1 or 0,ag and 1 or 0,tv and 1 or 0,speedValid and 1 or 0,speedValid and speed or 0},counts}
 if not(isHarm and ag and tv and allowed)then return rows end
 local header=raw[1]
 if not header or header[1]~='R'or not finite(header[2])or now-header[2]<-.1 or now-header[2]>.3 or header[3]~=1 then return rows end
 local seen={}
 for i=2,math.min(17,#raw)do
  local r=raw[i];local id=r[1];local age=r[3]
  if finite(id)and id>0 and id%1==0 and id<=4294967295 and type(r[2])=='string'and finite(age)and age>=0 and age+math.max(0,now-header[2])<=M.receiver_lifetime and finite(r[4])and r[4]>0 and finite(r[5])and r[5]>=.5 and not seen[id]then
   local object=call('LoGetObjectById',id)
   -- SOURCE is not assumed to be a world ID unless the exported unit type matches.
   if object and object.Name==r[2]and vector(object.Position)then
    seen[id]=true;local q=object.Position;rows[#rows+1]={'T',id,q.x,q.y,q.z,now}
   end
  end
 end
 return rows
end
function M.decode(rows)
 local r=rows[1];if not r or r[1]~='H'then return nil end
 for i=2,12 do if not finite(r[i])then return nil end end
 local f={time=r[2],own={position={x=r[3],y=r[4],z=r[5]},heading=r[6]},station=r[7],count=r[8],harm=r[9]==1,allowed=r[10]==1,ag=r[11]==1,tv=r[12]==1,counts={},contacts={}}
 -- Keep legacy H12 frames usable for target display and handoff. Only the
 -- range cue requires the additional, validated H14 speed sample.
 if r[13]==1 and finite(r[14])and r[14]>=0 and r[14]<=1500 then f.own.speed=r[14]end
 local counts=rows[2];if not counts or counts[1]~='C'then return nil end
 for i,p in ipairs(pylons)do if not finite(counts[i+1])then return nil end;f.counts[p]=counts[i+1]end
 for i=3,math.min(18,#rows)do local t=rows[i]
  if t[1]=='T'and finite(t[2])and finite(t[3])and finite(t[4])and finite(t[5])and finite(t[6])then
   f.contacts[#f.contacts+1]={id=t[2],position={x=t[3],y=t[4],z=t[5]},stamp=t[6],detected=true,identityVerified=true}
  end
 end
 return f
end
return M
