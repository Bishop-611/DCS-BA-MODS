-- Reuses existing NWS and release options, including both key-up routes.
local M={}
function M.new(active,send)
 local owned={}
 return function(kind,value)
  if kind~='nws'and kind~='bomb_release'then return false end
  local enabled=active();local held=owned[kind]
  if enabled or held then
   send(kind=='nws'and 3001 or 3002,value)
   owned[kind]=value>.5
   return true
  end
  -- Observe held input while inactive, preventing a synthetic edge on mode entry.
  send(kind=='nws'and 3001 or 3002,value)
  return false
 end
end
return M
