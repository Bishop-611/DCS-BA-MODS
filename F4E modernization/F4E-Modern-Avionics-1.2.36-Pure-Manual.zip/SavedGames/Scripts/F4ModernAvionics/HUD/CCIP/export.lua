if F4SimpleCCIPLoaded then return end
F4SimpleCCIPLoaded=true
local root=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/CCIP/]])
local Inputs,Profiles,Solver=dofile(root..'inputs.lua'),dofile(root..'profiles.lua'),dofile(root..'solver.lua')
local native=dofile(root..'native.lua')
local ccrp=dofile(root..'ccrp.lua').new(native)
local last_input,last_profile,last_impact,last_impact_time=nil,nil,nil,-10
local seq,next_compute,job,job_input,job_time=0,-1,nil,nil,nil
local last_attitude=nil
local terrain_verified_until=-1
local verified_terrain=nil
local previous_delivery_mode=nil
local compute_interval=nil
local TerrainOK,Terrain=pcall(require,'terrain')
local cpu_clock=type(os)=='table' and type(os.clock)=='function' and os.clock or nil
local function finite(v) return type(v)=='number' and v==v and math.abs(v)<1e12 end
local function call(n,...) if type(_G[n])=='function' then local ok,v=pcall(_G[n],...);if ok then return v end end end
local errorReported=false
local function report_error(message)
    if errorReported then return end
    errorReported=true
    if log and log.write then pcall(log.write,'F4_CCIP',log.ERROR or 1,message)end
end
local function publish(valid,time,impact,input,status,now,label)
    if ccrp.mode==1 and valid==1 then

        return -- CCIP indicator is hidden; CCRP consumes the local footprint.
    end
    seq=seq+1
    local p=impact or {x=0,y=0,z=0,time=0}
    local v=input and input.velocity or {x=0,y=0,z=0}
    local values={valid,time,p.x,p.y,p.z,p.time,status,input and input.code or 0,input and input.station or 0,v.x,v.y,v.z}
    local ok,err=pcall(function()
        local dev=assert(GetDevice(205),'HUD device unavailable')
        dev:performClickableAction(3900,seq,false)
        for i,value in ipairs(values) do dev:performClickableAction(3900+i,value,false) end
        dev:performClickableAction(3913,seq,false)
    end)
    if not ok then report_error('HUD bridge failed: '..tostring(err))end

end
local function tick()
    local now=call('LoGetModelTime');if not finite(now) then return end
    if now<next_compute-2 then next_compute=-1;job=nil;verified_terrain=nil;terrain_verified_until=-1;last_attitude=nil end
    local own=call('LoGetSelfData')
    if type(own)~='table' or own.Name~='F-4E-45MC' then
        job=nil;return
    end
    local panel=call('GetDevice',0)
    local ok,mode,tv=pcall(function() return panel:get_argument_value(271),panel:get_argument_value(2599) end)
    local ag=ok and finite(mode) and math.floor(mode/.1666+.5)==3
    local selected,selector=pcall(function()return panel:get_argument_value(273)end)
    if selected and finite(selector) and ((selector>=.10 and selector<=.17) or (selector>=.24 and selector<=.30))then ag=false end
    local observed_agl=call('LoGetAltitudeAboveGroundLevel')
    local designator_terrain
    if own.Position and finite(observed_agl) and now>=terrain_verified_until then
        verified_terrain=nil;terrain_verified_until=now+.1
        local candidate=TerrainOK and type(Terrain)=='table' and Terrain.GetHeight
        if type(candidate)=='function' then
            local good,height=pcall(candidate,own.Position.x,own.Position.z)
            if good and finite(height) and math.abs(height-(own.Position.y-observed_agl))<15 then
                verified_terrain=function(x,z)local valid,h=pcall(candidate,x,z);return valid and finite(h) and h or nil end
            end
        end
    end
    designator_terrain=verified_terrain
    ccrp:process(now,ag,own,designator_terrain)
    if previous_delivery_mode~=ccrp.mode then
        previous_delivery_mode=ccrp.mode;job=nil;next_compute=-1;compute_interval=nil
    end
    if not ag then
        job=nil
        last_input,last_profile,last_impact=nil,nil,nil
        if now>=next_compute then next_compute=now+.2;publish(0,now,nil,nil,0,now) end
        return
    end
    local agl=observed_agl -- one same-frame altitude sample for terrain validation and gates
    local altitude_limit=ccrp.mode==1 and 15240 or 3657.6
    if not finite(agl) or agl<=0 or agl>altitude_limit then
        job=nil
        if now>=next_compute then next_compute=now+.2;publish(0,now,nil,nil,9,now,'AGL_GATE') end
        return
    end
    if not job and now+1e-7>=next_compute then
        -- CCIP targets 30/60 Hz physical solutions, 60 Hz HUD projection.
        -- Game frame rate and synchronous solve cost bound the achievable rate. No coarser physics or terrain grid.
        local rapid=last_attitude and now>last_attitude.time and (
            math.abs((own.Pitch or 0)-last_attitude.pitch)/(now-last_attitude.time)>.05 or
            math.abs((own.Bank or 0)-last_attitude.bank)/(now-last_attitude.time)>.10)
        local interval=rapid and 1/60 or 1/30
        if ccrp.mode==1 then
            interval=rapid and .125 or .25
            local state=ccrp.solution
            -- Spend precision near the release point rather than throughout
            -- the approach. A held button alone does not force high-rate work.
            if state and ((state.ttr>=0 and state.ttr<4) or math.abs(ccrp.lastAlong or 1e9)<1000)then interval=.05 end
        end
        if compute_interval~=interval or next_compute<0 then next_compute=now+interval
        else next_compute=next_compute+interval end
        if next_compute<=now then next_compute=now+interval end
        compute_interval=interval
        last_attitude={time=now,pitch=own.Pitch or 0,bank=own.Bank or 0}
        local input,reason=Inputs.capture(_G)
        if not input then publish(0,now,nil,nil,reason=='EXCLUDED_WEAPON' and 8 or (reason=='AMBIGUOUS_SELECTION' and 7 or (reason=='NO_SELECTION' and 2 or 6)),now,reason);return end
        local profile=Profiles.select(input.name,input)
        if not profile then publish(0,now,nil,input,3,now,'UNSUPPORTED');return end
        input.code=profile.code
        if not(finite(input.pitch) and finite(input.bank) and finite(input.heading)) then publish(0,now,nil,input,6,now);return end
        local agl=observed_agl
        if not finite(agl) or agl<=0 then publish(0,now,nil,input,4,now);return end
        local terrain=designator_terrain
        if not terrain then publish(0,now,nil,input,4,now,'NO_VERIFIED_TERRAIN');return end
        local cp,sp,ch,sh,cb,sb=math.cos(input.pitch),math.sin(input.pitch),math.cos(input.heading),math.sin(input.heading),math.cos(input.bank),math.sin(input.bank)
        local bore=profile.bore or 0
        local dx=cp*ch*math.cos(bore)+(-sp*ch*cb-sh*sb)*math.sin(bore)
        local dy=sp*math.cos(bore)+cp*cb*math.sin(bore)
        local dz=cp*sh*math.cos(bore)+(-sp*sh*cb+ch*sb)*math.sin(bore)
        profile.direction={x=dx,y=dy,z=dz}
        profile.orientation=Solver.orientation(input.pitch,input.bank,input.heading)
        local velocity={x=input.velocity.x+dx*(profile.muzzle or 0),y=input.velocity.y+dy*(profile.muzzle or 0),z=input.velocity.z+dz*(profile.muzzle or 0)}
        job_input,job_time=input,now;profile.yield_step=coroutine.yield
        last_input,last_profile=input,profile
        job=coroutine.create(function() return Solver.solve(input.origin,velocity,profile,terrain,input.wind) end)
    end
    local ballistic_work=false
    if job then
        -- Native calls are synchronous. Admit at most one trajectory per frame;
        -- the Lua fallback retains its bounded integration slices.
        ballistic_work=true
        local ok,result,reason
        local deadline=cpu_clock and cpu_clock()+.002 or nil
        for _=1,12 do
            ok,result,reason=coroutine.resume(job)
            if not ok or coroutine.status(job)=='dead' then break end
            if deadline and cpu_clock()>=deadline then break end
        end
        if not ok then publish(0,now,nil,job_input,6,now,'SOLVER_ERROR '..tostring(result));job=nil
        elseif coroutine.status(job)=='dead' then
            if result and now-job_time<=1 then
                last_impact,last_impact_time=result,now
                publish(1,job_time,result,job_input,1,now)
            else publish(0,now,nil,job_input,4,now,reason or 'SOLVER_STALE') end
            job=nil
        end
    end
    -- update() is a no-op without an active CCRP target; avoid preparing its input then.
    if ccrp.mode==1 and ccrp.target and last_input and last_profile and designator_terrain then
        local frame_input={}
        for k,v in pairs(last_input)do frame_input[k]=v end
        frame_input.origin=own.Position
        local v=call('LoGetVectorVelocity');if type(v)=='table' and finite(v.x) and finite(v.y) and finite(v.z)then frame_input.velocity=v end
        frame_input.pitch=own.Pitch or last_input.pitch;frame_input.bank=own.Bank or last_input.bank
        local footprint
        if last_impact and now-last_impact_time<.35 then
            local dt=math.max(0,now-last_impact_time)
            footprint={x=last_impact.x+last_input.velocity.x*dt,y=last_impact.y,z=last_impact.z+last_input.velocity.z*dt}
        end
        ccrp:update(now,frame_input,last_profile,designator_terrain,footprint,not ballistic_work)
    end
end
local previous_frame=LuaExportAfterNextFrame
LuaExportAfterNextFrame=function(...)
    if previous_frame then previous_frame(...) end
    local ok,err=pcall(tick)
    if not ok then report_error('Export update failed: '..tostring(err))end
end
local previous_stop=LuaExportStop
LuaExportStop=function(...)
    job=nil;next_compute=-1;errorReported=false
    ccrp:reset();last_input,last_profile,last_impact=nil,nil,nil
    last_attitude=nil;verified_terrain=nil;terrain_verified_until=-1
    if previous_stop then previous_stop(...) end
end
