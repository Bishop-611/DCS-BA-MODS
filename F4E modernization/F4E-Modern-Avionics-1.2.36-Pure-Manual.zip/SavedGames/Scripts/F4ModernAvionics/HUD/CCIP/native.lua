local root=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/CCIP/]])
local native,reason
if package and type(package.loadlib)=='function' then
    local ok,loader,err=pcall(package.loadlib,root..'f4ballistics.dll','luaopen_f4ballistics')
    if ok and type(loader)=='function' then local loaded,lib=pcall(loader);if loaded and type(lib)=='table' and lib.abi==1 then native=lib else reason=tostring(lib) end
    else reason=tostring(err or loader) end
else reason='Native loader unavailable' end
if not native and log and log.write then log.write('F4_BALLISTICS',log.ERROR or 1,'Native backend unavailable; using Lua fallback: '..tostring(reason)) end
return native
