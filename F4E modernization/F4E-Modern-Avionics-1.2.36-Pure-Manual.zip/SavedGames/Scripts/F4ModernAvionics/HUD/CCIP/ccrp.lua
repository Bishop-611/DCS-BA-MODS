-- F-4 CCRP: designated point, future-release trajectory refinement and consent.
-- Ammunition-specific native ballistics; countdown is time TO RELEASE, not impact.
local M={sight_pitch=-.03,optical_y=-30,max_designation_range=30*1852}
-- User-selected angular cross-track corridor, shared with HUD ALIGN.
M.release_angle=math.rad(2.5)
function M.release_corridor(range)return math.max(0,range or 0)*math.sin(M.release_angle)end
-- Flat local ground geometry: equalize projected horizontal/vertical motion
-- without extra terrain samples or ballistic solves. Bound shallow-look gain.
function M.slew_velocity(own,target,sx,sy)
 local p=own.Position;local dx,dz=target.x-p.x,target.z-p.z
 local horizontal=math.sqrt(dx*dx+dz*dz)
 local height=math.abs(p.y-target.y)
 local gain=math.max(1,math.min(20,math.sqrt(horizontal*horizontal+height*height)/math.max(1,height)))
 local h=own.Heading or 0;local forward=sy*250*gain;local right=sx*250
 return forward*math.cos(h)-right*math.sin(h),forward*math.sin(h)+right*math.cos(h),gain
end
local function finite(v)return type(v)=='number' and v==v and math.abs(v)<1e12 end
local function copy(t)local r={};for k,v in pairs(t)do r[k]=v end;return r end
function M.new(native)
 local c={mode=0,target=nil,epoch=0,solution=nil,job=nil,next=0,lastAlong=nil,release=false}
 function c:clear()
  self.target=nil;self.solution=nil;self.job=nil;self.next=0;self.lastAlong=nil;self.lastReleaseCheck=nil;self.release=false;self.releaseUntil=-1;self.epoch=self.epoch+1
 end
 function c:reset()self.mode=0;self:clear();if native then native.ag_reset()end end
 function c:publish(now,valid,range,ttr,along,cross,release)
  if not native then return end
  local target=self.target or {};local solution=self.solution or {}
  local own=self.own or {};local position=own.Position or {}
  native.ag_publish({mode=self.mode,target=self.target and 1 or 0,tx=target.x or 0,ty=target.y or 0,tz=target.z or 0,
   valid=valid and 1 or 0,heading=solution.heading or 0,pitch=solution.pitch or 0,range=range or self.range or 0,ttr=ttr or -1,
   along=along or 0,cross=cross or 0,stamp=now,release=release and 1 or 0,epoch=self.epoch,status=valid and self.aligned==false and 1 or 0,
   ox=position.x or 0,oy=position.y or 0,oz=position.z or 0,opitch=own.Pitch or 0,obank=own.Bank or 0,oheading=own.Heading or 0,
   pose_time=self.lastProcess or now,pose_valid=position.x and finite(own.Pitch) and finite(own.Bank) and finite(own.Heading) and 1 or 0})
 end
 function c:process(now,ag,own,terrain)
  if not native then return end
  self.own=own
  local dt=math.max(0,math.min(.05,now-(self.lastProcess or now)));self.lastProcess=now
  for _=1,32 do
   local action=native.ag_poll();if action==0 then break end
   if ag and action==1 then self.mode=1-self.mode;self:clear();native.ag_hold(0)
   elseif ag and action==2 and self.mode==1 then
    if self.target then self:clear();native.ag_hold(0)
    elseif terrain and own and own.Position and finite(own.Pitch) and finite(own.Bank) and finite(own.Heading) then
     -- Fixed gun-style acquisition line is body-referenced, including roll.
     local cp,sp,ch,sh,cb,sb=math.cos(own.Pitch),math.sin(own.Pitch),math.cos(own.Heading),math.sin(own.Heading),math.cos(own.Bank),math.sin(own.Bank)
     local bx,by=math.cos(M.sight_pitch),math.sin(M.sight_pitch)
     local d={x=bx*cp*ch+by*(-sp*ch*cb-sh*sb),y=bx*sp+by*cp*cb,z=bx*cp*sh+by*(-sp*sh*cb+ch*sb)}
     local p=own.Position;local old=0
     -- A bounded ray/terrain intersection: no camera/FOV approximation or flat AGL plane.
     for step=1,math.ceil(M.max_designation_range/50) do
      local distance=math.min(step*50,M.max_designation_range)
      local x,y,z=p.x+d.x*distance,p.y+d.y*distance,p.z+d.z*distance;local ground=terrain(x,z)
      if not finite(ground) then break end
      if y<=ground then
       local lo,hi=old,distance
       for _=1,16 do local mid=(lo+hi)*.5;local h=terrain(p.x+d.x*mid,p.z+d.z*mid);if not finite(h)then break end;if p.y+d.y*mid>h then lo=mid else hi=mid end end
       local length=(lo+hi)*.5;local tx,tz=p.x+d.x*length,p.z+d.z*length
       local finalHeight=terrain(tx,tz)
       if finite(finalHeight) then self:clear();self.target={x=tx,y=finalHeight,z=tz}end
       break
      end
      old=distance
     end
    end
   end
  end
  if ag and self.mode==1 and self.target and terrain and own and own.Position and native.ag_slew then
   local sx,sy=native.ag_slew()
   if dt>0 and finite(sx) and finite(sy) and (math.abs(sx)>.05 or math.abs(sy)>.05) then
    local vx,vz=M.slew_velocity(own,self.target,sx,sy)
    local x=self.target.x+vx*dt
    local z=self.target.z+vz*dt
    local height=terrain(x,z);local p=own.Position
    if finite(height) and (x-p.x)^2+(height-p.y)^2+(z-p.z)^2<=M.max_designation_range^2 then
     self.target={x=x,y=height,z=z};self.solution=nil;self.job=nil;self.next=0;self.lastAlong=nil;self.lastReleaseCheck=nil;self.release=false;self.releaseUntil=-1
     -- Moving the aim point cancels existing consent; release and press again.
     self.epoch=self.epoch+1;native.ag_hold(0)
     self.lastMove=now
    end
   end
  end
  if self.target and own and own.Position then local p=own.Position;self.range=math.sqrt((self.target.x-p.x)^2+(self.target.y-p.y)^2+(self.target.z-p.z)^2) else self.range=0 end
  if not ag then self.job=nil;self.solution=nil;self.next=0;self.lastAlong=nil;self.lastReleaseCheck=nil;self.release=false end
  self:publish(now,false)
 end
 function c:update(now,input,profile,terrain,current,allow_solve)
  if not native or self.mode~=1 or not self.target then return end
  if profile.kind=='GUN' then self.job=nil;self.solution=nil;self:publish(now,false);return end
  local target=self.target;local p=input.origin;local velocity=input.velocity
  local key=tostring(input.name)..':'..tostring(input.station)
  if self.weapon~=key then self.weapon=key;self.job=nil;self.solution=nil;self.next=0;self.lastAlong=nil;self.lastReleaseCheck=nil;self.release=false end
  local dx,dz=target.x-p.x,target.z-p.z;local range=math.sqrt(dx*dx+dz*dz)
  local hs=math.sqrt(velocity.x^2+velocity.z^2);local speed=math.sqrt(hs^2+velocity.y^2)
  if hs<1 or range<1 or speed<1 then self:publish(now,false,range);return end
  if self.lastMove and now-self.lastMove<.15 then
   local closing=(dx*velocity.x+dz*velocity.z)/range
   local along=current and ((target.x-current.x)*velocity.x+(target.z-current.z)*velocity.z)/hs or -1
   self.solution={heading=math.atan2(dz,dx),pitch=input.pitch,epoch=self.epoch,time=now}
   self:publish(now,current~=nil,self.range,closing>1 and along>=0 and along/closing or -1,along,0,false)
   return
  end
  local heading=math.atan2(dz,dx);local fp=math.atan2(velocity.y,hs)
  local along,cross,ttr=0,0,-1
  if current then
   along=(target.x-current.x)*velocity.x/hs+(target.z-current.z)*velocity.z/hs
   cross=(target.x-current.x)*(-velocity.z/hs)+(target.z-current.z)*(velocity.x/hs)
   local closing=(dx*velocity.x+dz*velocity.z)/range
   if closing>1 and along>=0 then ttr=along/closing end
  end
  -- Reuse the current ammunition-specific CCIP trajectory. CCRP must not
  -- add synchronous future trajectories or extra terrain paging each frame.
  -- Countdown is a steady-flight estimate; the release crossing below uses
  -- the actual computed footprint, not countdown zero.
  self.job=nil
  local corrected=math.atan2(velocity.z,velocity.x)+math.atan2(cross,math.max(1,(dx*velocity.x+dz*velocity.z)/hs))
  self.solution={pitch=fp,heading=corrected,epoch=self.epoch,time=now,ttr=ttr}
  local valid=current~=nil
  -- Gate on the computed footprint, not aircraft course versus an ASL
  -- heading. Wind/crab can make those headings differ even at a valid hit.
  local alignment=current and math.abs(cross)<=M.release_corridor(self.range or math.sqrt(range*range+(target.y-p.y)^2))
  self.aligned=alignment
  local dt=self.lastReleaseCheck and now-self.lastReleaseCheck or 0
  local crossed=self.lastAlong and self.lastAlong>0 and along<=0 and dt>0 and dt<=.3
  local close=math.abs(along)<=math.max(2,hs*.025)
  local consent=native.ag_state().held==1
  -- Latch a detected crossing long enough for the cockpit input device to
  -- observe it. A slow export frame must not erase its own release event.
  if valid and current and alignment and (crossed or close) and consent then self.releaseUntil=now+.25 end
  self.release=valid and current and alignment and consent and now<=(self.releaseUntil or -1) and along>=-hs*.3 or false
  self.lastReleaseCheck=now
  self.lastAlong=current and along or nil
  self:publish(now,valid,self.range,ttr,along,cross,self.release)
 end
 return c
end
return M
