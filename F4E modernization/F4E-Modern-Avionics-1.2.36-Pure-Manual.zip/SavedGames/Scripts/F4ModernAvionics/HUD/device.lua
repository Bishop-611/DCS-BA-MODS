local update_harm=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/hud.lua]]))
local ccip=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/CCIP/device.lua]]))
local ccrpHud=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/CCIP/ccrp-hud.lua]]))
local update_uncage=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/heat-auto-uncage.lua]]))
local alignment=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/alignment.lua]]))
local update_dlz=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/dlz-device.lua]]))
local update_gun=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/gun-device.lua]]))
local weaponMath=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/weapon_math.lua]]))
local mathlib=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/flight_math.lua]]))
local ladder=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/ladder.lua]]))
local headingTape=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/heading-tape.lua]]))
local hudStep=1/60
local fpmCache=nil
local data=get_base_data()
local handles={}
local inputHandles={}
local function inputHandle(name)
    local h=inputHandles[name]
    if not h then h=get_param_handle(name);inputHandles[name]=h end
    return h
end
local elapsed,lastPosition=0,nil
local previousAttitude=nil
local lastLadderState=nil
local funnelCounts={L=0,R=0}
local function vector(name)
    local ok,x,y,z=pcall(function() return data[name](data) end)
    if type(x)=='table' then local v=x;x,y,z=v.x or v[1],v.y or v[2],v.z or v[3] end
    if ok and mathlib.finite(x) and mathlib.finite(y) and mathlib.finite(z) then return x,y,z end
end
local lastValues={}
local staged,buffer=nil,{}
local function set(name,value)
    if staged then staged[name]=value;return end
    if lastValues[name]==value then return end
    lastValues[name]=value
    if not handles[name] then handles[name]=get_param_handle('F4MH_'..name) end
    handles[name]:set(value)
end
local function read(name)
    local ok,v=pcall(function() return data[name](data) end)
    if ok and mathlib.finite(v) then return v end
end
make_default_activity(hudStep)
need_to_be_closed=false
local hud_device=GetSelf()
for command=3900,3913 do hud_device:listen_command(command) end
function SetCommand(command,value)
    ccip.command(command,value)
end
function post_initialize() set('VALID',0);set('FPM_VALID',0); end
local function shared(n)
        local ok,v=pcall(function() return inputHandle('F4MC_'..n):get() end)
        if ok and mathlib.finite(v) then return v end
    end
local function update_frame()
    elapsed=elapsed+hudStep
    local trimOK,trimY=true,-30 -- shared optical offset; no extra ladder offset
    trimY=trimOK and mathlib.finite(trimY) and trimY or 0
    set('VALID',0);set('FPM_VALID',0)
    local pitch,bank,heading=read('getPitch'),read('getRoll'),read('getHeading')
    local ias,alt=read('getIndicatedAirSpeed'),read('getBarometricAltitude')
    local agl=read('getRadarAltitude')
    -- Sensor values are metres. Exactly 500 ft and invalid AGL use MSL/barometric altitude.
    local useRadar=agl and agl>=0 and agl<152.4
    local displayedAlt=useRadar and agl or alt
    set('ATT_VALID',pitch and bank and 1 or 0)
    set('IAS_VALID',ias and 1 or 0);set('ALT_VALID',displayedAlt and 1 or 0);set('HDG_VALID',heading and 1 or 0)
    set('ALT_RADAR',useRadar and 1 or 0)
    local modeOK,mode=pcall(function() return get_cockpit_draw_argument_value(271) end)
    local index=modeOK and mathlib.finite(mode) and math.floor(mode/0.1666+0.5) or -1
    local landing=index==1
    -- Keep the calibrated optical origin. In STBY the native 3D glass mask,
    -- rather than the old rectangular FPM clamp, clips the flight presentation.
    local flightTrim=trimY
    set('LANDING',landing and 1 or 0)
    local onSpeedOK,onSpeed=false,0
    if landing then onSpeedOK,onSpeed=pcall(get_cockpit_draw_argument_value,78)end
    local showOnSpeed=landing and onSpeedOK and mathlib.finite(onSpeed) and onSpeed>.05
    if showOnSpeed then
        -- F-4 external draw_args.lua: nose=0, right main=3, left main=5.
        -- Require actual full extension; a DOWN handle alone is insufficient.
        -- Read only while STBY and the native on-speed lamp are active.
        for argument=0,5 do
            if argument==0 or argument==3 or argument==5 then
                local ok,position=pcall(get_aircraft_draw_argument_value,argument)
                if not ok or not mathlib.finite(position) or position<.99 or position>1.01 then
                    showOnSpeed=false;break
                end
            end
        end
    end
    set('LAND_ON_SPEED',showOnSpeed and 1 or 0)
    set('HUD_ON',index>=1 and index<=6 and 1 or 0) -- stock mode selector: OFF=0
    local intensityOK,intensity=pcall(get_cockpit_draw_argument_value,1201)
    set('BRIGHTNESS',intensityOK and mathlib.finite(intensity) and math.max(0,math.min(1,intensity)) or 0)
    for i=1,6 do set('MODE_'..i,index==i and 1 or 0) end

    local linked=shared('LINK')==1
    local aa=index==4 or index==2
    local tracked=inputHandle('RADAR_MODE'):get()==3 and inputHandle('RADAR_STT_RANGE'):get()>0
    local gunLightOK,gunLight=pcall(get_cockpit_draw_argument_value,274)
    local gunSelected=(linked and shared('WEAPON_5209')==1) or (gunLightOK and mathlib.finite(gunLight) and gunLight>.05)
    local heatOK,heatLight=pcall(get_cockpit_draw_argument_value,280) -- Heads_Up_Heat_Light, local draw_args.lua
    local heatSelected=(linked and shared('WEAPON_5208')==1) or (heatOK and mathlib.finite(heatLight) and heatLight>.05)
    -- The explicit original Radar switch owns AMRAAM selection; unsupported-store
    -- native annunciators must not leave gun/heat cues active for this missile.
    if aa and inputHandle('F4_AIM120_SELECTED'):get()==1 then gunSelected=false;heatSelected=false end
    set('IR_CUE',aa and heatSelected and not gunSelected and 1 or 0)
    update_uncage(false) -- user preference: original ARR remains manual only
    set('GUN_LEAD',aa and gunSelected and not tracked and 1 or 0);set('FIXED_REF',landing and 0 or 1)
    local ratePitch,rateYaw=read('getRateOfPitch'),read('getRateOfYaw')
    -- Some full-fidelity sensor tables omit body rates. Derive them from Euler
    -- attitude changes rather than suppressing the whole funnel in that case.
    if pitch and bank and heading and previousAttitude then
        local dp=(pitch-previousAttitude.pitch)/hudStep
        local dh=((heading-previousAttitude.heading+math.pi)%(2*math.pi)-math.pi)/hudStep
        if not ratePitch then ratePitch=dp*math.cos(bank)-dh*math.sin(bank)*math.cos(pitch) end
        if not rateYaw then rateYaw=-dp*math.sin(bank)-dh*math.cos(bank)*math.cos(pitch) end
    end
    if pitch and bank and heading then previousAttitude={pitch=pitch,bank=bank,heading=heading} else previousAttitude=nil end
    local spanOK,span=pcall(function() return inputHandle('F4MH_SPAN'):get() end)
    if not spanOK or not mathlib.finite(span) or span<5 then span=10 end
    set('FUNNEL_SPAN',span)
    local left,right
    if false then left,right=weaponMath.funnel(pitch,bank,ratePitch,rateYaw,span) end
    set('FUNNEL_VALID',left and 1 or 0)
    if left then
        -- Use the same proven mesh/parameter translation path as the FPM.
        -- Dense overlapping stroke samples avoid the unverified native line-point
        -- controller's coordinate/signature behavior entirely.
        for side,points in pairs({L=left,R=right}) do
            local count=0
            for i=1,#points-1 do
                local a,b=points[i],points[i+1]
                local dx,dy=b.x-a.x,b.y-a.y
                local steps=math.min(600,math.max(1,math.ceil(math.sqrt(dx*dx+dy*dy)/.9)))
                for j=0,steps-1 do
                    local t=j/steps;local x,y=a.x+dx*t,a.y+dy*t+trimY
                    if math.abs(x)<=110 and y>=-110 and y<=40 and count<256 then
                        count=count+1;set('FUN_'..side..'X_'..count,x);set('FUN_'..side..'Y_'..count,y);set('FUN_'..side..'SHOW_'..count,1)
                    end
                end
            end
            for i=count+1,funnelCounts[side] do set('FUN_'..side..'SHOW_'..i,0) end
            funnelCounts[side]=count
        end
    end

    local tx,ty,limited,bx,by,box_limited
    if aa and tracked then
        local az=inputHandle('RADAR_STT_AZIMUTH'):get()
        local el=inputHandle('RADAR_STT_ELEVATION'):get()
        tx,ty,limited=mathlib.ray(math.cos(el)*math.cos(az),math.sin(el),math.cos(el)*math.sin(az),trimY,true)
        -- STT supplies independent HUD angles; do not reinterpret elevation as spherical latitude.
        bx,by,box_limited=mathlib.hud_angles(az,el,alignment.target_y)

    end
    set('TD_VALID',tx and 1 or 0);set('TD_LIMIT',limited and 1 or 0)
    local onscreen=bx and not box_limited
    set('BOX_VALID',bx and 1 or 0);set('BOX_LIMIT',box_limited and 1 or 0)
    if bx then set('BOX_X',bx);set('BOX_Y',by) end
    set('TD_ONSCREEN',onscreen and 1 or 0)
    local iff=inputHandle('RADAR_STT_FRIENDLY'):get()
    local interrogating=inputHandle('IFF_INTERROGATOR_STATUS'):get()==1
    set('TD_IFF_FRIEND',onscreen and interrogating and iff==1 and 1 or 0)
    set('TD_IFF_FOE',onscreen and interrogating and iff==0 and 1 or 0)
    set('TD_IFF_NONE',onscreen and (not interrogating or (iff~=0 and iff~=1)) and 1 or 0)
    if tx then set('TD_X',tx);set('TD_Y',ty) end
    set('RADAR_INFO',aa and tracked and 1 or 0)
    set('VSI_SHOW',not (aa and tracked) and 1 or 0)
    set('RADAR_RANGE',inputHandle('RADAR_STT_RANGE'):get()/1852)
    set('RADAR_VC_VALID',aa and tracked and inputHandle('F4_SR_CLOSURE_VALID'):get() or 0)
    set('RADAR_VC',inputHandle('F4_SR_CLOSURE_KT'):get())
    set('ACM',aa and inputHandle('F4_SR_ACM'):get() or 0)
    -- Keep basic attitude until the F-16 gun attitude-awareness replacement is validated.
    set('ATT_VALID',pitch and bank and 1 or 0)
    set('GUN_TRACK',aa and gunSelected and tracked and 1 or 0)
    set('MISSILE_TRACK',aa and not gunSelected and tracked and 1 or 0)
    -- DCS base sensor heading is counterclockwise; displayed heading is true, clockwise.
    if heading then heading=(-heading)%(2*math.pi) end
    if ias then set('IAS',ias*1.94384449) end
    if displayedAlt then set('ALT',displayedAlt/0.3048) end
    local alpha=read('getAngleOfAttack')
    set('ALPHA_VALID',alpha and 1 or 0);set('ALPHA',alpha and math.deg(alpha) or 0)
    if pitch and bank then set('PITCH',pitch*1000);set('BANK',bank) end
    -- The active page consumes LR_/LL_ from ladder.update below.
    -- Legacy LADDER_X/Y/SHOW outputs have no display consumers.
    local degrees=heading and math.deg(heading)%360
    if degrees then
        set('HDG',math.floor(degrees+0.5)%360)
        headingTape.update(degrees,set)
    end
    local mach,g,vvi=read('getMachNumber'),read('getVerticalAcceleration'),read('getVerticalVelocity')
    set('MACH_VALID',mach and 1 or 0);set('MACH',mach or 0)
    set('G_VALID',g and 1 or 0);set('G',g or 0)
    set('VVI_VALID',vvi and 1 or 0);set('VVI',(vvi or 0)*196.8503937)
    local x,y,z=vector('getSelfVelocity')
    local cx,cy,cz=vector('getSelfCoordinates')
    local timeOK,now=pcall(function() return get_model_time() end)
    if not timeOK or not mathlib.finite(now) then now=elapsed end
    if cx then
        if not x and lastPosition then
            local dt=now-lastPosition.time
            if dt>0 and dt<=0.25 then
                local vx,vy,vz=(cx-lastPosition.x)/dt,(cy-lastPosition.y)/dt,(cz-lastPosition.z)/dt
                local speed=math.sqrt(vx*vx+vy*vy+vz*vz)
                if speed<1500 then x,y,z=vx,vy,vz end
            end
        end
        lastPosition={x=cx,y=cy,z=cz,time=now}
    else lastPosition=nil end
    local px,py,limited
    if x and pitch and bank and heading then
        local c=fpmCache
        if c and c.landing==landing and math.abs(x-c.vx)<.02 and math.abs(y-c.vy)<.02 and math.abs(z-c.vz)<.02
            and math.abs(pitch-c.pitch)<1e-5 and math.abs(bank-c.bank)<1e-5 and math.abs(heading-c.heading)<1e-5 then
            px,py,limited=c.x,c.y,c.limited
        else
            if landing then
                if x*x+y*y+z*z>=1 then
                    local f,u,r=mathlib.body(x,y,z,pitch,bank,heading)
                    px,py=mathlib.ray(f,u,r,flightTrim,false)
                    -- Do not feed unbounded geometry near a 90-degree ray.
                    if px and (math.abs(px)>1000 or math.abs(py)>1000) then px,py=nil,nil end
                end
                limited=false
            else px,py,limited=mathlib.velocity(x,y,z,pitch,bank,heading,flightTrim) end
            if px then px=math.floor(px*100+.5)/100;py=math.floor(py*100+.5)/100 end
            fpmCache={vx=x,vy=y,vz=z,pitch=pitch,bank=bank,heading=heading,x=px,y=py,limited=limited,landing=landing}
        end
    end
    if px then
        set('FPM_X',px);set('FPM_Y',py);set('FPM_LIMIT',limited and 1 or 0);set('FPM_VALID',1)
    end
    set('FPM_MISSING',px and 0 or 1)
    -- This cue means below the central layout, not outside the physical glass.
    set('LAND_FPM_LOW',landing and py and py < -100 and 1 or 0)
    local ladderReference=0
    if x and z and heading and x*x+z*z>1 and not limited then ladderReference=(math.atan2(z,x)-heading+math.pi)%(2*math.pi)-math.pi end
    local function changed(a,b)if a==nil or b==nil then return a~=b end;return math.abs(a-b)>1e-5 end
    local ladderChanged=not lastLadderState or changed(pitch,lastLadderState.pitch) or changed(bank,lastLadderState.bank) or changed(ladderReference,lastLadderState.reference) or lastLadderState.landing~=landing
    if ladderChanged then
        lastLadderState={pitch=pitch,bank=bank,reference=ladderReference,landing=landing}
        ladder.update(mathlib,pitch,bank,flightTrim,ladderReference,set,landing)
    end
    local combat={aa=aa,gun=gunSelected,pitch=pitch,bank=bank,heading=heading,altitude=alt,vx=x,vy=y,vz=z,time=now}
    update_dlz(combat);update_gun(combat)
    local tvOK,tv=pcall(get_cockpit_draw_argument_value,2599)
    local selectorOK,selector=pcall(get_cockpit_draw_argument_value,273)
    local deliveryAG=index==3 and not(selectorOK and type(selector)=='number' and ((selector>=.10 and selector<=.17) or (selector>=.24 and selector<=.30)))
    ccip.update({ag=deliveryAG and ccrpHud.mode()==0,time=now,
        x=cx,y=cy,z=cz,pitch=pitch,bank=bank,heading=heading,fpm_x=px,fpm_y=py})
    local agPoseFrame=ccrpHud.update({ag=deliveryAG,time=now,x=cx,y=cy,z=cz,pitch=pitch,bank=bank,heading=heading,fpm_y=py})
    update_harm({ag=index==3,time=now,pose=agPoseFrame,x=cx,y=cy,z=cz,pitch=pitch,bank=bank,heading=heading})
    set('VALID',pitch and bank and heading and ias and alt and 1 or 0)
end

function update()
    staged=buffer;update_frame()
    local final=staged;staged=nil
    for name,value in pairs(final)do set(name,value);final[name]=nil end
end
