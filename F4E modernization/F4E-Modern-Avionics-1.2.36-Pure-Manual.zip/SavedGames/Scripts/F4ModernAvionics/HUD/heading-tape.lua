-- Thirteen five-degree marks cover the visible +/-27 degrees around the nearest
-- ten-degree mark. Only the center and its two adjacent major marks can be labelled.
local M={slots={}}
for offset=-6,6 do
    local key='HT_'..(offset+6)..'_'
    local major=offset%2==0
    local slot={offset=offset,major=major,x=key..'X',show=key..'SHOW'}
    if major and math.abs(offset)<=2 then
        slot.label=key..'LABEL'
        slot.labelShow=key..'LABEL_SHOW'
    end
    M.slots[#M.slots+1]=slot
end

local previous
function M.update(degrees,set)
    if degrees==previous then return end
    previous=degrees
    local center=math.floor(degrees/10+.5)*2
    for _,slot in ipairs(M.slots) do
        local mark=(center+slot.offset)%72
        local delta=(mark*5-degrees+180)%360-180
        local visible=math.abs(delta)<=27
        set(slot.show,visible and 1 or 0)
        if visible then set(slot.x,delta*2.8) end
        if slot.label then
            set(slot.labelShow,math.abs(delta)<=12 and 1 or 0)
            set(slot.label,mark/2)
        end
    end
end
return M
