-- AIM-120B display-only envelope profile for the existing approximate planar solver.
-- Source: DCS CoreMods/aircraft/AircraftWeaponPack/aim120_family.lua, AIM_120B.
-- Exact stock values: mass, reference area, motor starts/durations/fuel/impulses,
-- Mach tables at 0.2 spacing, gload_limit, Knav, fuze arm_delay, D_min and v_min.
-- Solver assumptions: 6-G target escape, 0.15 s integration, ISA atmosphere,
-- linear altitude interpolation, no native loft/seeker simulation, and the existing
-- target-speed-plus-50 m/s terminal-energy requirement. These are NOT native DLZ.
-- Use the stock 80 s autopilot/sensor operating time, not the 90 s Life_Time,
-- as the finite guidance horizon. No maximum-speed clamp is modeled (stock Mach_max=4).
local source_k1={0.0039,0.0039,0.0039,0.0039,0.0039,0.0048,0.004,0.00325,0.002845,0.002602,0.002378,0.002176,0.001994,0.001832,0.001689,0.001564,0.001456,0.001366,0.00129,0.001229,0.001182,0.001147,0.001123,0.001108,0.001101,0.0011}
local source_k2={-0.0041,-0.0041,-0.0041,-0.0041,-0.0041,-0.0049,-0.0042,-0.0036,-0.003121,-0.002725,-0.002408,-0.00213,-0.001888,-0.001677,-0.001494,-0.001334,-0.001196,-0.001077,-0.000973,-0.000884,-0.000808,-0.000743,-0.000689,-0.000646,-0.000615,-0.0006}
local linear,quadratic={},{}
for i=1,#source_k1 do
 -- The shared solver expects linear+quadratic induced drag. Native K2 is negative;
 -- inserting it as the quadratic term produces negative drag at high incidence.
 -- Conservative display approximation: omit the negative correction and use the
 -- positive native K1 as the quadratic term. Preserve both source tables below.
 linear[i]=0;quadratic[i]=source_k1[i]
end
return {
 name='AIM-120B',mass=157.85,area=.0248,minimum_range=700,arm_delay=1.6,
 lifetime=80,minimum_speed=140,max_g=30,pn=4,turn_g=6,step=.15,
 boost={start=.5,duration=2.1,fuel=18.21,isp=236},
 sustain={start=2.6,duration=5,fuel=28.33,isp=227},
 cx={0.515,0.515,0.515,0.515,0.527,0.85,0.949,0.905,0.8605,0.8094,0.7636,0.7204,0.6813,0.6458,0.6135,0.5839,0.5567,0.5316,0.5082,0.4864,0.4659,0.4468,0.4288,0.4121,0.3968,0.384},base_drag={0.021,0.021,0.021,0.021,0.021,0.138,0.153,0.146,0.1382,0.1272,0.1167,0.1073,0.0987,0.0909,0.0837,0.077,0.0708,0.065,0.0595,0.0544,0.0495,0.0449,0.0406,0.0364,0.0324,0.0286},cya={0.345,0.345,0.345,0.345,0.357,0.401,0.448,0.495,0.513,0.506,0.5,0.495,0.49,0.486,0.482,0.478,0.474,0.471,0.468,0.465,0.462,0.46,0.457,0.455,0.453,0.451},
 k1=linear,k2=quadratic,source_k1=source_k1,source_k2=source_k2
}
