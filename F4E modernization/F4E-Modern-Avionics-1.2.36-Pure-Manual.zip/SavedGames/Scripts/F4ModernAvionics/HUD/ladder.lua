-- Sparse tangent-plane ladder: one rigid stroke per rung side, exact projected
-- anchors/labels and projected horizontal orientation; no per-pixel controllers.
local M={rows={}}
for row=0,34 do
 local deg=row*5-85;local slope=deg<0 and math.tan(math.rad(deg/2))or 0
 for side=1,2 do
  local sign=side==1 and -1 or 1
  local item={degree=deg,sign=sign,key='LR_'..row..'_'..side,label='LL_'..row..'_'..side,vertical=slope*25,lines={}}
  local extent=deg==0 and 170 or 25
  if deg<0 then
   for a=0,24,8 do local b=math.min(a+4,25);item.lines[#item.lines+1]={{a,slope*a*sign},{b,slope*b*sign}}end
  else item.lines[1]={{0,0},{extent,0}}end
  if deg~=0 then item.lines[#item.lines+1]={{25,slope*25*sign},{25,(slope*25+(deg>0 and -4 or 4))*sign}}end
  M.rows[#M.rows+1]=item
 end
end
function M.update(mathlib,pitch,bank,trim,reference,set,landing)
 local project=mathlib.prepare_ladder(pitch,bank,trim,reference)
 local pitchDeg=pitch and math.deg(pitch)or 0
 for _,item in ipairs(M.rows)do
  local deg,sign=item.degree,item.sign
  local visible=project and math.abs(deg-pitchDeg)<=25
  local x,y,angle,shown
  if visible then
   x,y=project(deg,16*sign,0)
   local bx,by=project(deg,41*sign,0)
   local ex,ey=project(deg,(deg==0 and 186 or 41)*sign,item.vertical)
   if x and bx and ex then
    angle=math.atan2(by-y,bx-x)
    local lower=landing and -400 or -110
    shown=math.min(x,ex)<=110 and math.max(x,ex)>=-110 and math.min(y,ey)<=40 and math.max(y,ey)>=lower
   end
  end
  set(item.key..'V',shown and 1 or 0)
  if shown then set(item.key..'X',x);set(item.key..'Y',y);set(item.key..'A',angle)end
  local lx,ly,labelShown
  if visible and deg~=0 then lx,ly,labelShown=project(deg,50*sign,item.vertical)end
  if landing and lx then labelShown=math.abs(lx)<=110 and ly>=-400 and ly<=40 end
  set(item.label..'V',labelShown and 1 or 0)
  if labelShown then set(item.label..'X',lx);set(item.label..'Y',ly)end
 end
end
return M
