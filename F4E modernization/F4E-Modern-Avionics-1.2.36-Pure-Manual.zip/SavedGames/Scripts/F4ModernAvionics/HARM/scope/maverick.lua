dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/tv-wrap.lua]]))(LockOn_Options.script_path..'Scripts/DSCG/indicator/TV_Indicator/maverick_page.lua','scope_maverick')
