-- Bounded data only, never evaluated as Lua. 10 Hz, two in-process mailboxes.
local M={}
function M.finite(v)return type(v)=='number'and v==v and math.abs(v)<1e10 end
function M.pack(rows)
 local lines={}
 for _,row in ipairs(rows)do
  local fields={};for _,v in ipairs(row)do
   fields[#fields+1]=type(v)=='number'and string.format('%.12g',v)or tostring(v):gsub('[\t\r\n]',' ')
  end
  lines[#lines+1]=table.concat(fields,'\t')
 end
 local text=table.concat(lines,'\n');return #text<8192 and text or ''
end
function M.unpack(text)
 if type(text)~='string'or #text>=8192 then return {} end
 local rows={}
 for line in text:gmatch('[^\n]+')do
  local row={};for value in line:gmatch('[^\t]+')do row[#row+1]=tonumber(value)or value end
  rows[#rows+1]=row;if #rows>20 then return {} end
 end
 return rows
end
return M
