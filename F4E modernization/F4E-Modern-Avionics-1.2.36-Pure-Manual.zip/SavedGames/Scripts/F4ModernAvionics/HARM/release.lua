-- One native release per physical press. An empty selection explicitly requests unassigned release; a failed targeted call never retries as unassigned.
local M={};M.__index=M
function M.new(native)return setmetatable({native=native,held=false,pending=nil,fault=false,status='IDLE'},M)end
function M:update(frame,now)
 local p=self.pending;if not p then return end
 local count=frame and frame.counts and frame.counts[p.station]
 if frame and frame.time>=p.time and type(count)=='number' then
  if count==p.count-1 then self.pending=nil;self.status='RELEASE_CONFIRMED';return end
  if count~=p.count then self.pending=nil;self.fault=true;self.status='UNEXPECTED_PAYLOAD_CHANGE';return end
 end
 if now-p.time>5 then self.pending=nil;self.fault=true;self.status='RELEASE_UNCONFIRMED' end
end
-- Readiness to supply the chosen target with a launch, not a seeker acknowledgement.
function M:handoff_ready(selection,context,frame,now)
 if self.fault or self.pending or not self.native or type(self.native.run)~='function'then return false end
 local packet=selection:handoff(context,now,false)
 return packet~=nil and packet.mode=='SP' and frame~=nil and now-frame.time>=0 and now-frame.time<=.25
  and frame.station==packet.station and frame.harm==true and frame.count>=1 or false
end
function M:command(value,selection,context,frame,now)
 local down=value>.5;local edge=down and not self.held;self.held=down
 if not edge then return end
 if self.fault or self.pending then return end
 local packet,reason=selection:handoff(context,now,true)
 if not packet then self.status=reason;return end
 if not frame or now-frame.time<0 or now-frame.time>.25 or frame.station~=packet.station or not frame.harm or frame.count<1 then self.status='PAYLOAD_STALE';return end
 if not self.native then self.status='NATIVE_UNAVAILABLE';return end
 -- Set pending before calling native: exceptions/zero results must never auto-retry.
 self.pending={station=packet.station,count=frame.count,time=now}
 local ok,status,raw,accepted
 if packet.mode=='UNASSIGNED' then
  ok,status,raw,accepted=pcall(self.native.run_unassigned,packet.station-1)
 else
  ok,status,raw,accepted=pcall(self.native.run,packet.station-1,packet.emitter,packet.x,packet.y,packet.z)
 end
 if not ok or not accepted or type(raw)~='number'or raw<=0 then
  self.pending=nil;self.fault=true;self.status='RELEASE_UNCONFIRMED';return
 end
 self.status='RELEASE_PENDING'
end
return M
