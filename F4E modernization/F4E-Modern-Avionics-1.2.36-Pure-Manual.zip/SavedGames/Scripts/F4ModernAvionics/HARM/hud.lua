local mathlib=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/flight_math.lua]]))
local handles,values={},{}
local function p(n)if not handles[n]then handles[n]=get_param_handle(n)end;return handles[n]end
local function set(n,v)if values[n]~=v then values[n]=v;p(n):set(v)end end
return function(s)
 local active=s.ag and p('F4_HARM_ACTIVE'):get()==1 and p('F4_HARM_TARGET_VALID'):get()==1
 local stamp=p('F4_HARM_TARGET_STAMP'):get()
 local fresh=type(stamp)=='number'and s.time-stamp>=-.05 and s.time-stamp<=.5
 local x,y,limited
 -- World targets and own-aircraft pose must use the same Export convention.
 -- Reuse the state already read by CCRP this frame; no extra native polling.
 local pose=s.pose
 local poseFresh=pose and pose.pose_valid==1 and mathlib.finite(pose.pose_time)and s.time-pose.pose_time>=-.05 and s.time-pose.pose_time<=.25
 if active and fresh and poseFresh and mathlib.finite(pose.ox)and mathlib.finite(pose.oy)and mathlib.finite(pose.oz)
 and mathlib.finite(pose.opitch)and mathlib.finite(pose.obank)and mathlib.finite(pose.oheading)then
  x,y,limited=mathlib.project(p('F4_HARM_TARGET_X'):get()-pose.ox,p('F4_HARM_TARGET_Y'):get()-pose.oy,p('F4_HARM_TARGET_Z'):get()-pose.oz,pose.opitch,pose.obank,pose.oheading,-30)
 end
 set('F4_HARM_HUD_SHOW',x and not limited and 1 or 0)
 if x then set('F4_HARM_HUD_X',x);set('F4_HARM_HUD_Y',y)end
end
