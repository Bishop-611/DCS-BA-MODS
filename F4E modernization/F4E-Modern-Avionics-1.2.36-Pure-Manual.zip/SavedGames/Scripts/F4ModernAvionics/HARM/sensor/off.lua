dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/tv-wrap.lua]]))(LockOn_Options.script_path..'Scripts/DSCG/indicator/off_page.lua','sensor_off')
