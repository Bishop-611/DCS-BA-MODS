dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/tv-wrap.lua]]))(LockOn_Options.script_path..'Scripts/DSCG/indicator/TV_Sensor/pave_spike_page.lua','sensor_pave_spike')
