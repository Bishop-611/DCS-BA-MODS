dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/tv-wrap.lua]]))(LockOn_Options.script_path..'Scripts/DSCG/indicator/TV_Sensor/maverick_page.lua','sensor_maverick')
