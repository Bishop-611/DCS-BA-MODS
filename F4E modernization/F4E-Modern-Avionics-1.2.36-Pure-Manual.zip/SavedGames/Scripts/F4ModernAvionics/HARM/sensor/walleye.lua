dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/tv-wrap.lua]]))(LockOn_Options.script_path..'Scripts/DSCG/indicator/TV_Sensor/walleye_page.lua','sensor_walleye')
