dofile(LockOn_Options.script_path..'Scripts/DSCG/indicator/TV_Indicator/init.lua')
page_subsets[MAVERICK]=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/scope/maverick.lua]])
page_subsets[PAVE_SPIKE]=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/scope/pave_spike.lua]])
page_subsets[WALLEYE]=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/scope/walleye.lua]])
page_subsets[OFF]=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/scope/off.lua]])
page_subsets[HOBOS]=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/scope/hobos.lua]])
local HARM=7
page_subsets[HARM]=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/plan-page.lua]])
for _,page in ipairs(pages)do page[#page+1]=HARM end
