return function(path,tag)
 local original=Add
 local gate=CreateElement 'ceSimple';gate.name='F4_HARM_NATIVE_TV_'..tag;gate.init_pos={0,0,0}
 gate.element_params={'F4_TV_PLAN_PAGE'};gate.controllers={{'parameter_in_range',0,-.5,.5}}
 original(gate)
 Add=function(e)
  local parent=e.parent_element
  if parent==nil or parent==''then e.parent_element=gate.name end
  original(e)
 end
 local ok,err=pcall(dofile,path);Add=original
 if not ok then error(err)end
end
