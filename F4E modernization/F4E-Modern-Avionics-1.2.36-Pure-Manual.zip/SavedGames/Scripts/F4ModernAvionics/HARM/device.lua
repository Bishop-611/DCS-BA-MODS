local root=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/]])
local native=dofile(root..'native.lua')
local wire=dofile(root..'wire.lua');local decode=dofile(root..'export-core.lua').decode
local selection=dofile(root..'selection.lua').new()
local release=dofile(root..'release.lua').new(native)
local plan=dofile(root..'plan-view.lua');local project=plan.project
local codes=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/RWR/upstream/Systems/rwr_codes.lua]]))
local identifiers={}
local rememberedLabel,displayRevision=nil,-1
local function finite(v)return type(v)=='number'and v==v and math.abs(v)<1e10 end
local dev=GetSelf();local handles,values={},{}
local nextData,nextZone,lastZoneTarget=0,0,nil
local frame,context,lastPacket=nil,{},nil
local function p(n)if not handles[n]then handles[n]=get_param_handle(n)end;return handles[n]end
local function set(n,v)if values[n]~=v then p(n):set(v);values[n]=v end end
local function draw(n)local ok,v=pcall(get_cockpit_draw_argument_value,n);return ok and type(v)=='number'and v or -1 end
local function now()return get_model_time()end
local rwr={}
for i=1,16 do local prefix=string.format('RWR_CONTACT_%02d_',i);rwr[i]={}
 for _,key in ipairs({'SOURCE','UNIT_TYPE','TIME','POWER','SIGNAL'})do rwr[i][key]=p(prefix..key)end
end
local function refresh(t)
 if not native then frame=nil else local packet=native.get(1);if packet~=lastPacket then lastPacket=packet;frame=decode(wire.unpack(packet))end end
 local fresh=frame and t>=frame.time-.05 and t-frame.time<=.3
 context={ag=math.floor(draw(271)/.1666+.5)==3,tv=draw(2599)>.75,harm=fresh and frame.harm or false,
  exportAllowed=fresh and frame.allowed or false,rwrPower=p('EXFULL_RWR_POWER'):get()>.5,masterArm=draw(247)>.5,
  station=fresh and frame.station or 0,stationVerified=fresh and frame.harm or false}
 selection:update(context,fresh and frame.contacts or {},nil,t)
 release:update(fresh and frame or nil,t)
 return fresh
end
function post_initialize()
 if native then native.reset()end
 set('F4_TV_PLAN_FOCUS',0);set('F4_TV_PLAN_PAGE',0);set('F4_TV_STATION_SYNC',0)
 set('F4_HARM_ACTIVE',0);set('F4_HARM_TARGET_VALID',0);set('F4_HARM_IN_RANGE',0);set('F4_HARM_HANDOFF_READY',0)
 for i=1,16 do local pre='F4_HARM_T'..i..'_'
  set(pre..'SHOW',0);set(pre..'TXT','U');set(pre..'NUM',0);set(pre..'CN',1)
 end
end
function SetCommand(command,value)
 local t=now();refresh(t);set('F4_HARM_HANDOFF_READY',0)
 if command==3001 then selection:nws(value);nextZone=0;set('F4_HARM_IN_RANGE',0)
 elseif command==3002 then release:command(value,selection,context,frame,t)end
end
for _,cmd in ipairs({3001,3002})do dev:listen_command(cmd)end
make_default_activity(.05);need_to_be_closed=false
function update()
 local t=now();local fresh=refresh(t)
 if native and t>=nextData then
  nextData=t+.1
  local rows={{'R',t,context.rwrPower and 1 or 0}}
  identifiers={}
  if context.ag and context.tv then for _,r in ipairs(rwr)do
   local unit=r.UNIT_TYPE:get()
   if type(unit)=='string'and unit~=''then local source=r.SOURCE:get();identifiers[source]=codes.code(unit);rows[#rows+1]={source,unit,r.TIME:get(),r.POWER:get(),r.SIGNAL:get()}end
  end end
  native.put(0,wire.pack(rows))
 end
 set('F4_HARM_HANDOFF_READY',release:handoff_ready(selection,context,frame,t)and 1 or 0)
 local target=selection:target();set('F4_HARM_TARGET_VALID',target and 1 or 0)
 if target then
  set('F4_HARM_TARGET_X',target.position.x);set('F4_HARM_TARGET_Y',target.position.y);set('F4_HARM_TARGET_Z',target.position.z)
  set('F4_HARM_TARGET_STAMP',t)
 end
 if not target or not fresh then set('F4_HARM_IN_RANGE',0);lastZoneTarget=nil
 elseif not(finite(frame.own.speed)and frame.own.speed>=0 and frame.own.speed<=1500
  and finite(frame.own.position.y)and frame.own.position.y>=-1000 and frame.own.position.y<=60000)then
  -- Old or incomplete Export frames retain their target presentation, but a
  -- previously valid range cue must clear immediately when kinematics vanish.
  set('F4_HARM_IN_RANGE',0);lastZoneTarget=nil;nextZone=0

 elseif t>=nextZone or lastZoneTarget~=target.id then
  nextZone=t+.25;lastZoneTarget=target.id
  local a,b=frame.own.position,target.position
  local distance=math.sqrt((a.x-b.x)^2+(a.y-b.y)^2+(a.z-b.z)^2)
  local result,reason=0,'native_api_unavailable'
  local ok,status,minimum,maximum,basis=false,'native_unavailable',nil,nil,nil
  if native and type(native.zone)=='function'then
   -- Target MSL remains the third argument. Own MSL is explicitly fifth, so
   -- native launch-table lookup cannot accidentally use the target altitude.
   ok,status,minimum,maximum,basis=pcall(native.zone,frame.station-1,distance,b.y,frame.own.speed,a.y)
   reason='native_result_unavailable'
   if not ok then status='native_error';minimum=nil;maximum=nil;basis=nil;reason='native_error'end
  end
  if ok and status=='f4_harm_native_zone'and finite(minimum)and finite(maximum)and minimum>=0 and maximum>minimum then
   result=distance>=minimum and distance<=maximum and 1 or 0
   reason=result==1 and 'available' or 'outside'
  elseif ok and status=='f4_harm_native_zone'then
   reason='native_bounds_invalid'
  end

  -- Publish only the completed answer; do not flash a zero between valid queries.
  set('F4_HARM_IN_RANGE',result)
 end
 if selection.revision~=displayRevision then
  displayRevision=selection.revision
  rememberedLabel=target and (identifiers[target.id] or 'U')
 end
 local displayContacts={}
 if target then displayContacts[1]=target end
 for _,contact in ipairs(selection.targets)do
  if not target or contact.id~=target.id then displayContacts[#displayContacts+1]=contact end
 end
 for i=1,16 do
  local prefix='F4_HARM_T'..i..'_';local contact=displayContacts[i]
  local x,y
  if contact and frame then x,y=project(frame.own,contact.position,50*1852)end
  if x and contact.id==selection.selected then x,y=plan.selected_anchor(x,y)end
  local label=contact and ((contact==target and rememberedLabel) or identifiers[contact.id] or 'U') or 'U'
  local number=tonumber(label)
  set(prefix..'TXT',number and 'U' or label)
  set(prefix..'NUM',number or 0);set(prefix..'CN',number and 1 or 0)
  set(prefix..'SHOW',x and 1 or 0)
  if x then set(prefix..'X',x);set(prefix..'Y',y);local lx,ly=plan.label(x,y);set(prefix..'LABEL_X',lx);set(prefix..'LABEL_Y',ly);local bx,by=plan.label(x,y,-1);set(prefix..'LOWER_X',bx);set(prefix..'LOWER_Y',by)end
  set(prefix..'SELECTED',contact and contact.id==selection.selected and 1 or 0)
 end
 -- Publish page visibility only after every label has a valid, stable type.
 set('F4_HARM_ACTIVE',selection.active and 1 or 0)
 local focus=fresh and context.ag and context.tv and frame.planPage
 set('F4_TV_PLAN_FOCUS',focus and 1 or 0)
 local visible=focus or (fresh and context.ag and context.tv and frame.keepDisplay)
 set('F4_TV_STATION_SYNC',visible and not selection.active and 1 or 0)
 set('F4_TV_PLAN_PAGE',visible and 1 or 0)
end
