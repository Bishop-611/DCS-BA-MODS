local path=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/F4Harm.dll]])
if not(package and package.loadlib)then return nil end
local ok,loader=pcall(package.loadlib,path,'luaopen_F4Harm')
if not ok or type(loader)~='function'then return nil end
local loaded,lib=pcall(loader)
return loaded and type(lib)=='table' and lib or nil
