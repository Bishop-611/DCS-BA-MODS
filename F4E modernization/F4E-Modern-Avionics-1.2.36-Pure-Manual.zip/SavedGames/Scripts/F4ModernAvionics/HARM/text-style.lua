local path=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/RWR/upstream/]])
dofile(path..'Displays/texture_font_chars.lua')
local font=MakeFont({texture=path..'IndicationTextures/'..TEXFONT_WEIGHTS.medium,
 size=TEXFONT_SIZE,resolution=TEXFONT_RES,default=TEXFONT_RECT,chars=texfont_chars},{50,255,90,255})
local u=.8*1.5*.70*.065/TEXFONT_CAP -- larger HARM glyphs; same modern-RWR medium atlas
return {font=font,stringdefs={1.75*TEXFONT_RECT_Y*u/TEXFONT_SIZE[1],1.75*2*TEXFONT_RECT_X*u/TEXFONT_SIZE[2],0,0}}
