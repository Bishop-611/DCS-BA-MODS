-- Stock AGM-88/LAU-118 store; only pylons already supporting the standard Shrike.
return function(aircraft)
 local function copy(v)if type(v)~='table'then return v end;local t={};for k,x in pairs(v)do t[k]=copy(x)end;return t end
 local allowed={[1]=true,[3]=true,[11]=true,[13]=true};local changes=0
 for index,pylon in pairs(aircraft.Pylons or {})do
  local number=pylon.Number or pylon.number or index
  if allowed[number]then
   local seed,exists
   for _,launcher in ipairs(pylon.Launchers or {})do
    if launcher.CLSID=='{LAU_34_AGM_45A}'then seed=launcher end
    if launcher.CLSID=='{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}'then exists=true end
   end
   if seed and not exists then
    local launcher=copy(seed);launcher.CLSID='{B06DD79A-F21E-4EB9-BD9D-AB3844618C93}'
    pylon.Launchers[#pylon.Launchers+1]=launcher;changes=changes+1
   end
  end
 end
 assert(changes==4,'F-4 AGM-88: expected four verified Shrike-compatible pylons')
end
