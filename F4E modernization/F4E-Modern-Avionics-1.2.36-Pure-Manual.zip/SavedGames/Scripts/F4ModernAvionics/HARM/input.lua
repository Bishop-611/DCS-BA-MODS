-- Reuses existing NWS and release options, including both key-up routes.
local M={}
function M.new(active,send,page)
 page=page or active
 local owned={}
 local pagePress,delivered=nil,false
 return function(kind,value)
  if kind=='nws'then
   -- A button belongs to the page that received its down edge. Never queue
   -- a press while waiting for the simulator to confirm a changed station.
   if value>.5 then
    if pagePress==nil then
     pagePress=page()
     delivered=pagePress and active()
     if delivered then send(3001,value)end
    end
    return pagePress
   end
   local owner=pagePress
   if delivered then send(3001,value)end
   pagePress,delivered=nil,false
   return owner==true
  end
  if kind~='bomb_release'then return false end
  local enabled=active();local held=owned[kind]
  if enabled or held then
   send(3002,value)
   owned[kind]=value>.5
   return true
  end
  -- Observe held input while inactive, preventing a synthetic edge on mode entry.
  send(3002,value)
  return false
 end
end
return M
