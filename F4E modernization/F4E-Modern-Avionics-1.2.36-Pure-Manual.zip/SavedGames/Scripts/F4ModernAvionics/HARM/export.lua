if F4HarmExportLoaded then return end
F4HarmExportLoaded=true
local root=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/HARM/]])
local native=dofile(root..'native.lua');if not native then return end
local wire=dofile(root..'wire.lua');local core=dofile(root..'export-core.lua')
local nextTime=-1
local previousStart,previousStop,previousAfter=LuaExportStart,LuaExportStop,LuaExportAfterNextFrame
function LuaExportStart()
 if previousStart then previousStart()end
 native.reset();core.resetPage();nextTime=-1
end
function LuaExportStop()
 native.reset();if previousStop then previousStop()end
end
function LuaExportAfterNextFrame()
 if previousAfter then previousAfter()end
 local now=LoGetModelTime();if type(now)~='number'then return end
 if now<nextTime-1 then nextTime=-1;native.reset();core.resetPage()end
 if now<nextTime then return end;nextTime=now+.1
 local ok,rows=pcall(core.capture,_G,wire.unpack(native.get(0)),now)
 native.put(1,ok and wire.pack(rows)or '')
end

-- Reuse this installed export entry; independent AA mailboxes preserve HARM state.
dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/AMRAAM/export.lua]]))
