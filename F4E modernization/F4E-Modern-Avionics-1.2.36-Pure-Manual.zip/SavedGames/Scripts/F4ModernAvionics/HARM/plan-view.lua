-- Heading-up plan view: ownship at origin, forward up, right right. No attitude/elevation axes.
local M={extent=.72,range_m=50*1852}
local function finite(x)return type(x)=='number' and x==x and math.abs(x)<1e10 end
function M.project(own,target,range)
 if not own or not own.position or not target then return nil end
 local p=own.position;range=range or M.range_m
 if not(finite(p.x)and finite(p.z)and finite(target.x)and finite(target.z)and finite(own.heading)and finite(range)and range>0)then return nil end
 local dx,dz=target.x-p.x,target.z-p.z
 local c,s=math.cos(own.heading),math.sin(own.heading)
 local forward,right=dx*c+dz*s,-dx*s+dz*c
 local x,y=right/range*M.extent,forward/range*M.extent
 local factor=math.max(1,math.sqrt(x*x+y*y)/M.extent)
 return x/factor,y/factor,factor>1
end
-- Fit the selected marker and both annotations as one stack. This preserves
-- above/below relationships at the circular aperture instead of moving text inside the box.
M.frame_half=.136
M.label_offset=.24
M.label_half_width=.48
M.label_half_height=.08
function M.selected_anchor(x,y)
 local w,h=M.label_half_width,M.label_offset+M.label_half_height
 local a=x*x+y*y
 if a<1e-12 then return x,y end
 local b=2*(math.abs(x)*w+math.abs(y)*h)
 local c=w*w+h*h-.98^2
 local k=math.min(1,(-b+math.sqrt(b*b-4*a*c))/(2*a))
 return x*k,y*k
end
function M.label(x,y,side)return x,y+(side or 1)*M.label_offset end
return M
