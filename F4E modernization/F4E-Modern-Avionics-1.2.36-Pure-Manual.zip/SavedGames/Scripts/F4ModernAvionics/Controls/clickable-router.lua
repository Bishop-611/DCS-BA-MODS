return function(elements)
    local map=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/Controls/input-map.lua]]))
    local rwrKnobs=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/RWR/knob-commands.lua]]))
    -- A mouse rotation belongs to the current displayed value. Keyboard and
    -- physical axes retain their native absolute/step mappings.
    local radarSteps={[3029]=3052,[3025]=3048,[3028]=3051,[3023]=3046,
        [3030]=3070,[3032]=3045,[3024]=3047,[3026]=3049}
    local rwrSteps={[3001]=3023,[3002]=3024,[3025]=3028,[3026]=3027,[3049]=3050,[3051]=3052}
    for _,element in pairs(elements) do
        local original=element.device
        local steps=original==67 and rwrSteps or original==52 and radarSteps
        if steps and element.relative and element.arg_lim then
            for i,cmd in ipairs(element.action or {})do
                if steps[cmd] then
                    element.relative[i]=true
                    element.arg_lim[i]={-1,1}
                    element.action[i]=steps[cmd]
                end
            end
        end
        local rwrKnob=false
        if original==67 then for _,command in ipairs(element.action or {})do if rwrKnobs[command]then rwrKnob=true end end end
        if rwrKnob then element.device=202
        elseif original==52 then
            local power=false
            for _,action in ipairs(element.action or {}) do if action==3004 then power=true end end
            element.device=power and 203 or 204
            if power then
                for _,field in ipairs({'action','stop_action'}) do
                    for i in ipairs(element[field] or {}) do element[field][i]=3009 end
                end
            end
        else
            for _,entry in ipairs(map) do
                if original==entry.device then
                    local matches=false
                    for _,action in ipairs(element.action or {}) do if action==entry.command then matches=true end end
                    if matches then
                        element.device=203
                        for _,field in ipairs({'action','stop_action'}) do
                            for i,action in ipairs(element[field] or {}) do
                                if action==entry.command then element[field][i]=entry.routed end
                            end
                        end
                        break
                    end
                end
            end
        end
    end
end
