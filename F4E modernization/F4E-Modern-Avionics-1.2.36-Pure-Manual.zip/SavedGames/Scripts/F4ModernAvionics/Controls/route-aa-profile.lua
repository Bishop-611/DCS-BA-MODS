return dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/Controls/profile-router.lua]]))(true)
