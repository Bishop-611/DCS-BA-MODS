local root=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/]])
local profile=dofile(root..'radar-profile.lua')
perfomance=profile.performance
dofile(root..'radar-contacts.lua')
local receive_init,receive_update=post_initialize,update
local force_interlock=dofile(root..'Controls/force-interlock.lua')
local dev=GetSelf()
local tick=0
dev:listen_command(509);dev:listen_command(510)
function SetCommand(command,value)end
local offErrorReported=false
local function original_off(reason)
    local ok,err=pcall(function()GetDevice(52):performClickableAction(3004,0,false)end)
    if not ok and not offErrorReported then
        offErrorReported=true
        if log and log.write then log.write('F4_RADAR',log.ERROR or 1,'Native radar OFF command failed: '..tostring(err)) end
    end
end
function post_initialize()
    get_param_handle('F4_SR_START_POWER_VALID'):set(0)
    local ok,v=pcall(get_cockpit_draw_argument_value,336)
    -- Zero before native initialization is ambiguous. Native OFF also changes
    -- this argument, so only preserve a populated startup position here.
    if ok and type(v)=='number'and v==v and v>0 then
        get_param_handle('F4_SR_START_POWER'):set(math.max(0,math.min(1,v)))
        get_param_handle('F4_SR_START_POWER_VALID'):set(1)
    end
    receive_init()
    original_off('STARTUP')
    force_interlock('STARTUP')
    for name,value in pairs({SCAN_ZONE_VOLUME_AZIMUTH=profile.performance.scan_volume_azimuth,
        SCAN_ZONE_VOLUME_ELEVATION=profile.performance.scan_volume_elevation,
        RADAR_PITCH_STABILIZATION=1,RADAR_ROLL_STABILIZATION=1}) do get_param_handle(name):set(value) end
    get_param_handle('IFF_INTERROGATOR_STATUS'):set(0)
end
function update()
    receive_update();tick=tick+1
    force_interlock('WATCHDOG')
    if tick%10==0 then
        -- Direct UI/input access to the original radar is blocked. Also resist initial AI power-on.
        original_off('WATCHDOG')
    end
end
