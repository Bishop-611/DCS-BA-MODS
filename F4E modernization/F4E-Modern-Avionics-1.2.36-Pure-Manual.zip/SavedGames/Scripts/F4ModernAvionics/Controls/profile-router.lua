-- Build the lookup once per input profile. Some profiles inherit already-routed bindings.
local runtime = (require('lfs').writedir()..[[Scripts/F4ModernAvionics/]])
local map = dofile(runtime .. 'Controls/input-map.lua')
local fields = {'down', 'up', 'pressed', 'action'}

local function earlier(a, b)
    if b and (not a or b.order < a.order) then return b end
    return a
end

return function(wso)
    local byDevice = {}
    for order, entry in ipairs(map) do
        if not wso or (entry.device == 27 and entry.kind:sub(1, 3) == 'aa_') then
            local commands = byDevice[entry.device] or {}
            byDevice[entry.device] = commands
            if not commands[entry.command] then
                entry.order = order
                commands[entry.command] = entry
            end
        end
    end
    local knobs
    if not wso then knobs = dofile(runtime .. 'RWR/knob-commands.lua') end

    local function route(bindings)
        for _, bind in ipairs(bindings or {}) do
            local device = bind.cockpit_device_id
            local commands = byDevice[device]
            if commands then
                -- Profiles may specify distinct down, pressed and axis commands.
                -- Match the first eligible entry in the original mapping order.
                local entry = earlier(earlier(commands[bind.down], commands[bind.action]), commands[bind.pressed])
                if entry then
                    local target = (bind.action and entry.axis_routed) or entry.routed
                    for _, field in ipairs(fields) do
                        if bind[field] == entry.command then bind[field] = target end
                    end
                    bind.cockpit_device_id = 203
                elseif device == 52 and not wso then
                    bind.cockpit_device_id = 204
                end
            elseif device == 67 and knobs then
                for _, field in ipairs(fields) do
                    if knobs[bind[field]] then
                        bind.cockpit_device_id = 202
                        break
                    end
                end
            end
        end
    end
    return function(profile)
        route(profile.keyCommands)
        route(profile.axisCommands)
        return profile
    end
end
