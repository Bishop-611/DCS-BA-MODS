-- Native receiver lifecycle. Acquisition/display read their own parameters;
-- release builds need no periodic slot dump or duplicate observation handles.
local dev=GetSelf()
make_default_activity(.1)
need_to_be_closed=false
function post_initialize()
 local ok,err=pcall(function()dev:set_power(true)end)
 if not ok and log and log.write then log.write('F4_SIMPLE_CONTACTS',log.ERROR or 1,'Initial radar power failed: '..tostring(err))end
end
function update()end