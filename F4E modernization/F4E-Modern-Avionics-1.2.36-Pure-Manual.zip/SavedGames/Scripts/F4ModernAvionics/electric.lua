local dev=GetSelf()
make_default_activity(.1)
need_to_be_closed=false
local function power(name)
    local ok,err=pcall(function()dev[name](dev,true)end)
    if not ok and log and log.write then log.write('F4_ELECTRIC',log.ERROR or 1,name..' failed: '..tostring(err))end
end
function post_initialize()
    power('AC_Generator_1_on');power('AC_Generator_2_on');power('DC_Battery_on')
end
function update()end
