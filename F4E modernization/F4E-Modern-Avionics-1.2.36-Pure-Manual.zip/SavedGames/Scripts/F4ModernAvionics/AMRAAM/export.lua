if F4AmraamExportLoaded then return end
F4AmraamExportLoaded=true
local root=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/]])
local native=dofile(root..'HARM/native.lua');if not native then return end
local wire=dofile(root..'HARM/wire.lua');local core=dofile(root..'AMRAAM/export-core.lua')
local nextTime,lastTime=-1,nil
local previousStart,previousStop,previousAfter=LuaExportStart,LuaExportStop,LuaExportAfterNextFrame
local function clear()
 -- Do not reset the shared DLL: HARM owns mailboxes 0/1 and its launch state.
 native.put(2,'');native.put(3,'');nextTime=-1;lastTime=nil
end
function LuaExportStart()
 if previousStart then previousStart()end
 clear()
end
function LuaExportStop()
 clear();if previousStop then previousStop()end
end
function LuaExportAfterNextFrame()
 if previousAfter then previousAfter()end
 if type(LoGetModelTime)~='function'then return end
 local ok,now=pcall(LoGetModelTime)
 if not ok or not wire.finite(now)then return end
 if lastTime and now<lastTime then clear()end;lastTime=now
 if now<nextTime then return end;nextTime=now+.1
 local captured,rows=pcall(function()return core.capture(_G,wire.unpack(native.get(2)),now)end)
 native.put(3,captured and wire.pack(rows)or '')
end