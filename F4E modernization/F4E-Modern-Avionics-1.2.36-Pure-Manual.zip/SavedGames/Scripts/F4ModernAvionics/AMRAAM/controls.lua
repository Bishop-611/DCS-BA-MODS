-- Existing F-4 controls: Gun/Heat/Radar = -1/0/+1; trigger = 0/.5/1.
-- The sequence-button options request a stage, not a next-position cycle.
-- Axis inputs use the existing DCS [-1,+1] range. No new binding is required.
local M={};M.__index=M
local function finite(v)return type(v)=='number'and v==v and math.abs(v)<math.huge end
local function clamp(v,lo,hi)return math.max(lo,math.min(hi,v))end
local function weapon_position(v)return v>=.5 and 1 or v<=-.5 and -1 or 0 end
local function trigger_position(v)return v>=.75 and 1 or v>=.25 and .5 or 0 end
function M.new(initial)
 local self=setmetatable({lo=-1,hi=1,stages={pilot=0,wso=0}},M)
 self:sync(initial);return self
end
-- A definite native readback may initialize an otherwise unknown selection.
-- Once an original switch command established it, stale lamps cannot override it.
function M:sync(value)
 if self.lo~=self.hi and (value==-1 or value==0 or value==1)then self.lo=value;self.hi=value end
 return self:mode()
end
function M:mode()if self.lo==self.hi then return self.lo end end
function M:radar_selected()return self:mode()==1 end
function M:weapon(kind,value,readback)
 self:sync(readback)
 if not finite(value)then return self:mode()end
 if kind=='aa_weapon'or kind=='aa_weapon_axis'then
  local position=weapon_position(clamp(value,-1,1));self.lo=position;self.hi=position
 elseif kind=='aa_weapon_step'and value~=0 then
  local step=value>0 and 1 or -1
  -- Unknown startup selection stays unknown until the commands reach a bound.
  -- Two increments always establish Radar; two decrements always establish Gun.
  self.lo=clamp(self.lo+step,-1,1);self.hi=clamp(self.hi+step,-1,1)
 end
 return self:mode()
end
function M:trigger(kind,value,seat)
 if not finite(value)then return nil end
 if kind~='aa_trigger'and kind~='aa_trigger_axis'and kind~='aa_trigger_sequence'then return nil end
 seat=seat=='wso'and'wso'or'pilot'
 if kind=='aa_trigger_axis'then value=(clamp(value,-1,1)+1)*.5 end
 local stage=trigger_position(clamp(value,0,1));local previous=self.stages[seat]
 self.stages[seat]=stage
 return {stage=stage,full=stage==1,rising=stage==1 and previous<1,
  falling=stage<1 and previous==1,released=stage==0,seat=seat}
end
return M
