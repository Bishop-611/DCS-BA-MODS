-- Stock AIM-120B on the four F-4 Sparrow stations. No new weapon declaration.
-- Preserve unrelated stores and restrictions; prohibit mixed Sparrow/AMRAAM loads.
local amraam='{C8E06185-7CD6-4C90-959F-044679E90751}'
local sparrows={'{HB_F4E_AIM-7F}','{HB_F4E_AIM-7E}','{HB_F4E_AIM-7E-2}','{HB_F4E_AIM-7M}'}
local isSparrow={};for _,id in ipairs(sparrows)do isSparrow[id]=true end
local stationOrder={5,6,8,9};local allowed={[5]=true,[6]=true,[8]=true,[9]=true}
local function copy(v)
 if type(v)~='table'then return v end
 local result={};for k,x in pairs(v)do result[k]=copy(x)end;return result
end
local function forbid(launcher,station,clsid)
 launcher.forbidden=launcher.forbidden or {}
 for _,rule in ipairs(launcher.forbidden)do
  if rule.station==station then
   if rule.loadout==nil then return end -- Existing whole-station prohibition is stronger.
   for _,id in ipairs(rule.loadout)do if id==clsid then return end end
  end
 end
 launcher.forbidden[#launcher.forbidden+1]={station=station,loadout={clsid}}
end
return function(aircraft)
 assert(type(aircraft)=='table'and type(aircraft.Pylons)=='table','F-4 AIM-120B: aircraft pylons unavailable')
 local prepared={};local changes=0
 -- Prepare every station before mutation. The native 5/8/9 launcher lists alias.
 for index,pylon in pairs(aircraft.Pylons)do
  local number=pylon.Number or pylon.number or index
  local seed,count,hasSparrow=nil,0,false
  for _,launcher in ipairs(pylon.Launchers or {})do
   if isSparrow[launcher.CLSID]then hasSparrow=true end
   if launcher.CLSID==sparrows[1]or launcher.CLSID==sparrows[4]then seed=launcher end
   if launcher.CLSID==amraam then count=count+1 end
  end
  if hasSparrow then
   assert(allowed[number]and not prepared[number],'F-4 AIM-120B: unexpected Sparrow station')
   assert(seed and count<=1,'F-4 AIM-120B: missing F/M seed or duplicate AMRAAM')
   local launchers=copy(pylon.Launchers)
   if count==0 then
    local item=copy(seed);item.CLSID=amraam
    -- Sparrow .47 is its semi-recessed drag correction, not an AMRAAM factor.
    -- Keep stock AMRAAM drag rather than inventing a new aircraft-specific factor.
    item.Cx_gain=nil;item.Cx_gain_empty=nil;item.Cx_gain_item=nil
    launchers[#launchers+1]=item;changes=changes+1
   end
   -- Each frame is translated 15 cm aft in its original 1.2.15 bay coordinate system.
   for _,launcher in ipairs(launchers) do
    if launcher.CLSID == amraam then
     launcher.connector = "F4MA_120B_AFT15_" .. number
    end
   end
   prepared[number]={pylon=pylon,launchers=launchers}
  end
 end
 for _,number in ipairs(stationOrder)do
  assert(prepared[number],'F-4 AIM-120B: expected Sparrow stations 5, 6, 8, 9')
 end
 for _,number in ipairs(stationOrder)do
  for _,launcher in ipairs(prepared[number].launchers)do
   for _,other in ipairs(stationOrder)do if other~=number then
    if launcher.CLSID==amraam then
     for _,id in ipairs(sparrows)do forbid(launcher,other,id)end
    elseif isSparrow[launcher.CLSID]then forbid(launcher,other,amraam)end
   end end
  end
 end
 for _,number in ipairs(stationOrder)do local item=prepared[number];item.pylon.Launchers=item.launchers end
 return changes
end
