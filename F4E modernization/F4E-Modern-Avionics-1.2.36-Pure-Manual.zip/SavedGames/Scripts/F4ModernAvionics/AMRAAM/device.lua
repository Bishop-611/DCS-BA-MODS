-- Hosted by the existing input device. No new native cockpit device.
local root=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/]])
local Controls=dofile(root..'AMRAAM/controls.lua')
local Release=dofile(root..'AMRAAM/release.lua')
local core=dofile(root..'AMRAAM/export-core.lua')
local wire=dofile(root..'HARM/wire.lua')
local M={};M.__index=M
local direct={pilot=3001,wso=3133}
function M.new(native,io)
 return setmetatable({native=native,io=io,controls=Controls.new(),release=Release.new(native),nextTime=-1,
  frame=nil,carried=false,owns={},nativeStage={},lastTime=nil,diagnostics=0,lastStatus=nil,
  track=nil,trackStatus='NOT_REQUIRED',trackLogs=0,lastTrackStatus=nil},M)
end
function M:seed()
 local mode,count=nil,0
 for _,item in ipairs({{274,-1},{279,1},{280,0}})do
  local v=self.io.draw(item[1]);if type(v)=='number'and v>.05 then mode=item[2];count=count+1 end
 end
 if count==1 then self.controls:sync(mode)end
end
function M:context(aa)
 local io=self.io
 return {aa=aa,radar=self.controls:radar_selected(),masterArm=(io.draw(247)or 0)>.5,
  mode=io.get('RADAR_MODE'),range=io.get('RADAR_STT_RANGE'),az=io.get('RADAR_STT_AZIMUTH'),el=io.get('RADAR_STT_ELEVATION'),
  native_id=self.track and self.track.id,native_time=self.track and self.track.time}
end
function M:owned(aa)return aa and self.controls:radar_selected()and self.carried end
function M:sample_track(aa,now)
 self.track=nil;self.trackStatus='NOT_REQUIRED'
 if not(self:owned(aa)and self.io.get('RADAR_MODE')==3)then return end
 self.trackStatus='NATIVE_RADAR_API_UNAVAILABLE'
 if not(self.native and type(self.native.radar_track)=='function'and type(self.io.radarLink)=='function')then return end
 local ok,link=pcall(self.io.radarLink)
 self.trackStatus='NATIVE_RADAR_LINK_UNAVAILABLE'
 if not ok or link==nil then return end
 local good,s=pcall(self.native.radar_track,link)
 self.trackStatus='NATIVE_RADAR_READ_FAILED'
 if not good or type(s)~='table'then return end
 if type(s.status)=='string'and s.status:match('^[%w_]+$')then self.trackStatus=s.status:sub(1,96)end
 if s.status~='f4_aa_radar_track'then return end
 if s.tracking~=1 then self.trackStatus='NATIVE_NOT_TRACKING';return end
 if not wire.finite(s.id)or s.id<=0 or s.id>4294967295 or s.id%1~=0 then self.trackStatus='NATIVE_ID_INVALID';return end
 if not wire.finite(s.range)or s.range<=0 then self.trackStatus='NATIVE_RANGE_INVALID';return end
 local range=self.io.get('RADAR_STT_RANGE')
 if not wire.finite(range)or range<=0 or math.abs(s.range-range)>math.max(100,range*.02)then self.trackStatus='NATIVE_RANGE_MISMATCH';return end
 self.track={id=s.id,range=s.range,time=now,provider=s.provider==1,provider120=s.provider120==1}
end
function M:reconcile(aa)
 for seat,stage in pairs(self.nativeStage)do
  if self:owned(aa)and stage>0 and not self.owns[seat]then
   self.io.forward(27,direct[seat],0);self.nativeStage[seat]=0
   self.owns[seat]=true;self.release.held[seat]=true
  elseif self.owns[seat]and not self:owned(aa)and stage>0 then
   self.io.forward(27,direct[seat],0);self.nativeStage[seat]=0
  end
 end
end
function M:command(entry,value,now,aa)
 if entry.kind:sub(1,9)=='aa_weapon' then
  self:seed();self.controls:weapon(entry.kind,value)
  self.io.forward(entry.device,entry.command,value)
  self:reconcile(aa)
  self:publish(aa,now);return true
 end
 if entry.kind:sub(1,10)~='aa_trigger'then return false end
 self:seed()
 self:reconcile(aa)
 local t=self.controls:trigger(entry.kind,value,entry.seat)
 if not t then return true end
 local seat=t.seat or entry.seat or 'pilot'
 local own=self:owned(aa)
 if own then self.owns[seat]=true end
 if self.owns[seat]then
  if t.full and not self.release.held[seat]and not self.release.pending and not self.release.fault then
   self:sample_track(aa,now) -- Recheck identity once, in the same callback as launch.
  end
  self.release:command(t.stage,self:context(aa),self.frame,now,seat)
  -- Preserve first-stage preparation, but suppress native full-stage release
  -- while the stock AMRAAM is released through the strictly typed adapter.
  local stage=own and math.min(.5,t.stage)or 0
  if self.nativeStage[seat]~=stage then self.io.forward(27,direct[seat],stage);self.nativeStage[seat]=stage end
  if t.released then self.owns[seat]=nil end
  self:publish(aa,now);return true
 end
 self.release:command(0,nil,nil,now,seat)
 self.nativeStage[seat]=t.stage
 self.io.forward(entry.device,entry.command,value);return true
end
function M:publish(aa,now)
 local active=self:owned(aa)
 self.io.publish('F4_AIM120_SELECTED',active and 1 or 0)
 local ready,mode=self.release:ready(self:context(aa),self.frame,now)
 self.io.publish('F4_AIM120_HANDOFF',ready and mode=='READY' and 1 or 0)
 local status=self.release.status
 if self.lastStatus~=status then
  self.lastStatus=status
  if status~='IDLE'and self.diagnostics<6 and self.io.report then
   self.diagnostics=self.diagnostics+1
   local detail=self.release.nativeStatus
   local suffix=type(detail)=='string'and detail:match('^[%w_]+$')and(' native='..detail:sub(1,96))or ''
   self.io.report(status..suffix)
  end
 end
 local state=self.trackStatus
 if self.lastTrackStatus~=state then
  self.lastTrackStatus=state
  if state~='NOT_REQUIRED'and self.trackLogs<6 and self.io.report then
   self.trackLogs=self.trackLogs+1
   local t=self.track
   self.io.report('TRACK '..state..(t and(' provider='..(t.provider and '1'or '0')..' responder120='..(t.provider120 and '1'or '0'))or ''))
  end
 end
end
function M:tick(now,aa)
 if now<self.nextTime and not(self.lastTime and now<self.lastTime)then return end
 if self.lastTime and now<self.lastTime then
  self.frame=nil;self.carried=false;self.track=nil;self.release=Release.new(self.native);self.owns={}
 end
 self.lastTime=now;self.nextTime=now+.1
 self:seed()
 local native=self.native
 if native and type(native.get)=='function'and type(native.put)=='function'then
  local ok,raw=pcall(native.get,3)
  local frame=ok and core.decode(wire.unpack(raw))or nil
  if frame and frame.time<=now and now-frame.time<=.25 then
   self.frame=frame
   if frame.payloadValid then self.carried=frame.carried end
  end
  self:sample_track(aa,now)
  local c=self:context(aa)
  local t=self.track
  pcall(native.put,2,wire.pack({{'Q',now,aa and 1 or 0,c.radar and 1 or 0,c.mode,c.range,c.az,c.el,
   t and t.id or 0,t and t.range or 0,t and 1 or 0}}))
 end
 self.release:update(self.frame,now)
 -- Changing weapon modes with a held trigger never causes an automatic AMRAAM
 -- launch or leaves the original weapon trigger held in the background.
 self:reconcile(aa)
 self:publish(aa,now)
end
return M
