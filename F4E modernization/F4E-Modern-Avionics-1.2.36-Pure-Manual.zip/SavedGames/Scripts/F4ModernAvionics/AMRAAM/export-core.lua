-- Resolve only the world ID supplied by the actual avSimpleRadar STT provider.
-- DCS Scripts/Export.lua defines LoGetObjectById: Position / Type (capitalized).
-- No generic lock-list dependency, world enumeration or nearest-target inference.
local mathlib=dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/HUD/flight_math.lua]]))
local M={}
local reasons={}
for _,name in ipairs({'READY','NATIVE_TRACK_UNAVAILABLE','NO_QUERY','OBJECT_EXPORT_BLOCKED',
 'OBJECT_UNAVAILABLE','TARGET_GEOMETRY_MISMATCH','NO_AMRAAM','MIXED_LOAD','PAYLOAD_UNAVAILABLE','OWN_POSE_UNAVAILABLE'})do reasons[name]=true end
local bays={5,6,8,9};local allowed={[5]=true,[6]=true,[8]=true,[9]=true}
local function finite(x)return type(x)=='number'and x==x and math.abs(x)<1e10 end
local function integer(x,lo,hi)return finite(x)and x%1==0 and x>=lo and x<=hi end
local function vector(p)return type(p)=='table'and finite(p.x)and finite(p.y)and finite(p.z)end
local function level(w,n)return w['level'..n]or w[n]end
local function classified(w)
 if type(w)~='table'then return false end
 for n=1,4 do if not integer(level(w,n),0,4294967295)then return false end end
 return true
end
local function weapon(st)
 if type(st)~='table'or type(st.weapon)~='table'then return false,false end
 local w=st.weapon;local aa=level(w,1)==4 and level(w,2)==4 and level(w,3)==7
 return aa and level(w,4)==24,aa
end
-- Query row: Q,time,aa,radar_selected,mode,range,az,el,nativeID,nativeRange,tracking.
-- Base/query errors remain distinct from missing native tracking evidence.
local function query(raw,now)
 local q=type(raw)=='table'and raw[1]
 if type(q)~='table'or (#q~=8 and #q~=11)or q[1]~='Q'then return nil end
 for i=2,8 do if not finite(q[i])then return nil end end
 if now<q[2]or now-q[2]>.25 or q[3]~=1 or q[4]~=1 or q[5]~=3 or q[6]<=0
  or math.abs(q[7])>=math.pi/2 or math.abs(q[8])>=math.pi/2 then return nil end
 return q
end
local function nativeTrack(q)
 return #q==11 and integer(q[9],1,4294967295)and finite(q[10])and q[10]>0 and q[11]==1
  and math.abs(q[10]-q[6])<=math.max(100,q[6]*.02)
end
local function match(own,q,p)
 local dx,dy,dz=p.x-own.Position.x,p.y-own.Position.y,p.z-own.Position.z
 local distance=math.sqrt(dx*dx+dy*dy+dz*dz)
 if distance<=0 or math.abs(distance-q[6])>math.max(100,q[6]*.02)then return nil end
 local f,u,r=mathlib.body(dx,dy,dz,own.Pitch,own.Bank,own.Heading)
 if f<=0 then return nil end
 local er,eu=math.tan(q[7]),math.tan(q[8]);local norm=math.sqrt(1+er*er+eu*eu)
 local dot=(f+u*eu+r*er)/(distance*norm)
 if dot<math.cos(math.rad(2))then return nil end
 return {'T',q[9],p.x,p.y,p.z,distance,math.atan2(r,f),math.atan2(u,f)}
end
function M.capture(api,raw,now)
 if not finite(now)then return {}end
 local function call(name,...)
  if type(api[name])~='function'then return nil end
  local ok,value=pcall(api[name],...);if ok then return value end
 end
 local own=call('LoGetSelfData')
 if type(own)=='table'and own.Name~='F-4E-45MC'then return {{'OFF',now}}end
 local payload=call('LoGetPayloadInfo')
 local valid=type(payload)=='table'and type(payload.Stations)=='table'
 local stations=valid and payload.Stations or {}
 local has120,hasOther=false,false;local counts={'C'};local choices={};local first
 for _,bay in ipairs(bays)do
  local s=stations[bay];local count=0
  if s~=nil then
   if type(s)~='table'or not integer(s.count,0,64)then valid=false
   elseif s.count>0 then
    if not classified(s.weapon)then valid=false
    else
     local is120,isAA=weapon(s)
     if is120 then has120=true;count=s.count;choices[bay]=count;first=first or bay
     elseif isAA then hasOther=true end
    end
   end
  end
  counts[#counts+1]=count
 end
 local current=type(payload)=='table'and payload.CurrentStation
 local station=(integer(current,1,14)and allowed[current]and choices[current]and current)or first or 0
 local panel=call('GetDevice',0);local master=false
 if panel~=nil then local ok,v=pcall(function()return panel:get_argument_value(247)end);master=ok and finite(v)and v>.5 end
 local mixed=has120 and hasOther
 local rows={{'A',now,station,choices[station]or 0,has120 and 1 or 0,mixed and 1 or 0,master and 1 or 0,valid and 1 or 0},counts}
 local function result(reason,target)
  rows[3]={'D',reason};if target then rows[4]=target end;return rows
 end
 -- Keep carriage metadata even when targeting is unavailable, so the cockpit
 -- never interprets missing ID/permission/pose as an empty missile loadout.
 if not valid then return result('PAYLOAD_UNAVAILABLE')end
 if not has120 then return result('NO_AMRAAM')end
 if mixed then return result('MIXED_LOAD')end
 local q=query(raw,now)
 if not q then return result('NO_QUERY')end
 if not nativeTrack(q)then return result('NATIVE_TRACK_UNAVAILABLE')end
 if not(type(own)=='table'and vector(own.Position)and finite(own.Pitch)
  and finite(own.Bank)and finite(own.Heading))then return result('OWN_POSE_UNAVAILABLE')end
 if call('LoIsObjectExportAllowed')~=true then return result('OBJECT_EXPORT_BLOCKED')end
 -- Exactly one lookup of the measured native ID; no fallback to another ID.
 local object=call('LoGetObjectById',q[9])
 if type(object)~='table'or not vector(object.Position)then return result('OBJECT_UNAVAILABLE')end
 if object.Type~=nil then
  if type(object.Type)~='table'then return result('OBJECT_UNAVAILABLE')end
  local first=level(object.Type,1)
  if first~=nil and first~=1 then return result('OBJECT_UNAVAILABLE')end
 end
 local target=match(own,q,object.Position)
 if not target then return result('TARGET_GEOMETRY_MISMATCH')end
 return result('READY',target)
end
function M.decode(rows)
 if type(rows)~='table'or(#rows~=3 and #rows~=4)then return nil end
 local a,c,d=rows[1],rows[2],rows[3]
 if type(d)~='table'or #d~=2 or d[1]~='D'or not reasons[d[2]]then return nil end
 if (d[2]=='READY')~=(rows[4]~=nil)then return nil end
 if type(a)~='table'or #a~=8 or a[1]~='A'or type(c)~='table'or #c~=5 or c[1]~='C'then return nil end
 if not finite(a[2])or not integer(a[3],0,14)or(a[3]~=0 and not allowed[a[3]])or not integer(a[4],0,64)then return nil end
 for i=5,8 do if a[i]~=0 and a[i]~=1 then return nil end end
 local frame={time=a[2],station=a[3],count=a[4],carried=a[5]==1,mixed=a[6]==1,masterArm=a[7]==1,payloadValid=a[8]==1,reason=d[2],counts={}}
 local total=0
 for i,bay in ipairs(bays)do if not integer(c[i+1],0,64)then return nil end;frame.counts[bay]=c[i+1];total=total+c[i+1]end
 if frame.carried~=(total>0)or(frame.mixed and not frame.carried)or(frame.station==0 and(frame.count~=0 or total>0))
  or(frame.station~=0 and(frame.count==0 or frame.counts[frame.station]~=frame.count))then return nil end
 if rows[4]then
  local t=rows[4];if type(t)~='table'or #t~=8 or t[1]~='T'or not integer(t[2],1,4294967295)
   or not finite(t[3])or not finite(t[4])or not finite(t[5])or not finite(t[6])or t[6]<=0
   or not finite(t[7])or not finite(t[8])or math.abs(t[7])>=math.pi/2 or math.abs(t[8])>=math.pi/2 or not frame.carried or frame.mixed or not frame.payloadValid then return nil end
  frame.target={id=t[2],position={x=t[3],y=t[4],z=t[5]},range=t[6],az=t[7],el=t[8],stamp=frame.time}
 end
 return frame
end
return M