-- Native stock missile release. An existing STT requires its real exported target ID.
-- One attempt per complete trigger press; never synthesize a target or retry
-- a native call whose result/count change cannot be confirmed.
local M={};M.__index=M
local bays={[5]=true,[6]=true,[8]=true,[9]=true}
local function finite(v)return type(v)=='number'and v==v and math.abs(v)<1e10 end
local function fresh(t,now)return finite(t)and now>=t and now-t<=.25 end
function M.new(native)return setmetatable({native=native,held={},pending=nil,fault=false,status='IDLE'},M)end
function M:update(frame,now)
 local p=self.pending;if not p then return end
 if frame and frame.payloadValid and frame.time>=p.time and fresh(frame.time,now)then
  local count=frame.counts[p.station]
  if count==p.count-1 then self.pending=nil;self.status='RELEASE_CONFIRMED';return end
  if count~=p.count then self.pending=nil;self.fault=true;self.status='UNEXPECTED_PAYLOAD_CHANGE';return end
 end
 if now-p.time>5 then self.pending=nil;self.fault=true;self.status='RELEASE_UNCONFIRMED'end
end
function M:ready(c,f,now)
 if self.fault then return false,'RELEASE_FAULT'end
 if self.pending then return false,'RELEASE_PENDING'end
 if not(c and c.aa and c.radar)then return false,'MODE'end
 if not c.masterArm then return false,'MASTER_SAFE'end
 if not f or not f.payloadValid or not fresh(f.time,now)then return false,'PAYLOAD_STALE'end
 if f.mixed then return false,'MIXED_LOAD'end
 if not(f.carried and f.masterArm and bays[f.station]and finite(f.count)and f.count>=1 and f.counts[f.station]==f.count)then return false,'NO_STOCK_AIM120'end
 if c.mode==0 or c.mode==1 or c.mode==2 then
  if not self.native or type(self.native.run_aa_unassigned)~='function'then return false,'NATIVE_UNAVAILABLE'end
  return true,'MADDOG'
 end
 if c.mode~=3 then return false,'NO_STT'end
 if not self.native or type(self.native.run_aa)~='function'then return false,'NATIVE_UNAVAILABLE'end
 if not(finite(c.native_id)and c.native_id>0 and c.native_id<=4294967295 and c.native_id%1==0)then return false,'NATIVE_TRACK_UNAVAILABLE'end
 if not fresh(c.native_time,now)then return false,'NATIVE_TRACK_STALE'end
 local t=f.target
 if not(t and finite(t.id)and t.id>0 and t.id<=4294967295 and t.id%1==0 and fresh(t.stamp,now))then return false,f.reason or 'NO_TARGET_ID'end
 if t.id~=c.native_id then return false,'TARGET_CHANGED'end
 local p=t.position
 if not(p and finite(p.x)and finite(p.y)and finite(p.z))then return false,'NO_TARGET_POSITION'end
 if not(finite(c.range)and c.range>0 and finite(c.az)and finite(c.el)and finite(t.range)and finite(t.az)and finite(t.el))then return false,'NO_STT'end
 if math.abs(c.az)>=math.pi/2 or math.abs(c.el)>=math.pi/2 or math.abs(t.az)>=math.pi/2 or math.abs(t.el)>=math.pi/2 then return false,'NO_STT'end
 local cr,cu,tr,tu=math.tan(c.az),math.tan(c.el),math.tan(t.az),math.tan(t.el)
 local dot=(1+cr*tr+cu*tu)/math.sqrt((1+cr*cr+cu*cu)*(1+tr*tr+tu*tu))
 if math.abs(c.range-t.range)>math.max(100,c.range*.02)or dot<math.cos(math.rad(2))then return false,'TARGET_CHANGED'end
 return true,'READY'
end
function M:command(stage,c,f,now,seat)
 seat=seat or 'pilot'
 if stage<=.05 then self.held[seat]=false;return end
 if stage<.95 or self.held[seat]then return end
 self.held[seat]=true
 local ready,reason=self:ready(c,f,now)
 if not ready then self.status=reason;return end
 self.pending={station=f.station,count=f.count,time=now}
 local ok,status,raw,accepted
 if reason=='MADDOG' then
  ok,status,raw,accepted=pcall(self.native.run_aa_unassigned,f.station-1)
 else
  local t=f.target;local p=t.position
  ok,status,raw,accepted=pcall(self.native.run_aa,f.station-1,t.id,p.x,p.y,p.z)
 end
 self.nativeStatus=ok and status or 'NATIVE_EXCEPTION'
 if not ok or not accepted or not finite(raw)or raw<=0 then
  self.pending=nil;self.fault=true;self.status='RELEASE_UNCONFIRMED';return
 end
 self.status='RELEASE_PENDING'
end
return M
