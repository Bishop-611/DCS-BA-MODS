-- Native panel adapter, with direct DIM/AUDIO command handling.
local M={}
local buttons={[390]='power',[2833]='power',[381]='priority',[2824]='priority',
 [382]='search',[2825]='search',[383]='handoff',[2826]='handoff',
 [386]='separate',[2829]='separate',[387]='test',[2830]='test',
 [388]='unknown',[2831]='unknown'}
local modes={'priority','search','unknown','separate'}
local publishedModes={'priority','search','unknown','separate','test'}
local brightnessArgs={976,975,2625,2809}
local volumeArgs={977,2624}
function M.new(read, publish, report, birth)
 local state={on=birth=='AIR_HOT' or birth=='GROUND_HOT', brightness=1, volume=.5,
  priority=false,search=true,unknown=true,separate=false,handoff=0,test=false}
 local previous={}
 local commanded={}
 local first=true
 local bootTicks=0
 local panelSeen=false
 local function arg(id)
  local ok,v=pcall(read,id)
  if ok and type(v)=='number' and v==v and v>=0 and v<=1 then return v end
 end
 local function readKnob(ids)
  local firstValue,populated
  for _,id in ipairs(ids)do
   local value=arg(id)
   if firstValue==nil then firstValue=value end
   if value and value>0 then populated=true end
  end
  return firstValue,populated
 end
 local function observeKnobs()
  if bootTicks>=20 then return end
  local b,bValid=readKnob(brightnessArgs)
  local v,vValid=readKnob(volumeArgs)
  panelSeen=panelSeen or (bValid and not commanded.brightness) or (vValid and not commanded.volume)
  if panelSeen or birth=='GROUND_COLD' then
   if not commanded.brightness and b~=nil then state.brightness=b end
   if not commanded.volume and v~=nil then state.volume=v end
  end
  bootTicks=bootTicks+1
  publish('ALR56_KNOBS_SAMPLING',bootTicks<20 and 1 or 0)
  publish('ALR56_AUDIO_GAIN_READY',(bootTicks>=20 or commanded.volume) and 1 or 0)
 end
 function state:update()
  local edges={}
  -- Momentary buttons; held buttons and releases never cause repeated toggles.
  for id,action in pairs(buttons) do
   local value=arg(id)
   local v=value and value>.5 or false
   if not first and v and not previous[id] then
    edges[action]=true
   end
   previous[id]=v
  end
  if edges.power then self.on=not self.on;end
  for _,action in ipairs(modes)do
   if edges[action] and self.on then self[action]=not self[action];end
  end
  if edges.handoff and self.on then self.handoff=self.handoff+1;end
  self.test=self.on and (previous[387]or previous[2830])or false
  observeKnobs()
  publish('EFM_SYSTEMS',1)
  publish('EFM_ELEC_ESS',self.on and 1 or 0)
  publish('ALR56_BRIGHTNESS',self.brightness)
  publish('ALR56_BRIGHTNESS_LEVEL',math.floor(self.brightness*32+.5))
  publish('ALR56_VOLUME',self.volume)
  publish('ALR56_PANEL_READY',1)
  for _,action in ipairs(publishedModes)do
   publish('ALR56_'..action:upper(),self[action]and 1 or 0)
  end
  publish('ALR56_HANDOFF_SEQ',self.handoff)
  first=false
 end
 function state:knob(spec,value,draw)
  if type(value)~='number'or value~=value then return end
  local v=spec.kind=='step'and(self[spec.field]+value)or(spec.kind=='axis'and(value+1)*.5 or value)
  v=math.max(0,math.min(1,v));self[spec.field]=v;commanded[spec.field]=true
  previous[spec.arg]=v
  if draw then draw(spec.arg,v)end
  publish('ALR56_BRIGHTNESS',self.brightness)
  publish('ALR56_BRIGHTNESS_LEVEL',math.floor(self.brightness*32+.5))
  publish('ALR56_VOLUME',self.volume)
  publish('ALR56_KNOBS_SAMPLING',bootTicks<20 and 1 or 0)
  publish('ALR56_AUDIO_GAIN_READY',(bootTicks>=20 or commanded.volume) and 1 or 0)
  publish('ALR56_PANEL_READY',1)
 end
 return state
end
return M
