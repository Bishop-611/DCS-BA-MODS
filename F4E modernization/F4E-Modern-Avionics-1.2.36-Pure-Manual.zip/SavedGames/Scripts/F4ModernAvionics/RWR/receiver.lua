dofile((require('lfs').writedir()..[[Scripts/F4ModernAvionics/RWR/common.lua]]))
dofile(LockOn_Options.script_path..'Systems/RWR.lua')
local basePost,baseUpdate=post_initialize,update
local knobs=dofile(EXFULL_ROOT..'knob-commands.lua')
for command in pairs(knobs)do GetSelf():listen_command(command)end
local panel=dofile(EXFULL_ROOT..'controls.lua').new(get_cockpit_draw_argument_value,
 function(n,v)get_param_handle(n):set(v)end,nil,
 LockOn_Options.init_conditions and LockOn_Options.init_conditions.birth_place)
local nativeCommand=SetCommand
function SetCommand(command,value)
 if knobs[command]then
  -- avSimpleRWR does not expose the Lua-device draw-argument setter. Command
  -- publication must succeed independently of optional animation support.
  local draw
  if type(set_cockpit_draw_argument_value)=='function'then
   draw=function(id,v)pcall(set_cockpit_draw_argument_value,id,v)end
  end
  panel:knob(knobs[command],value,draw)
  EXFULL_flush()
 elseif nativeCommand then nativeCommand(command,value)end
end
local audioPowerReady=get_param_handle('ALR56_AUDIO_POWER_READY')
local firstPowerUpdate=true
function post_initialize()
 firstPowerUpdate=true
 audioPowerReady:set(0)
 panel:update();basePost();EXFULL_flush()
 make_default_activity(.05)

end
function update()
 panel:update()
 baseUpdate()
 if firstPowerUpdate then
  audioPowerReady:set(1)
  firstPowerUpdate=false
 end
 EXFULL_flush()
end
