EXFULL_ROOT=(require('lfs').writedir()..[[Scripts/F4ModernAvionics/RWR/]])
local options={};for k,v in pairs(LockOn_Options)do options[k]=v end
options.script_path=EXFULL_ROOT..'upstream/'
LockOn_Options=options
local nativeParam=get_param_handle
local handles,dirty={},{}
function get_param_handle(name)
 if name:match('^RWR_CONTACT_%d+_')then return nativeParam(name)end
 if handles[name]then return handles[name]end
 local h=nativeParam('EXFULL_'..name)
 local p={native=h}
 function p:get()if self.pending then return self.value end;return h:get()end
 function p:set(v)
  if not self.pending and self.sent==v then return end
  self.value=v;if not self.pending then self.pending=true;dirty[#dirty+1]=self end
 end
 handles[name]=p;return p
end
function EXFULL_flush()
 for i=1,#dirty do local p=dirty[i]
  if p.sent~=p.value then p.native:set(p.value);p.sent=p.value end
  p.pending=false;dirty[i]=nil
 end
end
local nativeDofile=dofile
function dofile(path)
 if path==options.script_path..'devices.lua' then devices={RWR=202,TEWS=206,ELECTRIC_SYSTEM=200};return end
 return nativeDofile(path)
end
