declare_plugin('F4ModernAvionicsRwrResources',{
 installed=true,dirName=current_mod_path,displayName='F-4 Modern Avionics RWR Resources',
 version='1.2.35',state='installed',info='F-4 Modern Avionics cockpit audio.'
})
plugin_done()
