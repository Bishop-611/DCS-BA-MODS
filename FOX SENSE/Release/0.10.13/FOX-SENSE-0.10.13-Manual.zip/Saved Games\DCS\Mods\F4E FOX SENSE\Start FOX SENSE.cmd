@echo off
setlocal
for %%I in ("%~dp0..\..") do set "FOX_PROFILE=%%~fI"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -ExecutionPolicy RemoteSigned -File "%~dp0Runtime\Overlay\Overlay.ps1" -ProfileRoot "%FOX_PROFILE%"
if errorlevel 1 pause
endlocal