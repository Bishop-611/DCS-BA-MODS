param([switch]$Demo,[string]$RenderPreview,[switch]$SelfTest,[string]$ProfileRoot,[switch]$ModernPreview,[switch]$RuntimeControlsTest)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase
Add-Type -Path (Join-Path $PSScriptRoot 'Fox.Runtime.dll')
. (Join-Path $PSScriptRoot 'InstrumentFont.ps1')
. (Join-Path $PSScriptRoot 'Protocol.ps1')
. (Join-Path $PSScriptRoot 'AspectLayout.ps1')
. (Join-Path $PSScriptRoot 'ViewProjection.ps1')
. (Join-Path $PSScriptRoot 'Datalink.ps1')
. (Join-Path $PSScriptRoot 'RangeHighlights.ps1')
. (Join-Path $PSScriptRoot 'JesterMissiles.ps1')
. (Join-Path $PSScriptRoot 'RangeAndView.ps1')
. (Join-Path $PSScriptRoot 'MissileSources.ps1')
. (Join-Path $PSScriptRoot 'MissileAudio.ps1')
. (Join-Path $PSScriptRoot 'RadarLockAudio.ps1')
. (Join-Path $PSScriptRoot 'WarningLoops.ps1')
. (Join-Path $PSScriptRoot 'IncomingMissiles.ps1')
. (Join-Path $PSScriptRoot 'HornetStyle.ps1')
. (Join-Path $PSScriptRoot 'HornetRwr.ps1')
. (Join-Path $PSScriptRoot 'ModernRwr.ps1')
. (Join-Path $PSScriptRoot 'SaRwr.ps1')
. (Join-Path $PSScriptRoot 'SaMissiles.ps1')
. (Join-Path $PSScriptRoot 'DatalinkOverlay.ps1')
. (Join-Path $PSScriptRoot 'Settings.ps1')
. (Join-Path $PSScriptRoot 'MenuAudio.ps1')
. (Join-Path $PSScriptRoot 'AudioVolume.ps1')
. (Join-Path $PSScriptRoot 'ControlsFocus.ps1')
. (Join-Path $PSScriptRoot 'MenuLifecycle.ps1')
. (Join-Path $PSScriptRoot 'OverlayVisibility.ps1')
. (Join-Path $PSScriptRoot 'FloatingMenu.ps1')
$script:settingsReady=$false
$settingsPath=Join-Path (Split-Path $PSScriptRoot) 'HudSettings.json'
function Load-Xaml([string]$Name) {
    $text=Get-Content -LiteralPath (Join-Path $PSScriptRoot $Name) -Raw
    if($Name -eq 'Hud.xaml'){$text=ConvertTo-InstrumentXaml $text}
    [xml]$xml=$text
    $window=[Windows.Markup.XamlReader]::Load([Xml.XmlNodeReader]::new($xml))
    if($Name -eq 'Hud.xaml'){$window.FontFamily=$script:instrumentFont}
    if($Name -eq 'Controls.xaml'){$window.FindName('MenuBackground').Source=[Windows.Media.Imaging.BitmapImage]::new([uri](Join-Path $PSScriptRoot 'Art\menu-background.png'))}
    return $window
}
$hudWindow=Load-Xaml 'Hud.xaml'
$hud=$hudWindow.FindName('Hud')
$status=$hudWindow.FindName('Status')
$detail=$hudWindow.FindName('Detail')
$source=$hudWindow.FindName('Source')
$threat=$hudWindow.FindName('Threat')
$sector=$hudWindow.FindName('Sector')
$sectorStart=$hudWindow.FindName('SectorStart')
$sectorEnd=$hudWindow.FindName('SectorEnd')
$bearingLabel=$hudWindow.FindName('BearingLabel')
$audioLabel=$hudWindow.FindName('AudioLabel')
$trackCanvas=$hudWindow.FindName('TrackLayer')
$rwrCueCanvas=$hudWindow.FindName('RwrCueLayer')
$datalinkOverlayCanvas=$hudWindow.FindName('DatalinkOverlayLayer')
$missileCanvas=$hudWindow.FindName('MissileLayer')
$missileStatus=$hudWindow.FindName('MissileStatus')
$dlStatus=$hudWindow.FindName('DatalinkStatus')
foreach($instrument in $hudWindow.FindName('FlightData').Children){
    Set-HudAspectTransform $instrument (1280-[Windows.Controls.Canvas]::GetLeft($instrument)) (720-[Windows.Controls.Canvas]::GetTop($instrument))
}
Set-HudAspectTransform $dlStatus 400 0
Set-HudAspectTransform $missileStatus
$script:readers=@()
$script:reader=$null
$script:lastEvent=[datetime]::MinValue
$script:lastBeep=[datetime]::MinValue
$script:lastMode=''
$script:telemetryLast=[datetime]::MinValue
$script:partial=''
$script:demoStep=0
$script:flash=$false

$script:fontBaselines=@{}
function Register-HudText($panel){
    foreach($child in $panel.Children){
        if($child -is [Windows.Controls.TextBlock]){$script:fontBaselines[$child]=$child.FontSize}
        elseif($child -is [Windows.Controls.Panel]){Register-HudText $child}
        elseif($child -is [Windows.Controls.Border] -and $child.Child -is [Windows.Controls.Panel]){Register-HudText $child.Child}
    }
}
Register-HudText $hud
function Set-HudFontScale([double]$Factor){
    $factor=[Math]::Max(0.6,[Math]::Min(2.5,$Factor));$script:fontFactor=$factor
    foreach($item in $script:fontBaselines.Keys){$item.FontSize=$script:fontBaselines[$item]*$factor}
}
function Reset-HudOffsets($Horizontal,$Vertical){
    $Horizontal.Value=0
    $Vertical.Value=0
}
function Set-ClockSector([int]$Hour) {
    if($Hour -lt 1 -or $Hour -gt 12){$threat.Visibility='Hidden';return}
    $points=New-Object Windows.Media.PointCollection
    $angle=$Hour*30
    for($step=0;$step -le 16;$step++){
        $radians=($angle-15+$step*30/16)*[Math]::PI/180
        $points.Add([Windows.Point]::new((2200+90*[Math]::Sin($radians)),(1000-90*[Math]::Cos($radians))))
    }
    $sector.Points=$points
    foreach($boundary in @(@($sectorStart,($angle-15)),@($sectorEnd,($angle+15)))){
        $rad=$boundary[1]*[Math]::PI/180
        $line=$boundary[0]
        $line.X1=2200+82*[Math]::Sin($rad);$line.Y1=1000-82*[Math]::Cos($rad)
        $line.X2=2200+98*[Math]::Sin($rad);$line.Y2=1000-98*[Math]::Cos($rad)
    }
    $rad=$angle*[Math]::PI/180
    [Windows.Controls.Canvas]::SetLeft($bearingLabel,(2200+120*[Math]::Sin($rad)-20))
    [Windows.Controls.Canvas]::SetTop($bearingLabel,(1000-120*[Math]::Cos($rad)-9))
    $bearingLabel.Text=('{0:00} H' -f $Hour)
    $threat.Visibility='Visible'
}
function Show-ReceiverEvent($e) {
    $script:receiverEvent=$e
    $script:lastEvent=[datetime]::UtcNow
    $source.Text=if($Demo -or $RenderPreview){'DEMO / SYNTHETIC DATA'}else{'JESTER RWR / LIVE RECEIVER'}
    $color=[Windows.Media.Brushes]::LightGreen
    switch($e.Mode){
        LAUNCH {$status.Text='LAUNCH';$color=[Windows.Media.Brushes]::OrangeRed}
        CONTACT {$status.Text='RADAR CONTACT';$color=[Windows.Media.Brushes]::LightGreen}
        CLEAR {$status.Text='NO REPORTED RWR CONTACTS'}
        TEST {$status.Text='RWR TEST / ALERTS SUPPRESSED';$color=[Windows.Media.Brushes]::LightBlue}
        default {$status.Text='RWR DATA UNAVAILABLE';$color=[Windows.Media.Brushes]::Gray}
    }
    $status.Opacity=1
    $status.Foreground=$color
    $sector.Stroke=$color;$sectorStart.Stroke=$color;$sectorEnd.Stroke=$color;$bearingLabel.Foreground=$color
    $threat.Opacity=1
    if($e.Mode -in @('CONTACT','LAUNCH')){
        Set-ClockSector $e.Hour
        $bearing=if($e.Hour){"$($e.Hour) O'CLOCK"}else{'BEARING UNKNOWN'}
        $detail.Text="BODY: $bearing | $($e.Category) | $($e.Activity)"
    }else{
        $threat.Visibility='Hidden'
        $detail.Text='Receiver reports only; no contacts does not mean safe.'
    }
    $now=[datetime]::UtcNow
    $script:lastMode=$e.Mode
}
function Set-NoSignal([string]$Title,[string]$Description){
    $status.Text=$Title;$status.Foreground=[Windows.Media.Brushes]::Gray
    $source.Text='NO LIVE RECEIVER SIGNAL';$detail.Text=$Description
    $threat.Visibility='Hidden';$script:lastMode=''
$script:telemetryLast=[datetime]::MinValue
}
if($SelfTest){$null=Load-Xaml 'Controls.xaml';$v=[FoxGeometry]::A(0,1,0,0,12,1);if($v.Length -ne 3){throw 'Runtime initialization failed'};Write-Output 'PASS: runtime initialization';exit}
if($RenderPreview){
    Show-ReceiverEvent ([pscustomobject]@{Mode='LAUNCH';Hour=2;Activity='launch';Category='surface'})
    
    Set-DatalinkFrame (New-DatalinkDemo 0) $true;Draw-Datalink
    if($ModernPreview){
        $script:dlFrame|Add-Member NoteProperty flight @{ias=177.49;altitude=1908.048;aoa=3.1;mach=0.58;g=1} -Force
        $script:dlFrame.own_heading=[Math]::PI*1.5
        $script:dlFrame.tracks[0].aircraft_type='F-15C'
        $script:dlFrame.tracks[1].aircraft_type='F-16C_50'
        Update-HornetFlightData;Draw-Datalink
        $script:modernRwrEnabled=$false
        $script:jesterMissileFrame=[pscustomobject]@{state='AWARENESS';missiles=@(
            @{id='preview-detected';identity='HOSTILE';type='SA10_5V55R';age_s=0;world=@{x=10000;y=4000;z=4000}},
            @{id='preview-inbound';identity='HOSTILE';type='AIM_120C';age_s=0;world=@{x=10000;y=7300;z=-4000}})}
        $script:jesterMissileLast=[datetime]::UtcNow
        $script:incomingSamples=@{'preview-inbound'=@{Incoming=$true}}
        $script:incomingMarkerLast=[datetime]::UtcNow
        Draw-JesterMissiles
        $script:modernRwrEnabled=$true;$script:rwrSize=1
        $script:rwrContacts=[pscustomobject]@{state='LIVE';contacts=@(
            [pscustomobject]@{hour=12;activity='search';symbol1='five'},
            [pscustomobject]@{hour=3;activity='lock';symbol1='seven'},
            [pscustomobject]@{hour=8;activity='launch';symbol1='ten'})}
        $script:rwrContactsLast=[datetime]::UtcNow;$script:flash=$true;Draw-RwrCue
        $script:datalinkOverlayEnabled=$true;Draw-DatalinkOverlay
        $detail.Text='DEMO / SYNTHETIC CONTACTS / JHMCS + OPTIONAL DATALINK'
    }
    $hud.Background=[Windows.Media.Brushes]::Black
    $hud.Measure([Windows.Size]::new(2560,1440))
    $hud.Arrange([Windows.Rect]::new(0,0,2560,1440));$hud.UpdateLayout()
    $bitmap=[Windows.Media.Imaging.RenderTargetBitmap]::new(2560,1440,96,96,[Windows.Media.PixelFormats]::Pbgra32)
    $bitmap.Render($hud)
    $encoder=New-Object Windows.Media.Imaging.PngBitmapEncoder
    $encoder.Frames.Add([Windows.Media.Imaging.BitmapFrame]::Create($bitmap))
    $output=[IO.File]::Create($RenderPreview)
    try{$encoder.Save($output)}finally{$output.Dispose()}
    exit
}
$controls=Load-Xaml 'Controls.xaml'
$audio=$controls.FindName('Audio')
$incomingAudioCheckbox=$controls.FindName('IncomingAudio')
$sizeSlider=$controls.FindName('Size')
$opacitySlider=$controls.FindName('Opacity')
$fontSlider=$controls.FindName('FontScale')
$fontValue=$controls.FindName('FontValue')
$fovSlider=$controls.FindName('HorizontalFov')
$markerSlider=$controls.FindName('MarkerScale')
$xSlider=$controls.FindName('OffsetX');$ySlider=$controls.FindName('OffsetY')
$centerZoomSlider=$controls.FindName('CenterZoom')
$rwrZoomSlider=$controls.FindName('RwrZoom')
$missileZoomSlider=$controls.FindName('MissileZoom')
$aircraftSizeSlider=$controls.FindName('AircraftSize')
$missileSizeSlider=$controls.FindName('MissileSize')
$rwrSizeSlider=$controls.FindName('RwrSize')
$datalinkCheckbox=$controls.FindName('DatalinkEnabled')
$modernRwrCheckbox=$controls.FindName('ModernRwrEnabled')
$datalinkRange=$controls.FindName('DatalinkRange')
$mapCheckbox=$controls.FindName('DatalinkOverlayEnabled')
$saRwrCheckbox=$controls.FindName('SaRwrEnabled')
$mapX=$controls.FindName('DatalinkOverlayX');$mapY=$controls.FindName('DatalinkOverlayY')
$mapScale=$controls.FindName('DatalinkOverlayScale')
function Move-DatalinkOverlay([double]$X,[double]$Y){
    $maxX=2560-420*$mapScale.Value;$maxY=1440-420*$mapScale.Value
    $mapX.Value=[Math]::Max(0,[Math]::Min($maxX,([Math]::Min($maxX,$mapX.Value)+$X)))
    $mapY.Value=[Math]::Max(0,[Math]::Min($maxY,([Math]::Min($maxY,$mapY.Value)+$Y)))
    Update-HudVisuals;Draw-DatalinkOverlay
}
function Update-HudVisuals {
    Set-FlightDataScale $controls.FindName('FlightDataScale').Value
    Set-HudAudioVolume $controls.FindName('AudioVolume').Value

    Set-AlertRange ([int]$datalinkRange.SelectedValue)
    $controls.FindName('AlertRangeNm').Value=[int]$datalinkRange.SelectedValue
    Set-LaunchWarningRange ([int]$controls.FindName('LaunchWarningRangeNm').Value)
    $script:rwrWarningEnabled=[bool]$controls.FindName('RwrWarning').IsChecked
    Update-RangeHighlights
    $script:cockpitOnly=[bool]$controls.FindName('CockpitOnly').IsChecked
    $script:flightDataEnabled=[bool]$controls.FindName('FlightDataEnabled').IsChecked
    $controls.FindName('RwrRangeValue').Text=('{0:0} NM' -f ($script:launchWarningRangeM/1852.0))
    $controls.FindName('DatalinkRangeValue').Text=($datalinkRange.SelectedValue+' NM')
    foreach($nm in @(20,40,60)){
        $controls.FindName(('Range'+$nm)).FontWeight=if([int]$datalinkRange.SelectedValue -eq $nm){'Bold'}else{'Normal'}
    }
    $script:saRwrEnabled=[bool]$saRwrCheckbox.IsChecked
    $script:saAircraftTypes=[bool]$controls.FindName('SaAircraftTypes').IsChecked
    $script:datalinkOverlayEnabled=[bool]$mapCheckbox.IsChecked
    $script:datalinkOverlayX=$mapX.Value;$script:datalinkOverlayY=$mapY.Value
    $script:datalinkOverlayScale=$mapScale.Value
    Set-DatalinkRange ([int]$datalinkRange.SelectedValue)
    $script:modernRwrEnabled=[bool]$modernRwrCheckbox.IsChecked
    $script:contentScale=$sizeSlider.Value
    $script:aircraftSize=$aircraftSizeSlider.Value
    $script:missileSize=$missileSizeSlider.Value
    $script:rwrSize=$rwrSizeSlider.Value
    Set-HudFontScale $fontSlider.Value
    $fontValue.Text=('{0:0}%' -f ($fontSlider.Value*100))
    $hud.Opacity=$opacitySlider.Value
    $script:markerOffsetX=0;$script:markerOffsetY=0
    $script:projectionScaleX=$centerZoomSlider.Value;$script:projectionScaleY=$centerZoomSlider.Value
    $script:rwrProjectionZoom=$rwrZoomSlider.Value
    $script:missileProjectionZoom=$missileZoomSlider.Value
    if($script:settingsReady){Save-HudSettings $controls $settingsPath}
    
    [Windows.Controls.Canvas]::SetLeft($dlStatus,(880+$xSlider.Value))
    [Windows.Controls.Canvas]::SetTop($dlStatus,(1340+$ySlider.Value))
}
function Set-HudWindowVisible([bool]$Visible){
    if($script:hudVisibilityChanging){return}
    $script:hudVisibilityChanging=$true
    try{
        if($Visible){if(-not $hudWindow.IsVisible){$hudWindow.Show()}}
        elseif($hudWindow.IsVisible){$hudWindow.Hide()}
    }finally{$script:hudVisibilityChanging=$false}
}
function Update-HudPosition {
    $metrics=if(-not $Demo){[F4HudWindow]::CaptureDcs()}else{$null}
    $source=[Windows.PresentationSource]::FromVisual($hudWindow)
    $dx=1.0;$dy=1.0
    if($source -and $source.CompositionTarget){
        $dx=$source.CompositionTarget.TransformToDevice.M11
        $dy=$source.CompositionTarget.TransformToDevice.M22
    }
    if($metrics){
        $hudWindow.Width=$metrics.Width/$dx;$hudWindow.Height=$metrics.Height/$dy
        $hudWindow.Left=$metrics.X/$dx;$hudWindow.Top=$metrics.Y/$dy
        $script:viewportAspect=[double]$metrics.Width/$metrics.Height
        Update-HudAspect $metrics.Width $metrics.Height
        $signature=('{0},{1} {2}x{3} DPI={4},{5}' -f $metrics.X,$metrics.Y,$metrics.Width,$metrics.Height,$dx,$dy)
        if($script:lastViewportSignature -ne $signature){
            $script:lastViewportSignature=$signature
            $signature | Set-Content -LiteralPath (Join-Path $PSScriptRoot '..\viewport-info.txt') -Encoding UTF8
        }
        $view=Get-CockpitViewState $script:dlFrame (([datetime]::UtcNow-$script:dlLast).TotalSeconds -le 1)
        $viewAllowed=-not $script:cockpitOnly -or $view -eq 'NEAR_COCKPIT'
        Set-HudWindowVisible ($metrics.Active -and $viewAllowed)
        $hudWindow.Opacity=if($metrics.Active -and $viewAllowed){1}else{0}
        $script:hudDisplayState=@{gameActive=$metrics.Active;view=$view;viewAllowed=$viewAllowed;opacity=$hudWindow.Opacity;contentVisibility=[string]$hud.Visibility;windowVisible=$hudWindow.IsVisible;topmost=$hudWindow.Topmost}
        if($hudWindow.Opacity -gt 0){
            if(-not $script:hudWasVisible -or ([datetime]::UtcNow-$script:lastHudRaise).TotalSeconds -ge 1){
                [F4HudWindow]::KeepAboveGame([Windows.Interop.WindowInteropHelper]::new($hudWindow).Handle)
                $script:lastHudRaise=[datetime]::UtcNow
            }
            $script:hudWasVisible=$true
        }else{$script:hudWasVisible=$false}
        if($script:menuBubble){if($metrics.Active -and (-not $script:cockpitOnly -or $view -ne 'EXTERNAL')){$script:menuBubble.Show()}else{$script:menuBubble.Hide()}}
        if($script:cockpitOnly -and $view -eq 'EXTERNAL' -and $controls.IsVisible){Hide-ControlsPanel}
    }else{
        $script:hudWasVisible=$false
        if(-not $Demo){Set-HudWindowVisible $false}
        $script:hudDisplayState=@{gameActive=$false;view='NO_GAME_WINDOW';opacity=0;contentVisibility=[string]$hud.Visibility;windowVisible=$hudWindow.IsVisible}
        $hudWindow.Left=0;$hudWindow.Top=0
        $hudWindow.Width=[Windows.SystemParameters]::PrimaryScreenWidth
        $hudWindow.Height=[Windows.SystemParameters]::PrimaryScreenHeight
        $script:viewportAspect=$hudWindow.Width/$hudWindow.Height
        Update-HudAspect ($hudWindow.Width*$dx) ($hudWindow.Height*$dy)
        $hudWindow.Opacity=if($Demo){1}else{0}
        if($script:menuBubble){$script:menuBubble.Show()}
    }
}
Load-HudSettings $controls $settingsPath
$controls.FindName('SaRwrRangeNm').Value=[int]$datalinkRange.SelectedValue
$script:settingsReady=$true
$script:modernRwrEnabled=[bool]$modernRwrCheckbox.IsChecked
$script:flightDataEnabled=[bool]$controls.FindName('FlightDataEnabled').IsChecked
$controls.FindName('AllOverlaysToggle').Add_Checked({if(-not $script:syncOverlaySwitch){Set-GameOverlaysVisible $true}})
$controls.FindName('AllOverlaysToggle').Add_Unchecked({if(-not $script:syncOverlaySwitch){Set-GameOverlaysVisible $false}})
$modernRwrCheckbox.Add_Checked({Update-HudVisuals;Draw-RwrCue})
$modernRwrCheckbox.Add_Unchecked({Update-HudVisuals;Draw-RwrCue})
$datalinkRange.Add_SelectionChanged({Update-HudVisuals;Draw-Datalink;Draw-DatalinkOverlay})
Connect-DatalinkRangeButtons $controls
$controls.FindName('SaRwrRangeNm').Add_ValueChanged({Select-DatalinkRange ([int]$args[1].NewValue)})
$controls.FindName('LaunchWarningRangeNm').Add_ValueChanged({Set-LaunchWarningRange ([int]$args[1].NewValue);$controls.FindName('RwrRangeValue').Text=('{0:0} NM' -f ($script:launchWarningRangeM/1852));if($script:settingsReady){Save-HudSettings $controls $settingsPath}})
$controls.FindName('RwrWarning').Add_Checked({$script:rwrWarningEnabled=$true;Save-HudSettings $controls $settingsPath})
$controls.FindName('RwrWarning').Add_Unchecked({$script:rwrWarningEnabled=$false;Stop-RadarToneLoop;if($script:receiverAudioPlayer){$script:receiverAudioPlayer.Stop()};if($script:missileTonePlayer){$script:missileTonePlayer.Stop()};$script:missileAudioQueue.Clear();Save-HudSettings $controls $settingsPath})
$controls.FindName('ResetAllCalibration').Add_Click({$centerZoomSlider.Value=1;$missileZoomSlider.Value=1;$rwrZoomSlider.Value=1;Reset-HudOffsets $xSlider $ySlider;Update-HudVisuals})
$controls.FindName('LaunchRange20').Add_Click({$controls.FindName('LaunchWarningRangeNm').Value=20;Update-HudVisuals})
$controls.FindName('LaunchRange40').Add_Click({$controls.FindName('LaunchWarningRangeNm').Value=40;Update-HudVisuals})
$controls.FindName('LaunchRange60').Add_Click({$controls.FindName('LaunchWarningRangeNm').Value=60;Update-HudVisuals})
$controls.FindName('AudioVolume').Add_ValueChanged({Set-HudAudioVolume ([double]$args[1].NewValue);if($script:settingsReady){Save-HudSettings $controls $settingsPath}})
$controls.FindName('AlertRange20').Add_Click({$controls.FindName('AlertRangeNm').Value=20;Update-HudVisuals})
$controls.FindName('AlertRange40').Add_Click({$controls.FindName('AlertRangeNm').Value=40;Update-HudVisuals})
$controls.FindName('AlertRange60').Add_Click({$controls.FindName('AlertRangeNm').Value=60;Update-HudVisuals})
$controls.FindName('CockpitOnly').Add_Checked({Update-HudVisuals})
$controls.FindName('CockpitOnly').Add_Unchecked({Update-HudVisuals})
$controls.FindName('FlightDataEnabled').Add_Checked({Update-HudVisuals;Update-HornetFlightData})
$controls.FindName('FlightDataEnabled').Add_Unchecked({Update-HudVisuals;Update-HornetFlightData})
$mapCheckbox.Add_Checked({Update-HudVisuals;Draw-DatalinkOverlay})
$mapCheckbox.Add_Unchecked({Update-HudVisuals;Draw-DatalinkOverlay})
$controls.FindName('SaAircraftTypes').Add_Checked({Update-HudVisuals;Draw-DatalinkOverlay})
$controls.FindName('SaAircraftTypes').Add_Unchecked({Update-HudVisuals;Draw-DatalinkOverlay})
$saRwrCheckbox.Add_Checked({Update-HudVisuals;Draw-DatalinkOverlay})
$saRwrCheckbox.Add_Unchecked({Update-HudVisuals;Draw-DatalinkOverlay})
$mapX.Add_ValueChanged({Update-HudVisuals;Draw-DatalinkOverlay})
$mapY.Add_ValueChanged({Update-HudVisuals;Draw-DatalinkOverlay})
$mapScale.Add_ValueChanged({Update-HudVisuals;Draw-DatalinkOverlay})
$controls.FindName('MapLeft').Add_Click({Move-DatalinkOverlay -20 0})
$controls.FindName('MapRight').Add_Click({Move-DatalinkOverlay 20 0})
$controls.FindName('MapUp').Add_Click({Move-DatalinkOverlay 0 -20})
$controls.FindName('MapDown').Add_Click({Move-DatalinkOverlay 0 20})
$controls.FindName('ResetDatalinkOverlay').Add_Click({$mapX.Value=180;$mapY.Value=880;$mapScale.Value=1;Update-HudVisuals;Draw-DatalinkOverlay})
$datalinkCheckbox.Add_Checked({Save-HudSettings $controls $settingsPath})
$datalinkCheckbox.Add_Unchecked({Save-HudSettings $controls $settingsPath})
$audio.Add_Checked({Save-HudSettings $controls $settingsPath})
$audio.Add_Unchecked({Save-HudSettings $controls $settingsPath})
$incomingAudioCheckbox.Add_Checked({Save-HudSettings $controls $settingsPath})
$incomingAudioCheckbox.Add_Unchecked({Stop-IncomingToneLoop;$script:incomingNextTone=[datetime]::MinValue;Save-HudSettings $controls $settingsPath})
foreach($slider in @($controls.FindName('FlightDataScale'),$sizeSlider,$fontSlider,$opacitySlider,$xSlider,$ySlider,$centerZoomSlider,$rwrZoomSlider,$missileZoomSlider,$aircraftSizeSlider,$missileSizeSlider,$rwrSizeSlider)){$slider.Add_ValueChanged({Update-HudVisuals})}
$controls.FindName('ResetMissileZoom').Add_Click({$missileZoomSlider.Value=1;Update-HudVisuals})
$controls.FindName('ResetRwrZoom').Add_Click({$rwrZoomSlider.Value=1;Update-HudVisuals})
$controls.FindName('ResetPosition').Add_Click({Reset-HudOffsets $xSlider $ySlider;$centerZoomSlider.Value=1;$fovSlider.Value=90;Update-HudVisuals})
$audio.Add_Checked({$audioLabel.Text='AUDIO ON'})
$audio.Add_Unchecked({Stop-RadarToneLoop;Stop-IncomingToneLoop;if($script:receiverAudioPlayer){$script:receiverAudioPlayer.Stop()};$audioLabel.Text='AUDIO OFF';if($script:missileTonePlayer){$script:missileTonePlayer.Stop()};if($script:incomingTonePlayer){$script:incomingTonePlayer.Stop()};$script:missileAudioQueue.Clear()})
$controls.FindName('HideControls').Add_Click({Hide-ControlsPanel})
$controls.FindName('ExitApplication').Add_Click({Exit-FoxApplication})
$controls.Add_Closing({Handle-MenuClosing $args[1]})
$controls.Add_SourceInitialized({Initialize-ControlsFocus})
if(-not $Demo){
    if($ProfileRoot){
        $fullRoot=[IO.Path]::GetFullPath($ProfileRoot)
        if($fullRoot -match '(?i)(^|[\\/])OneDrive[^\\/]*([\\/]|$)'){throw 'Use a profile outside OneDrive.'}
        $selectedPaths=@((Join-Path $fullRoot 'Logs\F4RwrLink.log'),(Join-Path $fullRoot 'Logs\F4RwrProbe.log'),(Join-Path $fullRoot 'Logs\dcs.log'))
    }else{
        $picker=New-Object Microsoft.Win32.OpenFileDialog
        $picker.Title='Choose up to 3 logs: F4RwrLink, F4RwrProbe, optional mission dcs.log'
        $picker.Filter='Log files (*.log)|*.log|All files (*.*)|*.*'
        $picker.Multiselect=$true
        if(-not $picker.ShowDialog()){exit}
        if($picker.FileNames.Count -gt 3){[void][Windows.MessageBox]::Show('Select at most three logs.');exit}
        $selectedPaths=$picker.FileNames
    }
    foreach($selectedPath in $selectedPaths){
        $script:readers+=([pscustomobject]@{Reader=$null;Partial='';Path=$selectedPath;Retry=[datetime]::MinValue;Buffer=(New-Object char[] 32768)})
    }
}

$script:bridgeLeasePath=$null;$script:lastBridgePulse=[datetime]::MinValue
if(-not $Demo){
    foreach($selectedPath in $selectedPaths){
        if([IO.Path]::GetFileName($selectedPath) -eq 'F4RwrLink.log'){
            $script:bridgeLeasePath=Join-Path ([IO.Path]::GetDirectoryName($selectedPath)) 'FoxSense.active';break
        }
    }
}
function Update-BridgeHeartbeat {
    if(-not $script:bridgeLeasePath -or ([datetime]::UtcNow-$script:lastBridgePulse).TotalSeconds -lt 1){return}
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($script:bridgeLeasePath))
    [IO.File]::WriteAllText($script:bridgeLeasePath,'FOX SENSE active')
    $script:lastBridgePulse=[datetime]::UtcNow
}
Add-Type -TypeDefinition @"
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
public sealed class F4ClientMetrics { public int X,Y,Width,Height; public bool Active; }
public static class F4HudWindow {
 [StructLayout(LayoutKind.Sequential)] public struct RECT {public int Left,Top,Right,Bottom;}
 [StructLayout(LayoutKind.Sequential)] public struct POINT {public int X,Y;}
 [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h,int n);
 [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr h,int n,int v);
 [DllImport("user32.dll")] private static extern bool GetClientRect(IntPtr h,out RECT r);
 [DllImport("user32.dll")] private static extern bool ClientToScreen(IntPtr h,ref POINT p);
 [DllImport("user32.dll")] private static extern bool IsIconic(IntPtr h);
 [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] private static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int cx,int cy,uint flags);
 public static void KeepAboveGame(IntPtr h){if(h!=IntPtr.Zero)SetWindowPos(h,new IntPtr(-1),0,0,0,0,0x213);}
 [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr h,out uint p);
 public static void MakePassive(IntPtr h) { SetWindowLong(h,-20,GetWindowLong(h,-20)|0x20|0x08000000|0x80); }
 public static F4ClientMetrics CaptureDcs(){
  foreach(Process p in Process.GetProcessesByName("DCS")){
   try{
    IntPtr h=p.MainWindowHandle;
    if(h==IntPtr.Zero||IsIconic(h)||!p.MainWindowTitle.Contains("Digital Combat Simulator"))continue;
    RECT r;POINT origin=new POINT();
    if(!GetClientRect(h,out r)||!ClientToScreen(h,ref origin)||r.Right<640||r.Bottom<480)continue;
    uint foreground;GetWindowThreadProcessId(GetForegroundWindow(),out foreground);
    return new F4ClientMetrics{X=origin.X,Y=origin.Y,Width=r.Right-r.Left,Height=r.Bottom-r.Top,Active=foreground==(uint)p.Id||foreground==(uint)Process.GetCurrentProcess().Id};
   }catch{}finally{p.Dispose();}
  }
  return null;
 }
}
"@
$hudWindow.Add_SourceInitialized({
    $handle=[Windows.Interop.WindowInteropHelper]::new($hudWindow).Handle
    [F4HudWindow]::MakePassive($handle)
    Update-HudPosition
})
$script:lastViewportCheck=[datetime]::MinValue
$timer=New-Object Windows.Threading.DispatcherTimer
$timer.Interval=[timespan]::FromTicks(166667)
$timer.Add_Tick({
    $tickClock=[Diagnostics.Stopwatch]::StartNew()
    try{
        Update-BridgeHeartbeat
        if(([datetime]::UtcNow-$script:lastViewportCheck).TotalMilliseconds -gt 100){Update-HudPosition;$script:lastViewportCheck=[datetime]::UtcNow}
        if($Demo){
            $script:demoStep++
            Set-DatalinkFrame (New-DatalinkDemo $script:demoStep) $true
            if($script:demoStep%60 -eq 1){
                $modes=@('CLEAR','CONTACT','CONTACT','LAUNCH','LAUNCH','TEST','UNAVAILABLE')
                $index=[int][Math]::Floor(($script:demoStep-1)/60)%$modes.Count
                $hours=@(0,2,9,4,7,0,0)
                Show-ReceiverEvent ([pscustomobject]@{Mode=$modes[$index];Hour=$hours[$index];Activity=if($modes[$index] -eq 'LAUNCH'){'launch'}else{'demo'};Category='surface'})
            }
        }else{
            foreach($entry in $script:readers){
                $now=[datetime]::UtcNow
                if($entry.Reader -and ($now-$script:dlLast).TotalSeconds -gt 4 -and $now -ge $entry.Retry){
                    
                    $entry.Reader.Dispose();$entry.Reader=$null;$entry.Partial=''
                }
                if($null -eq $entry.Reader){
                    if($now -lt $entry.Retry){continue}
                    $entry.Retry=$now.AddSeconds(2)
                    try{
                        $stream=[IO.File]::Open($entry.Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
                        [void]$stream.Seek(0,[IO.SeekOrigin]::End)
                        $entry.Reader=[IO.StreamReader]::new($stream)
                        $entry.Partial=''
                        $entry.Retry=$now.AddSeconds(4)
                    }catch{continue}
                }
                $reader=$entry.Reader
                if($reader.BaseStream.Length -lt $reader.BaseStream.Position){
                    $reader.DiscardBufferedData();[void]$reader.BaseStream.Seek(0,[IO.SeekOrigin]::Begin);$entry.Partial=''
                }
                $buffer=$entry.Buffer
                $count=$reader.Read($buffer,0,$buffer.Length)
                if($count -gt 0){
                    $lines=($entry.Partial+[string]::new($buffer,0,$count)) -split "`n"
                    $entry.Partial=$lines[-1]
                    if($entry.Partial.Length -gt 65536){$entry.Partial=''}
                    $latestRwr=$null;$latestDl=$null;$latestCamera=$null;$latestMissiles=$null;$latestRwrContacts=$null
                    for($i=0;$i -lt $lines.Length-1;$i++){
                        $line=$lines[$i].TrimEnd("`r")
                        $worldPacket=ConvertFrom-WorldMissileLine $line
                        if($null -ne $worldPacket){$script:exportMissileFrame=$worldPacket;$script:exportMissileLast=[datetime]::UtcNow}
                        $missionPacket=ConvertFrom-WorldMissileLine $line 'F4MODERN_V1|'
                        if($null -ne $missionPacket){$script:missionFrame=$missionPacket;$script:missionLast=[datetime]::UtcNow}
                        $nativePacket=ConvertFrom-NativeRwrLine $line
                        if($null -ne $nativePacket){$script:nativeRwr=$nativePacket;$script:nativeRwrLast=[datetime]::UtcNow}
                        $rwrPacket=ConvertFrom-RwrContactsLine $line
                        if($null -ne $rwrPacket){$latestRwrContacts=$rwrPacket}
                        $missilePacket=ConvertFrom-JesterMissileLine $line
                        if($null -ne $missilePacket){$latestMissiles=$missilePacket}
                        $parsed=ConvertFrom-F4RwrLine $line
                        if($null -ne $parsed){$latestRwr=$parsed}
                        $packet=ConvertFrom-DatalinkLine $line
                        if($null -ne $packet){$latestDl=$packet}
                        $cameraPacket=ConvertFrom-DatalinkLine $line 'F4CAM_V1|'
                        if($null -ne $cameraPacket){$latestCamera=$cameraPacket}
                    }
                    if($null -ne $latestRwrContacts){$script:rwrContacts=$latestRwrContacts;$script:rwrContactsLast=[datetime]::UtcNow}
                    if($null -ne $latestMissiles){$script:jesterMissileFrame=$latestMissiles;$script:jesterMissileLast=[datetime]::UtcNow}
                    if($null -ne $latestRwr){Show-ReceiverEvent $latestRwr}
                    if($null -ne $latestDl){Set-DatalinkFrame $latestDl ($latestDl.state -eq 'DEMO')}
                    if($null -ne $latestCamera){Set-CameraFrame $latestCamera}
                }
            }
            if(([datetime]::UtcNow-$script:lastEvent).TotalSeconds -gt 8){Set-NoSignal 'NO LIVE RWR DATA' 'Check selected log, Jester mods, pause or mission state.'}
        }
        Draw-Datalink
        Update-HornetFlightData
        Draw-RwrCue
        Update-IncomingMissileAudio
        Draw-DatalinkOverlay -RateLimited
        Update-RadarLockAudio
        Update-MissileDiscoveryAudio
        Draw-JesterMissiles
        if(([datetime]::UtcNow-$script:telemetryLast).TotalSeconds -ge 1){
            $script:telemetryLast=[datetime]::UtcNow
            $activeMissiles=Get-ActiveMissileFeed
            $snapshot=@{display=$script:hudDisplayState;time=[datetime]::UtcNow.ToString('o');missileSource=$activeMissiles.Source;exportMissileState=$script:exportMissileFrame.state;missileFeedAge=([datetime]::UtcNow-$activeMissiles.Last).TotalSeconds;cameraAge=([datetime]::UtcNow-$script:dlLast).TotalSeconds;status=$missileStatus.Text;cacheCount=$script:jesterMissileCache.Count;shapes=$missileCanvas.Children.Count;packet=$activeMissiles.Packet;rwrShapes=$rwrCueCanvas.Children.Count;saRangeNm=($script:markerRangeM/1852);rwrRangeNm=($script:alertRangeM/1852);launchWarningRangeNm=($script:launchWarningRangeM/1852);targetHudIntervalMs=(1000.0/60.0);previousTickMs=$script:lastTickMs;actualTimerIntervalMs=$timer.Interval.TotalMilliseconds;radarAudio=$script:radarAudioDiagnostic;radarToneLoop=$script:radarToneLoop;launchToneLoop=$script:incomingToneLoop}
            [IO.File]::WriteAllText((Join-Path (Split-Path $PSScriptRoot) 'hud-runtime.json'),($snapshot|ConvertTo-Json -Depth 8))
            if($missileCanvas.Children.Count -gt 0){[IO.File]::WriteAllText((Join-Path (Split-Path $PSScriptRoot) 'last-missile-drawn.json'),($snapshot|ConvertTo-Json -Depth 8))}
        }
        if(-not $Demo -and $ProfileRoot -and $datalinkCheckbox.IsChecked -and ([datetime]::UtcNow-$script:dlLast).TotalSeconds -gt 3){$dlStatus.Text='WAITING FOR DCS MISSION / AUTO CONNECT'}
        $script:flash=([Math]::Floor([datetime]::UtcNow.TimeOfDay.TotalMilliseconds/250)%2 -eq 0)
        if($script:lastMode -eq 'LAUNCH'){$threat.Opacity=if($script:flash){1}else{0.25};$status.Opacity=$threat.Opacity}
    }catch{[IO.File]::WriteAllText((Join-Path (Split-Path $PSScriptRoot) 'hud-runtime-error.txt'),($_|Out-String));Set-NoSignal 'LOG READ ERROR' 'Restart the HUD and select the active log again.'}finally{$tickClock.Stop();$script:lastTickMs=$tickClock.Elapsed.TotalMilliseconds;$timer.Interval=if(-not $Demo -and $hudWindow.Opacity -eq 0 -and -not $controls.IsVisible){[timespan]::FromMilliseconds(100)}else{[timespan]::FromTicks(166667)}}
})
$script:controlsLoop=[Windows.Threading.DispatcherFrame]::new()
$controls.Add_Closed({$timer.Stop();foreach($entry in $script:readers){if($entry.Reader){$entry.Reader.Dispose()}};if($script:controlsFocus){$script:controlsFocus.Dispose()};if($script:menuFocus){$script:menuFocus.Dispose()};if($script:menuBubble){$script:menuBubble.Close()};$hudWindow.Close();$script:controlsLoop.Continue=$false})
Update-HudVisuals
Update-HudPosition
if($RuntimeControlsTest){if(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'Test-RuntimeControls.ps1')){. (Join-Path $PSScriptRoot 'Test-RuntimeControls.ps1')};return}
if($Demo){Set-HudWindowVisible $true}
$timer.Start()
try{
    [void][Windows.Interop.WindowInteropHelper]::new($controls).EnsureHandle()
    Initialize-FloatingMenu
    [Windows.Threading.Dispatcher]::PushFrame($script:controlsLoop)
}finally{
    if($script:bridgeLeasePath){try{[IO.File]::Delete($script:bridgeLeasePath)}catch{}}
    Stop-MenuAudio
    $timer.Stop();foreach($entry in $script:readers){if($entry.Reader){$entry.Reader.Dispose()}}
    if($script:controlsFocus){$script:controlsFocus.Dispose();$script:controlsFocus=$null}
    if($script:menuFocus){$script:menuFocus.Dispose();$script:menuFocus=$null}
    if($script:menuBubble){$script:menuBubble.Close();$script:menuBubble=$null}
    $hudWindow.Close()
}








