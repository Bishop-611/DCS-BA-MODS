FOX SENSE 0.10.13 - Manual installation

Adaptive HUD proportions follow the current DCS window. Text and symbols
remain uniform on ultrawide and other aspect ratios; target centers retain
their full-window projection. Live ultrawide appearance awaits user testing.
Camera/HUD target 60 Hz, world/target snapshots 10 Hz. The bridge
requires a fresh local HUD heartbeat and stops work when FOX SENSE exits.
The Flight data switch independently controls speed, altitude, HDG, AoA, Mach
and G. Actual rendering rate depends on game/render workload.
Restart DCS after installing the GUI hook. Standard single-view desktop
rendering is the intended target; VR and custom multi-camera viewports need
separate validation. If no fresh FOV is available, manual calibration is used.
This update does not claim to resolve the reported head-motion alignment issue.

This package does not require the FOX SENSE Setup EXE. It uses the same runtime
files as the EXE edition. Do not run both editions at the same time.

1. Close DCS and FOX SENSE. Back up any existing FOX SENSE application folder,
   your Saved Games\DCS\Scripts\Export.lua, and any existing F4RwrProbe.lua or
   init\StartF4RwrProbe.lua under Saved Games\DCS_F4E\jester\mods.

2. Copy the CONTENTS of this package's "Saved Games" folder into your Windows
   Saved Games folder (normally C:\Users\YOUR_WINDOWS_USER\Saved Games).
   Merge the corresponding folders; do not replace an entire profile folder.
   If you use DCS.openbeta or another DCS.* profile, use that folder instead
   of DCS. Keep DCS_F4E\jester\mods at your actual Jester mods location.
   On upgrade, keep your existing Runtime\HudSettings.json to retain settings.

3. IMPORTANT: edit Saved Games\DCS_F4E\jester\mods\F4RwrProbe.lua with a text
   editor. Replace the one path containing YOUR_WINDOWS_USER with the full
   path to YOUR DCS profile's Logs\F4RwrProbe.log. For example:
   C:\Users\YOUR_WINDOWS_USER\Saved Games\DCS\Logs\F4RwrProbe.log
   If you use DCS.openbeta, use DCS.openbeta in that path. Preserve the [[ ]].

4. Open your DCS profile's Scripts\Export.lua. If it does not exist, create it.
   Append the block from Export.lua.addition.txt, unless the same F4RWRLINK
   block already exists. Preserve all other mods' contents and callbacks.

5. Start DCS and enter the F-4E cockpit. Run:
   Saved Games\DCS\Mods\F4E FOX SENSE\Start FOX SENSE.cmd
   The CMD starts Windows PowerShell using the normal RemoteSigned policy.
   It does not change system execution policy or install a Windows font.
   If Windows marks a downloaded archive as blocked, review its source and
   use Properties > Unblock on the downloaded ZIP before extracting it.
   Organization security restrictions are not bypassed.

OPTIONAL PORTRAIT
   Skip this section to retain the current Jester portrait. To use the supplied
   portrait, first back up the existing file at:
   <DCS GAME>\Mods\aircraft\F-4E\UI\JesterSubtitle\img\jester_portrait.png
   Then copy the corresponding file from "Optional Portrait" into the DCS game
   folder. This affects the subtitle portrait, not the rear-seat 3D model.

REMOVAL / RESTORATION
   Close FOX SENSE and DCS. Remove only the F4RWRLINK block from Export.lua.
   Remove Scripts\Hooks\FoxViewFov.lua only, or restore its prior backup.
   Restore/remove only Scripts\F4RwrLink\FoxBridgeActivity.lua as applicable.
   Restore the two Jester mod files from your backups, or remove those exact
   files if they were newly added. Remove the FOX SENSE application folder.
   If you chose the portrait, restore its original backup. Do not delete other
   mods or replace newer Export.lua edits with an outdated backup.

NOTES
   The HUD visibility shortcut was removed; use the HUD switch in the menu.
   Export data availability depends on the mission/server. Multiplayer IC and
   antivirus compatibility must be checked in your actual environment.
   Font license: Runtime\Overlay\Fonts\OFL.txt inside the application folder.